package com.example.data

import com.example.model.ColorGradeWheel
import com.example.model.ColorGradingParams
import com.example.model.CurvePoint
import com.example.model.HslColorRange
import com.example.model.HslMixerParams
import com.example.model.ToneCurveParams
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Pure Kotlin color engine implementing:
 * 1. Smooth 8-band HSL Color Mixer with raised-cosine partition-of-unity hue blending.
 * 2. Fritsch-Carlson Monotone Cubic Hermite Spline Tone Curve LUTs (prevents overshoot/artifacts).
 * 3. Smooth tonal-range Color Grading (Shadows, Midtones, Highlights).
 */
object ColorEngine {

  class HslLut(
    val hueShiftsDeg: FloatArray,
    val satShifts: FloatArray,
    val lumShifts: FloatArray,
  )

  fun buildHslLut(params: HslMixerParams): HslLut {
    val hueLut = FloatArray(360)
    val satLut = FloatArray(360)
    val lumLut = FloatArray(360)
    val ranges = HslColorRange.entries

    for (deg in 0 until 360) {
      val h = deg.toFloat()
      var totalH = 0f
      var totalS = 0f
      var totalL = 0f

      for (i in ranges.indices) {
        val adj = params.forRange(ranges[i])
        if (adj.isIdentity) continue

        val center = ranges[i].centerHueDegrees
        val prevCenter = ranges[(i - 1 + ranges.size) % ranges.size].centerHueDegrees
        val nextCenter = ranges[(i + 1) % ranges.size].centerHueDegrees

        val leftSpan = forwardDistance(prevCenter, center)
        val rightSpan = forwardDistance(center, nextCenter)
        val weight = computeBandWeight(h, center, leftSpan, rightSpan)
        if (weight > 0f) {
          totalH += weight * (adj.hue / 100f) * 35f
          totalS += weight * (adj.saturation / 100f)
          totalL += weight * (adj.luminance / 100f) * 0.42f
        }
      }
      hueLut[deg] = totalH
      satLut[deg] = totalS
      lumLut[deg] = totalL
    }
    return HslLut(hueLut, satLut, lumLut)
  }

  private fun forwardDistance(fromDeg: Float, toDeg: Float): Float {
    val d = ((toDeg - fromDeg) % 360f + 360f) % 360f
    return if (d == 0f) 360f else d
  }

  private fun computeBandWeight(h: Float, center: Float, leftSpan: Float, rightSpan: Float): Float {
    // Signed shortest angular distance from center in [-180..180]
    var diff = h - center
    while (diff > 180f) diff -= 360f
    while (diff < -180f) diff += 360f

    return when {
      diff == 0f -> 1f
      diff < 0f && -diff < leftSpan -> {
        val t = 1f - (-diff / leftSpan)
        0.5f * (1f - cos(PI.toFloat() * t))
      }
      diff > 0f && diff < rightSpan -> {
        val t = 1f - (diff / rightSpan)
        0.5f * (1f - cos(PI.toFloat() * t))
      }
      else -> 0f
    }
  }

  fun applyHslMixerToRgb(
    rIn: Float,
    gIn: Float,
    bIn: Float,
    lut: HslLut,
  ): Triple<Float, Float, Float> {
    val r = (rIn / 255f).coerceIn(0f, 1f)
    val g = (gIn / 255f).coerceIn(0f, 1f)
    val b = (bIn / 255f).coerceIn(0f, 1f)

    val maxC = max(r, max(g, b))
    val minC = min(r, min(g, b))
    val delta = maxC - minC
    val l = (maxC + minC) * 0.5f

    if (delta < 1e-4f) {
      return Triple(rIn, gIn, bIn)
    }

    val s =
      if (l > 0.5f) delta / (2f - maxC - minC).coerceAtLeast(1e-5f)
      else delta / (maxC + minC).coerceAtLeast(1e-5f)

    var h =
      when (maxC) {
        r -> ((g - b) / delta + (if (g < b) 6f else 0f)) * 60f
        g -> ((b - r) / delta + 2f) * 60f
        else -> ((r - g) / delta + 4f) * 60f
      }
    h = ((h % 360f) + 360f) % 360f

    // Interpolate LUT across adjacent degree integers
    val deg0 = h.toInt().coerceIn(0, 359)
    val deg1 = (deg0 + 1) % 360
    val frac = h - deg0

    val hueShift = lut.hueShiftsDeg[deg0] * (1f - frac) + lut.hueShiftsDeg[deg1] * frac
    val satShift = lut.satShifts[deg0] * (1f - frac) + lut.satShifts[deg1] * frac
    val lumShift = lut.lumShifts[deg0] * (1f - frac) + lut.lumShifts[deg1] * frac

    if (hueShift == 0f && satShift == 0f && lumShift == 0f) {
      return Triple(rIn, gIn, bIn)
    }

    // Attenuate cleanly on near-neutral pixels so grays/whites do not pick up hue noise
    val chromaMask = smoothstep(0.02f, 0.14f, s)
    val newH = ((h + hueShift * chromaMask) % 360f + 360f) % 360f
    val newS =
      if (satShift >= 0f) (s + (1f - s) * s * satShift * 1.35f * chromaMask).coerceIn(0f, 1f)
      else (s * (1f + satShift * chromaMask)).coerceIn(0f, 1f)
    val lumScale = (1f - abs(2f * l - 1f) * 0.35f)
    val newL = (l + lumShift * lumScale * chromaMask).coerceIn(0f, 1f)

    val (outR, outG, outB) = hslToRgb(newH, newS, newL)
    return Triple(outR * 255f, outG * 255f, outB * 255f)
  }

  // --- Fritsch-Carlson Monotone Cubic Spline LUT for Tone Curve ---

  class ToneCurveLuts(
    val hasRgb: Boolean,
    val hasRed: Boolean,
    val hasGreen: Boolean,
    val hasBlue: Boolean,
    val rgb: IntArray,
    val red: IntArray,
    val green: IntArray,
    val blue: IntArray,
  )

  fun buildToneCurveLuts(params: ToneCurveParams): ToneCurveLuts {
    val hasRgb = !ToneCurveParams.isChannelIdentity(params.rgbPoints)
    val hasRed = !ToneCurveParams.isChannelIdentity(params.redPoints)
    val hasGreen = !ToneCurveParams.isChannelIdentity(params.greenPoints)
    val hasBlue = !ToneCurveParams.isChannelIdentity(params.bluePoints)
    return ToneCurveLuts(
      hasRgb = hasRgb,
      hasRed = hasRed,
      hasGreen = hasGreen,
      hasBlue = hasBlue,
      rgb = if (hasRgb) buildChannelLut(params.rgbPoints) else IDENTITY_LUT,
      red = if (hasRed) buildChannelLut(params.redPoints) else IDENTITY_LUT,
      green = if (hasGreen) buildChannelLut(params.greenPoints) else IDENTITY_LUT,
      blue = if (hasBlue) buildChannelLut(params.bluePoints) else IDENTITY_LUT,
    )
  }

  fun buildChannelLut(rawPoints: List<CurvePoint>): IntArray {
    val lut = IntArray(256)
    for (i in 0 until 256) {
      val x = i / 255f
      val y = evaluateMonotoneCurve(rawPoints, x)
      lut[i] = (y * 255f).roundToInt().coerceIn(0, 255)
    }
    return lut
  }

  fun evaluateMonotoneCurve(rawPoints: List<CurvePoint>, xQuery: Float): Float {
    val pts = ToneCurveParams.sanitizePoints(rawPoints)
    val n = pts.size
    if (xQuery <= pts[0].x) return pts[0].y.coerceIn(0f, 1f)
    if (xQuery >= pts[n - 1].x) return pts[n - 1].y.coerceIn(0f, 1f)
    if (n == 2) {
      val t = (xQuery - pts[0].x) / (pts[1].x - pts[0].x).coerceAtLeast(1e-5f)
      return (pts[0].y + t * (pts[1].y - pts[0].y)).coerceIn(0f, 1f)
    }

    // Secant slopes
    val d = FloatArray(n - 1)
    val h = FloatArray(n - 1)
    for (i in 0 until n - 1) {
      h[i] = (pts[i + 1].x - pts[i].x).coerceAtLeast(1e-5f)
      d[i] = (pts[i + 1].y - pts[i].y) / h[i]
    }

    // Initial tangents
    val m = FloatArray(n)
    m[0] = d[0]
    m[n - 1] = d[n - 2]
    for (i in 1 until n - 1) {
      m[i] =
        if (d[i - 1] * d[i] <= 0f) 0f
        else (d[i - 1] + d[i]) * 0.5f
    }

    // Fritsch-Carlson monotonicity clamp
    for (i in 0 until n - 1) {
      if (abs(d[i]) < 1e-6f) {
        m[i] = 0f
        m[i + 1] = 0f
      } else {
        val a = m[i] / d[i]
        val b = m[i + 1] / d[i]
        val sq = a * a + b * b
        if (sq > 9f) {
          val tau = 3f / sqrt(sq)
          m[i] = tau * a * d[i]
          m[i + 1] = tau * b * d[i]
        }
      }
    }

    // Locate segment
    var seg = 0
    for (i in 0 until n - 1) {
      if (xQuery >= pts[i].x && xQuery <= pts[i + 1].x) {
        seg = i
        break
      }
    }

    val span = h[seg]
    val t = ((xQuery - pts[seg].x) / span).coerceIn(0f, 1f)
    val t2 = t * t
    val t3 = t2 * t
    val h00 = 2f * t3 - 3f * t2 + 1f
    val h10 = t3 - 2f * t2 + t
    val h01 = -2f * t3 + 3f * t2
    val h11 = t3 - t2

    val y = h00 * pts[seg].y + h10 * span * m[seg] + h01 * pts[seg + 1].y + h11 * span * m[seg + 1]
    return y.coerceIn(0f, 1f)
  }

  // --- Tonal-Range Color Grading (Shadows / Midtones / Highlights) ---

  class GradingPrepared(
    val sTintR: Float, val sTintG: Float, val sTintB: Float, val sLum: Float, val hasShadows: Boolean,
    val mTintR: Float, val mTintG: Float, val mTintB: Float, val mLum: Float, val hasMidtones: Boolean,
    val hTintR: Float, val hTintG: Float, val hTintB: Float, val hLum: Float, val hasHighlights: Boolean,
  )

  fun prepareColorGrading(params: ColorGradingParams): GradingPrepared {
    val (sr, sg, sb) = wheelToTintOffset(params.shadows)
    val (mr, mg, mb) = wheelToTintOffset(params.midtones)
    val (hr, hg, hb) = wheelToTintOffset(params.highlights)
    return GradingPrepared(
      sTintR = sr, sTintG = sg, sTintB = sb, sLum = params.shadows.luminance * 65f, hasShadows = !params.shadows.isIdentity,
      mTintR = mr, mTintG = mg, mTintB = mb, mLum = params.midtones.luminance * 65f, hasMidtones = !params.midtones.isIdentity,
      hTintR = hr, hTintG = hg, hTintB = hb, hLum = params.highlights.luminance * 65f, hasHighlights = !params.highlights.isIdentity,
    )
  }

  private fun wheelToTintOffset(wheel: ColorGradeWheel): Triple<Float, Float, Float> {
    if (wheel.saturation <= 0.001f) return Triple(0f, 0f, 0f)
    val (r, g, b) = hslToRgb(wheel.hueDegrees, 1f, 0.5f)
    val strength = wheel.saturation * 120f
    return Triple((r - 0.5f) * strength, (g - 0.5f) * strength, (b - 0.5f) * strength)
  }

  fun applyColorGradingToRgb(
    rIn: Float,
    gIn: Float,
    bIn: Float,
    gPrep: GradingPrepared,
  ): Triple<Float, Float, Float> {
    val lum = ((0.299f * rIn + 0.587f * gIn + 0.114f * bIn) / 255f).coerceIn(0f, 1f)
    val wShadow = smoothstep(0.55f, 0.05f, lum)
    val wHighlight = smoothstep(0.45f, 0.95f, lum)
    val wMidtone = (1f - wShadow - wHighlight).coerceIn(0f, 1f)

    var r = rIn
    var g = gIn
    var b = bIn

    if (gPrep.hasShadows && wShadow > 0.001f) {
      r += (gPrep.sTintR + gPrep.sLum) * wShadow
      g += (gPrep.sTintG + gPrep.sLum) * wShadow
      b += (gPrep.sTintB + gPrep.sLum) * wShadow
    }
    if (gPrep.hasMidtones && wMidtone > 0.001f) {
      r += (gPrep.mTintR + gPrep.mLum) * wMidtone
      g += (gPrep.mTintG + gPrep.mLum) * wMidtone
      b += (gPrep.mTintB + gPrep.mLum) * wMidtone
    }
    if (gPrep.hasHighlights && wHighlight > 0.001f) {
      r += (gPrep.hTintR + gPrep.hLum) * wHighlight
      g += (gPrep.hTintG + gPrep.hLum) * wHighlight
      b += (gPrep.hTintB + gPrep.hLum) * wHighlight
    }
    return Triple(r, g, b)
  }

  fun hslToRgb(hueDeg: Float, sat: Float, light: Float): Triple<Float, Float, Float> {
    if (sat <= 1e-5f) return Triple(light, light, light)
    val h = (((hueDeg % 360f) + 360f) % 360f) / 360f
    val q = if (light < 0.5f) light * (1f + sat) else light + sat - light * sat
    val p = 2f * light - q
    val r = hueToChannel(p, q, h + 1f / 3f)
    val g = hueToChannel(p, q, h)
    val b = hueToChannel(p, q, h - 1f / 3f)
    return Triple(r, g, b)
  }

  private fun hueToChannel(p: Float, q: Float, tIn: Float): Float {
    var t = tIn
    if (t < 0f) t += 1f
    if (t > 1f) t -= 1f
    return when {
      t < 1f / 6f -> p + (q - p) * 6f * t
      t < 0.5f -> q
      t < 2f / 3f -> p + (q - p) * (2f / 3f - t) * 6f
      else -> p
    }
  }

  private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
    val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
    return t * t * (3f - 2f * t)
  }

  private val IDENTITY_LUT = IntArray(256) { it }
}
