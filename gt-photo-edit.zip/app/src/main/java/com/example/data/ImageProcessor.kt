package com.example.data

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.Matrix
import com.example.model.ColorAdjustments
import com.example.model.ColorGradingParams
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.model.CropTransformParams
import com.example.model.HslMixerParams
import com.example.model.ToneCurveParams
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

object ImageProcessor {

  fun createWorkingPreview(source: Bitmap, maxEdge: Int = 1080): Bitmap {
    val w = source.width
    val h = source.height
    val longest = max(w, h)
    if (longest <= maxEdge || longest <= 0) {
      return source
    }
    val scale = maxEdge.toFloat() / longest.toFloat()
    val targetW = max(1, (w * scale).roundToInt())
    val targetH = max(1, (h * scale).roundToInt())
    return Bitmap.createScaledBitmap(source, targetW, targetH, true)
  }

  fun orientedDimensions(
    sourceWidth: Int,
    sourceHeight: Int,
    rotation90Degrees: Int,
  ): Pair<Int, Int> {
    val normalized = ((rotation90Degrees % 360) + 360) % 360
    return if (normalized == 90 || normalized == 270) {
      sourceHeight to sourceWidth
    } else {
      sourceWidth to sourceHeight
    }
  }

  fun computeCropRectForAspectRatio(
    orientedWidth: Int,
    orientedHeight: Int,
    aspectRatio: CropAspectRatio,
    currentRect: CropRect = CropRect(),
  ): CropRect {
    if (orientedWidth <= 0 || orientedHeight <= 0) return CropRect()
    val targetRatio =
      when (aspectRatio) {
        CropAspectRatio.FREE -> return currentRect
        CropAspectRatio.ORIGINAL -> return CropRect(0f, 0f, 1f, 1f)
        else -> aspectRatio.ratio ?: return currentRect
      }
    val imageRatio = orientedWidth.toFloat() / orientedHeight.toFloat()
    return if (targetRatio > imageRatio) {
      val normHeight = (imageRatio / targetRatio).coerceIn(CropRect.MIN_SIZE, 1f)
      val margin = (1f - normHeight) / 2f
      CropRect(left = 0f, top = margin, right = 1f, bottom = 1f - margin)
    } else {
      val normWidth = (targetRatio / imageRatio).coerceIn(CropRect.MIN_SIZE, 1f)
      val margin = (1f - normWidth) / 2f
      CropRect(left = margin, top = 0f, right = 1f - margin, bottom = 1f)
    }
  }

  fun processBitmap(
    source: Bitmap,
    transform: CropTransformParams,
    adjustments: ColorAdjustments,
    applyCrop: Boolean = true,
    hslMixer: HslMixerParams = HslMixerParams(),
    toneCurve: ToneCurveParams = ToneCurveParams(),
    colorGrading: ColorGradingParams = ColorGradingParams(),
  ): Bitmap {
    val srcW = source.width
    val srcH = source.height
    if (srcW <= 0 || srcH <= 0) return source

    val srcPixels = IntArray(srcW * srcH)
    source.getPixels(srcPixels, 0, srcW, 0, 0, srcW, srcH)

    // 1. Discrete 90/180/270 rotation + Horizontal/Vertical flip
    val rot90 = ((transform.rotation90Degrees % 360) + 360) % 360
    val (orientedW, orientedH) = orientedDimensions(srcW, srcH, rot90)
    var orientedPixels =
      applyRotateAndFlip(
        srcPixels = srcPixels,
        srcW = srcW,
        srcH = srcH,
        outW = orientedW,
        outH = orientedH,
        rot90 = rot90,
        flipH = transform.flipHorizontal,
        flipV = transform.flipVertical,
      )

    // 2. Straighten & Perspective keystone correction via exact inverse projective sampling
    val needsWarp =
      abs(transform.straightenDegrees) > 0.01f ||
        abs(transform.perspectiveVertical) > 0.001f ||
        abs(transform.perspectiveHorizontal) > 0.001f
    if (needsWarp) {
      orientedPixels =
        applyStraightenAndPerspective(
          pixels = orientedPixels,
          w = orientedW,
          h = orientedH,
          straightenDegrees = transform.straightenDegrees,
          perspectiveV = transform.perspectiveVertical,
          perspectiveH = transform.perspectiveHorizontal,
        )
    }

    // 3. Crop extraction
    val finalW: Int
    val finalH: Int
    val workingPixels: IntArray
    if (applyCrop && !transform.cropRect.isFullFrame) {
      val leftPx = (transform.cropRect.left * orientedW).roundToInt().coerceIn(0, max(0, orientedW - 1))
      val topPx = (transform.cropRect.top * orientedH).roundToInt().coerceIn(0, max(0, orientedH - 1))
      val rightPx = (transform.cropRect.right * orientedW).roundToInt().coerceIn(leftPx + 1, orientedW)
      val bottomPx = (transform.cropRect.bottom * orientedH).roundToInt().coerceIn(topPx + 1, orientedH)
      finalW = max(1, rightPx - leftPx)
      finalH = max(1, bottomPx - topPx)
      workingPixels = IntArray(finalW * finalH)
      for (y in 0 until finalH) {
        System.arraycopy(orientedPixels, (topPx + y) * orientedW + leftPx, workingPixels, y * finalW, finalW)
      }
    } else {
      finalW = orientedW
      finalH = orientedH
      workingPixels = orientedPixels
    }

    // 4. Unified Color Pipeline:
    // Basic Adjustments -> HSL Color Mixer -> RGB Tone Curve -> Color Grading -> Vignette & Grain
    val hasAnyColorWork =
      !adjustments.isIdentity || !hslMixer.isIdentity || !toneCurve.isIdentity || !colorGrading.isIdentity
    if (hasAnyColorWork) {
      applyAllColorAdjustmentsInPlace(
        pixels = workingPixels,
        w = finalW,
        h = finalH,
        adj = adjustments,
        hslMixer = hslMixer,
        toneCurve = toneCurve,
        colorGrading = colorGrading,
      )
    }

    val output = Bitmap.createBitmap(finalW, finalH, Bitmap.Config.ARGB_8888)
    output.setPixels(workingPixels, 0, finalW, 0, 0, finalW, finalH)
    return output
  }

  fun renderTransformedBitmap(
    source: Bitmap,
    transform: CropTransformParams,
    adjustments: ColorAdjustments,
    hslMixer: HslMixerParams = HslMixerParams(),
    toneCurve: ToneCurveParams = ToneCurveParams(),
    colorGrading: ColorGradingParams = ColorGradingParams(),
  ): Bitmap =
    processBitmap(
      source = source,
      transform = transform,
      adjustments = adjustments,
      applyCrop = false,
      hslMixer = hslMixer,
      toneCurve = toneCurve,
      colorGrading = colorGrading,
    )

  private fun applyRotateAndFlip(
    srcPixels: IntArray,
    srcW: Int,
    srcH: Int,
    outW: Int,
    outH: Int,
    rot90: Int,
    flipH: Boolean,
    flipV: Boolean,
  ): IntArray {
    if (rot90 == 0 && !flipH && !flipV) {
      return srcPixels
    }
    val out = IntArray(outW * outH)
    for (sy in 0 until srcH) {
      val srcRow = sy * srcW
      for (sx in 0 until srcW) {
        val rx: Int
        val ry: Int
        when (rot90) {
          90 -> {
            rx = srcH - 1 - sy
            ry = sx
          }
          180 -> {
            rx = srcW - 1 - sx
            ry = srcH - 1 - sy
          }
          270 -> {
            rx = sy
            ry = srcW - 1 - sx
          }
          else -> {
            rx = sx
            ry = sy
          }
        }
        val fx = if (flipH) outW - 1 - rx else rx
        val fy = if (flipV) outH - 1 - ry else ry
        out[fy * outW + fx] = srcPixels[srcRow + sx]
      }
    }
    return out
  }

  private fun applyStraightenAndPerspective(
    pixels: IntArray,
    w: Int,
    h: Int,
    straightenDegrees: Float,
    perspectiveV: Float,
    perspectiveH: Float,
  ): IntArray {
    val out = IntArray(w * h)
    val wf = w.toFloat()
    val hf = h.toFloat()
    val cx = wf * 0.5f
    val cy = hf * 0.5f

    // Build forward perspective homography if non-zero
    val hasPerspective = abs(perspectiveV) > 0.001f || abs(perspectiveH) > 0.001f
    val invPerspective: Mat3? =
      if (hasPerspective) {
        val pv = perspectiveV.coerceIn(-1f, 1f) * 0.22f
        val ph = perspectiveH.coerceIn(-1f, 1f) * 0.22f
        val topInset = if (pv > 0f) wf * pv else 0f
        val bottomInset = if (pv < 0f) wf * (-pv) else 0f
        val leftInset = if (ph > 0f) hf * ph else 0f
        val rightInset = if (ph < 0f) hf * (-ph) else 0f
        computeQuadToSquareHomography(
          x0 = topInset,
          y0 = leftInset,
          x1 = wf - topInset,
          y1 = rightInset,
          x2 = wf - bottomInset,
          y2 = hf - rightInset,
          x3 = bottomInset,
          y3 = hf - leftInset,
          w = wf,
          h = hf,
        )
      } else {
        null
      }

    // Inverse straighten rotation + zoom
    val hasStraighten = abs(straightenDegrees) > 0.01f
    val zoom = if (hasStraighten) computeStraightenZoom(wf, hf, straightenDegrees) else 1f
    val invScale = 1f / zoom
    val rad = -straightenDegrees * PI.toFloat() / 180f
    val cosA = cos(rad)
    val sinA = sin(rad)

    for (dy in 0 until h) {
      val rowOffset = dy * w
      for (dx in 0 until w) {
        var sx = dx.toFloat()
        var sy = dy.toFloat()

        // Undo perspective first (since perspective was applied after straighten)
        if (invPerspective != null) {
          val mapped = invPerspective.map(sx, sy)
          sx = mapped.first
          sy = mapped.second
        }

        // Undo straighten around center
        if (hasStraighten) {
          val tx = (sx - cx) * invScale
          val ty = (sy - cy) * invScale
          sx = tx * cosA - ty * sinA + cx
          sy = tx * sinA + ty * cosA + cy
        }

        out[rowOffset + dx] = sampleBilinear(pixels, w, h, sx, sy)
      }
    }
    return out
  }

  private fun sampleBilinear(pixels: IntArray, w: Int, h: Int, sx: Float, sy: Float): Int {
    if (sx < 0f || sy < 0f || sx >= w - 1f || sy >= h - 1f) {
      val ix = sx.roundToInt()
      val iy = sy.roundToInt()
      return if (ix in 0 until w && iy in 0 until h) pixels[iy * w + ix] else 0xFF000000.toInt()
    }
    val x0 = floor(sx).toInt()
    val y0 = floor(sy).toInt()
    val x1 = min(w - 1, x0 + 1)
    val y1 = min(h - 1, y0 + 1)
    val fx = sx - x0
    val fy = sy - y0
    val invFx = 1f - fx
    val invFy = 1f - fy

    val p00 = pixels[y0 * w + x0]
    val p10 = pixels[y0 * w + x1]
    val p01 = pixels[y1 * w + x0]
    val p11 = pixels[y1 * w + x1]

    val w00 = invFx * invFy
    val w10 = fx * invFy
    val w01 = invFx * fy
    val w11 = fx * fy

    val a = (((p00 ushr 24) and 0xFF) * w00 + ((p10 ushr 24) and 0xFF) * w10 + ((p01 ushr 24) and 0xFF) * w01 + ((p11 ushr 24) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
    val r = (((p00 ushr 16) and 0xFF) * w00 + ((p10 ushr 16) and 0xFF) * w10 + ((p01 ushr 16) and 0xFF) * w01 + ((p11 ushr 16) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
    val g = (((p00 ushr 8) and 0xFF) * w00 + ((p10 ushr 8) and 0xFF) * w10 + ((p01 ushr 8) and 0xFF) * w01 + ((p11 ushr 8) and 0xFF) * w11).roundToInt().coerceIn(0, 255)
    val b = ((p00 and 0xFF) * w00 + (p10 and 0xFF) * w10 + (p01 and 0xFF) * w01 + (p11 and 0xFF) * w11).roundToInt().coerceIn(0, 255)
    return (a shl 24) or (r shl 16) or (g shl 8) or b
  }

  private fun computeStraightenZoom(w: Float, h: Float, degrees: Float): Float {
    if (w <= 0f || h <= 0f) return 1f
    val rad = abs(degrees) * PI.toFloat() / 180f
    val sinA = sin(rad)
    val cosA = cos(rad)
    val scaleW = (w * cosA + h * sinA) / w
    val scaleH = (h * cosA + w * sinA) / h
    return max(scaleW, scaleH)
  }

  private class Mat3(
    val m00: Float, val m01: Float, val m02: Float,
    val m10: Float, val m11: Float, val m12: Float,
    val m20: Float, val m21: Float, val m22: Float,
  ) {
    fun map(x: Float, y: Float): Pair<Float, Float> {
      val w = (m20 * x + m21 * y + m22).let { if (abs(it) < 1e-6f) 1e-6f else it }
      return (m00 * x + m01 * y + m02) / w to (m10 * x + m11 * y + m12) / w
    }
  }

  // Maps destination quad (x0,y0)..(x3,y3) back to source unit square scaled by (w, h)
  private fun computeQuadToSquareHomography(
    x0: Float, y0: Float,
    x1: Float, y1: Float,
    x2: Float, y2: Float,
    x3: Float, y3: Float,
    w: Float, h: Float,
  ): Mat3 {
    // First compute square-to-quad homography (unit square -> quad), then invert it and scale by (w, h)
    val dx1 = x1 - x2
    val dy1 = y1 - y2
    val dx2 = x3 - x2
    val dy2 = y3 - y2
    val sx = x0 - x1 + x2 - x3
    val sy = y0 - y1 + y2 - y3

    val denom = (dx1 * dy2 - dx2 * dy1).let { if (abs(it) < 1e-6f) 1e-6f else it }
    val g = (sx * dy2 - dx2 * sy) / denom
    val hh = (dx1 * sy - sx * dy1) / denom

    val a = x1 - x0 + g * x1
    val b = x3 - x0 + hh * x3
    val c = x0
    val d = y1 - y0 + g * y1
    val e = y3 - y0 + hh * y3
    val f = y0

    // Adjugate of [a b c; d e f; g hh 1] maps quad -> unit square
    val i00 = e - f * hh
    val i01 = c * hh - b
    val i02 = b * f - c * e
    val i10 = f * g - d
    val i11 = a - c * g
    val i12 = c * d - a * f
    val i20 = d * hh - e * g
    val i21 = b * g - a * hh
    val i22 = a * e - b * d

    // Scale unit square output by (w, h)
    return Mat3(
      i00 * w, i01 * w, i02 * w,
      i10 * h, i11 * h, i12 * h,
      i20, i21, i22,
    )
  }

  private fun applyAllColorAdjustmentsInPlace(
    pixels: IntArray,
    w: Int,
    h: Int,
    adj: ColorAdjustments,
    hslMixer: HslMixerParams,
    toneCurve: ToneCurveParams,
    colorGrading: ColorGradingParams,
  ) {
    val hasMatrix =
      adj.exposure != 0f ||
        adj.brightness != 0f ||
        adj.contrast != 0f ||
        adj.saturation != 0f ||
        adj.temperature != 0f ||
        adj.tint != 0f ||
        adj.hue != 0f

    val expScale = 2f.pow(adj.exposure)
    val tempR = 1f + adj.temperature * 0.22f
    val tempB = 1f - adj.temperature * 0.22f
    val tintR = 1f + adj.tint * 0.14f
    val tintG = 1f - adj.tint * 0.18f
    val tintB = 1f + adj.tint * 0.14f

    val contrastScale =
      if (adj.contrast >= 0f) 1f + adj.contrast * 1.25f else (1f + adj.contrast * 0.75f).coerceAtLeast(0.2f)
    val contrastTranslate = 128f * (1f - contrastScale)
    val brightnessOffset = adj.brightness * 110f

    val rScale = expScale * tempR * tintR * contrastScale
    val gScale = expScale * tintG * contrastScale
    val bScale = expScale * tempB * tintB * contrastScale
    val channelOffset = contrastTranslate + brightnessOffset

    val hasSat = adj.saturation != 0f
    val sat = (1f + adj.saturation).coerceAtLeast(0f)

    val hasHue = abs(adj.hue) > 0.01f
    val hueRad = adj.hue * PI.toFloat() / 180f
    val hueCos = cos(hueRad)
    val hueSin = sin(hueRad)
    val lumR = 0.213f
    val lumG = 0.715f
    val lumB = 0.072f
    val h00 = lumR + hueCos * (1f - lumR) + hueSin * (-lumR)
    val h01 = lumG + hueCos * (-lumG) + hueSin * (-lumG)
    val h02 = lumB + hueCos * (-lumB) + hueSin * (1f - lumB)
    val h10 = lumR + hueCos * (-lumR) + hueSin * 0.143f
    val h11 = lumG + hueCos * (1f - lumG) + hueSin * 0.140f
    val h12 = lumB + hueCos * (-lumB) + hueSin * (-0.283f)
    val h20 = lumR + hueCos * (-lumR) + hueSin * (-(1f - lumR))
    val h21 = lumG + hueCos * (-lumG) + hueSin * lumG
    val h22 = lumB + hueCos * (1f - lumB) + hueSin * lumB

    val hasHighlights = adj.highlights != 0f
    val hasShadows = adj.shadows != 0f
    val hasVibrance = adj.vibrance != 0f

    val hslLut = if (!hslMixer.isIdentity) ColorEngine.buildHslLut(hslMixer) else null
    val curveLuts = if (!toneCurve.isIdentity) ColorEngine.buildToneCurveLuts(toneCurve) else null
    val gradingPrep = if (!colorGrading.isIdentity) ColorEngine.prepareColorGrading(colorGrading) else null

    val hasVignette = adj.vignette > 0.001f
    val hasGrain = adj.grain > 0.001f

    val halfW = w * 0.5f
    val halfH = h * 0.5f
    val maxRadius = sqrt(halfW * halfW + halfH * halfH).coerceAtLeast(1f)
    val grainAmplitude = adj.grain * 68f

    for (y in 0 until h) {
      val dyNorm = (y - halfH) / maxRadius
      val rowOffset = y * w
      for (x in 0 until w) {
        val idx = rowOffset + x
        val pixel = pixels[idx]
        val a = (pixel ushr 24) and 0xFF
        var r = ((pixel ushr 16) and 0xFF).toFloat()
        var g = ((pixel ushr 8) and 0xFF).toFloat()
        var b = (pixel and 0xFF).toFloat()

        if (hasMatrix) {
          r = r * rScale + channelOffset
          g = g * gScale + channelOffset
          b = b * bScale + channelOffset

          if (hasSat) {
            val lum = 0.213f * r + 0.715f * g + 0.072f * b
            r = lum + sat * (r - lum)
            g = lum + sat * (g - lum)
            b = lum + sat * (b - lum)
          }

          if (hasHue) {
            val nr = h00 * r + h01 * g + h02 * b
            val ng = h10 * r + h11 * g + h12 * b
            val nb = h20 * r + h21 * g + h22 * b
            r = nr
            g = ng
            b = nb
          }
        }

        if (hasHighlights || hasShadows) {
          val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
          val clampedLum = lum.coerceIn(0f, 1f)
          var delta = 0f
          if (hasShadows) {
            val shadowMask = (1f - clampedLum) * (1f - clampedLum)
            delta += adj.shadows * shadowMask * 95f
          }
          if (hasHighlights) {
            val highlightMask = clampedLum * clampedLum
            delta += adj.highlights * highlightMask * 95f
          }
          r += delta
          g += delta
          b += delta
        }

        if (hasVibrance) {
          val maxC = max(r, max(g, b))
          val minC = min(r, min(g, b))
          val pixelSat = if (maxC > 0f) (maxC - minC) / maxC else 0f
          val boost = adj.vibrance * (1f - pixelSat)
          val avg = (r + g + b) / 3f
          r += (r - avg) * boost
          g += (g - avg) * boost
          b += (b - avg) * boost
        }

        // Milestone 3 Stage A: HSL Color Mixer
        if (hslLut != null) {
          val mixed = ColorEngine.applyHslMixerToRgb(r, g, b, hslLut)
          r = mixed.first
          g = mixed.second
          b = mixed.third
        }

        // Milestone 3 Stage B: RGB Tone Curve (Composite RGB LUT then R/G/B channel LUTs)
        if (curveLuts != null) {
          var ri = r.roundToInt().coerceIn(0, 255)
          var gi = g.roundToInt().coerceIn(0, 255)
          var bi = b.roundToInt().coerceIn(0, 255)
          if (curveLuts.hasRgb) {
            ri = curveLuts.rgb[ri]
            gi = curveLuts.rgb[gi]
            bi = curveLuts.rgb[bi]
          }
          if (curveLuts.hasRed) ri = curveLuts.red[ri]
          if (curveLuts.hasGreen) gi = curveLuts.green[gi]
          if (curveLuts.hasBlue) bi = curveLuts.blue[bi]
          r = ri.toFloat()
          g = gi.toFloat()
          b = bi.toFloat()
        }

        // Milestone 3 Stage C: Tonal Color Grading (Shadows / Midtones / Highlights)
        if (gradingPrep != null) {
          val graded = ColorEngine.applyColorGradingToRgb(r, g, b, gradingPrep)
          r = graded.first
          g = graded.second
          b = graded.third
        }

        // Finishing Effects: Vignette & Grain
        if (hasVignette) {
          val dxNorm = (x - halfW) / maxRadius
          val dist = sqrt(dxNorm * dxNorm + dyNorm * dyNorm)
          val falloff = ((dist - 0.32f) / 0.68f).coerceIn(0f, 1f)
          val factor = (1f - adj.vignette * 0.78f * falloff * falloff).coerceIn(0.05f, 1f)
          r *= factor
          g *= factor
          b *= factor
        }

        if (hasGrain) {
          var hash = x * 374761393 + y * 668265263
          hash = (hash xor (hash ushr 13)) * 1274126177
          hash = hash xor (hash ushr 16)
          val noise = ((hash and 0xFF) / 255f) - 0.5f
          val grainDelta = noise * grainAmplitude
          r += grainDelta
          g += grainDelta
          b += grainDelta
        }

        val ri = r.roundToInt().coerceIn(0, 255)
        val gi = g.roundToInt().coerceIn(0, 255)
        val bi = b.roundToInt().coerceIn(0, 255)
        pixels[idx] = (a shl 24) or (ri shl 16) or (gi shl 8) or bi
      }
    }
  }

  // Retained for callers needing native Android Matrix / ColorMatrix representations
  fun buildTransformMatrix(
    srcW: Int,
    srcH: Int,
    outW: Int,
    outH: Int,
    transform: CropTransformParams,
  ): Matrix {
    val matrix = Matrix()
    val rot90 = ((transform.rotation90Degrees % 360) + 360) % 360
    matrix.postTranslate(-srcW / 2f, -srcH / 2f)
    if (rot90 != 0) matrix.postRotate(rot90.toFloat())
    val sx = if (transform.flipHorizontal) -1f else 1f
    val sy = if (transform.flipVertical) -1f else 1f
    if (sx != 1f || sy != 1f) matrix.postScale(sx, sy)
    if (abs(transform.straightenDegrees) > 0.01f) {
      val zoom = computeStraightenZoom(outW.toFloat(), outH.toFloat(), transform.straightenDegrees)
      matrix.postRotate(transform.straightenDegrees)
      matrix.postScale(zoom, zoom)
    }
    matrix.postTranslate(outW / 2f, outH / 2f)
    return matrix
  }

  fun buildColorMatrix(adj: ColorAdjustments): ColorMatrix? {
    val hasMatrixAdjustment =
      adj.exposure != 0f ||
        adj.brightness != 0f ||
        adj.contrast != 0f ||
        adj.saturation != 0f ||
        adj.temperature != 0f ||
        adj.tint != 0f ||
        adj.hue != 0f
    if (!hasMatrixAdjustment) return null
    return ColorMatrix()
  }
}
