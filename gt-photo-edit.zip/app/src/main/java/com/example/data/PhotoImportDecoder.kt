package com.example.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.example.model.ImportedPhoto
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface PhotoDecoder {
  suspend fun decode(uri: Uri): Result<ImportedPhoto>

  suspend fun decodeFullResolution(uri: Uri): Result<ImportedPhoto> = decode(uri)
}

class AndroidPhotoDecoder(
  private val context: Context,
  private val maxPreviewDimension: Int = DEFAULT_MAX_DIMENSION,
) : PhotoDecoder {

  override suspend fun decode(uri: Uri): Result<ImportedPhoto> =
    decodeInternal(uri, maxEdgeLimit = maxPreviewDimension)

  override suspend fun decodeFullResolution(uri: Uri): Result<ImportedPhoto> =
    decodeInternal(uri, maxEdgeLimit = Int.MAX_VALUE)

  private suspend fun decodeInternal(uri: Uri, maxEdgeLimit: Int): Result<ImportedPhoto> =
    withContext(Dispatchers.IO) {
      runCatching {
        val resolver = context.contentResolver
        val displayName = queryDisplayName(uri) ?: "Imported Photo"
        val (origWidth, origHeight) = readBounds(uri)

        val bitmap =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(resolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
              decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
              val w = info.size.width
              val h = info.size.height
              val maxEdge = max(w, h)
              if (maxEdge > maxEdgeLimit && maxEdge > 0) {
                val scale = maxEdgeLimit.toFloat() / maxEdge.toFloat()
                decoder.setTargetSize(
                  max(1, (w * scale).roundToInt()),
                  max(1, (h * scale).roundToInt()),
                )
              }
            }
          } else {
            val sampleSize =
              if (maxEdgeLimit == Int.MAX_VALUE) 1
              else calculateInSampleSize(origWidth, origHeight, maxEdgeLimit)
            val options =
              BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
              }
            resolver.openInputStream(uri)?.use { stream ->
              BitmapFactory.decodeStream(stream, null, options)
            } ?: error("Unable to open selected image stream.")
          }

        val resolvedWidth = if (origWidth > 0) origWidth else bitmap.width
        val resolvedHeight = if (origHeight > 0) origHeight else bitmap.height

        ImportedPhoto(
          uriString = uri.toString(),
          displayName = displayName,
          originalWidth = resolvedWidth,
          originalHeight = resolvedHeight,
          bitmap = bitmap,
        )
      }
    }

  private fun queryDisplayName(uri: Uri): String? {
    return runCatching {
        context.contentResolver
          .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
          ?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
          }
      }
      .getOrNull()
  }

  private fun readBounds(uri: Uri): Pair<Int, Int> {
    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { stream ->
      BitmapFactory.decodeStream(stream, null, options)
    }
    return options.outWidth to options.outHeight
  }

  private fun calculateInSampleSize(width: Int, height: Int, maxEdge: Int): Int {
    var sample = 1
    var currentMax = max(width, height)
    while (currentMax / 2 >= maxEdge) {
      sample *= 2
      currentMax /= 2
    }
    return sample
  }

  companion object {
    const val DEFAULT_MAX_DIMENSION = 1600
  }
}
