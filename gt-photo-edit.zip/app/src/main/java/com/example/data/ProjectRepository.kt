package com.example.data

import android.content.Context
import com.example.model.ColorAdjustments
import com.example.model.ColorGradeWheel
import com.example.model.ColorGradingParams
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.model.CropTransformParams
import com.example.model.CurvePoint
import com.example.model.EditorCategory
import com.example.model.EditorFont
import com.example.model.EditorSnapshot
import com.example.model.HslAdjustment
import com.example.model.HslColorRange
import com.example.model.HslMixerParams
import com.example.model.SavedProject
import com.example.model.SavedProjectSummary
import com.example.model.TextLayer
import com.example.model.ToneCurveParams
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

interface ProjectRepository {
  suspend fun saveProject(project: SavedProject): Result<SavedProjectSummary>

  suspend fun loadProject(projectId: String): Result<SavedProject>

  suspend fun listProjects(): Result<List<SavedProjectSummary>>

  suspend fun deleteProject(projectId: String): Result<Unit>
}

class LocalProjectRepository(
  private val context: Context,
  private val ioDispatcher: kotlinx.coroutines.CoroutineDispatcher = Dispatchers.IO,
) : ProjectRepository {

  private val projectsDir: File
    get() = File(context.filesDir, PROJECTS_DIR_NAME).apply { mkdirs() }

  override suspend fun saveProject(project: SavedProject): Result<SavedProjectSummary> =
    withContext(ioDispatcher) {
      runCatching {
        val safeId = sanitizeFileId(project.id)
        val json = serializeProject(project)
        val dir = projectsDir
        val tmpFile = File(dir, "$safeId.json.tmp")
        val targetFile = File(dir, "$safeId.json")
        tmpFile.writeText(json.toString(2), Charsets.UTF_8)
        if (!tmpFile.renameTo(targetFile)) {
          targetFile.writeText(json.toString(2), Charsets.UTF_8)
          tmpFile.delete()
        }
        project.toSummary()
      }
    }

  override suspend fun loadProject(projectId: String): Result<SavedProject> =
    withContext(ioDispatcher) {
      runCatching {
        val safeId = sanitizeFileId(projectId)
        val file = File(projectsDir, "$safeId.json")
        if (!file.exists()) {
          error("Saved project file not found.")
        }
        val json = JSONObject(file.readText(Charsets.UTF_8))
        deserializeProject(json)
      }
    }

  override suspend fun listProjects(): Result<List<SavedProjectSummary>> =
    withContext(ioDispatcher) {
      runCatching {
        val files = projectsDir.listFiles { file -> file.isFile && file.name.endsWith(".json") }.orEmpty()
        files
          .mapNotNull { file ->
            runCatching {
              val project = deserializeProject(JSONObject(file.readText(Charsets.UTF_8)))
              project.toSummary()
            }.getOrNull()
          }
          .sortedByDescending { it.updatedAtMillis }
      }
    }

  override suspend fun deleteProject(projectId: String): Result<Unit> =
    withContext(ioDispatcher) {
      runCatching {
        val safeId = sanitizeFileId(projectId)
        val file = File(projectsDir, "$safeId.json")
        if (file.exists()) {
          file.delete()
        }
        Unit
      }
    }

  private fun sanitizeFileId(id: String): String =
    id.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "project" }

  private fun SavedProject.toSummary(): SavedProjectSummary =
    SavedProjectSummary(
      id = id,
      name = name,
      sourceDisplayName = sourceDisplayName,
      originalWidth = originalWidth,
      originalHeight = originalHeight,
      updatedAtMillis = updatedAtMillis,
      layerCount = snapshot.textLayers.size,
    )

  companion object {
    private const val PROJECTS_DIR_NAME = "gt_projects"

    fun serializeProject(project: SavedProject): JSONObject {
      val root = JSONObject()
      root.put("version", 1)
      root.put("id", project.id)
      root.put("name", project.name)
      root.put("sourceUriString", project.sourceUriString)
      root.put("sourceDisplayName", project.sourceDisplayName)
      root.put("originalWidth", project.originalWidth)
      root.put("originalHeight", project.originalHeight)
      root.put("updatedAtMillis", project.updatedAtMillis)
      root.put("activeCategory", project.activeCategory.name)

      val snap = project.snapshot
      root.put("cropTransform", serializeTransform(snap.cropTransform))
      root.put("colorAdjustments", serializeAdjustments(snap.colorAdjustments))
      root.put("hslMixer", serializeHsl(snap.hslMixer))
      root.put("toneCurve", serializeToneCurve(snap.toneCurve))
      root.put("colorGrading", serializeColorGrading(snap.colorGrading))
      root.put("textLayers", serializeTextLayers(snap.textLayers))
      if (snap.selectedLayerId != null) {
        root.put("selectedLayerId", snap.selectedLayerId)
      } else {
        root.put("selectedLayerId", JSONObject.NULL)
      }
      return root
    }

    fun deserializeProject(root: JSONObject): SavedProject {
      val category =
        runCatching { EditorCategory.valueOf(root.optString("activeCategory", EditorCategory.PHOTO.name)) }
          .getOrDefault(EditorCategory.PHOTO)

      val selectedRaw =
        if (root.isNull("selectedLayerId")) null
        else root.optString("selectedLayerId").takeIf { it.isNotBlank() }

      val snapshot =
        EditorSnapshot(
          cropTransform = deserializeTransform(root.optJSONObject("cropTransform")),
          colorAdjustments = deserializeAdjustments(root.optJSONObject("colorAdjustments")),
          hslMixer = deserializeHsl(root.optJSONObject("hslMixer")),
          toneCurve = deserializeToneCurve(root.optJSONObject("toneCurve")),
          colorGrading = deserializeColorGrading(root.optJSONObject("colorGrading")),
          textLayers = deserializeTextLayers(root.optJSONArray("textLayers")),
          selectedLayerId = selectedRaw,
        )

      return SavedProject(
        id = root.getString("id"),
        name = root.optString("name", "Untitled Project"),
        sourceUriString = root.optString("sourceUriString", ""),
        sourceDisplayName = root.optString("sourceDisplayName", "Photo"),
        originalWidth = root.optInt("originalWidth", 0),
        originalHeight = root.optInt("originalHeight", 0),
        updatedAtMillis = root.optLong("updatedAtMillis", 0L),
        activeCategory = category,
        snapshot = snapshot,
      )
    }

    private fun serializeTransform(t: CropTransformParams): JSONObject =
      JSONObject().apply {
        put(
          "cropRect",
          JSONObject().apply {
            put("left", t.cropRect.left.toDouble())
            put("top", t.cropRect.top.toDouble())
            put("right", t.cropRect.right.toDouble())
            put("bottom", t.cropRect.bottom.toDouble())
          },
        )
        put("aspectRatio", t.aspectRatio.name)
        put("rotation90Degrees", t.rotation90Degrees)
        put("flipHorizontal", t.flipHorizontal)
        put("flipVertical", t.flipVertical)
        put("straightenDegrees", t.straightenDegrees.toDouble())
        put("perspectiveVertical", t.perspectiveVertical.toDouble())
        put("perspectiveHorizontal", t.perspectiveHorizontal.toDouble())
      }

    private fun deserializeTransform(obj: JSONObject?): CropTransformParams {
      if (obj == null) return CropTransformParams()
      val rectObj = obj.optJSONObject("cropRect")
      val cropRect =
        if (rectObj != null) {
          CropRect(
            left = rectObj.optDouble("left", 0.0).toFloat(),
            top = rectObj.optDouble("top", 0.0).toFloat(),
            right = rectObj.optDouble("right", 1.0).toFloat(),
            bottom = rectObj.optDouble("bottom", 1.0).toFloat(),
          )
        } else {
          CropRect()
        }
      val aspect =
        runCatching { CropAspectRatio.valueOf(obj.optString("aspectRatio", CropAspectRatio.FREE.name)) }
          .getOrDefault(CropAspectRatio.FREE)
      return CropTransformParams(
        cropRect = cropRect,
        aspectRatio = aspect,
        rotation90Degrees = obj.optInt("rotation90Degrees", 0),
        flipHorizontal = obj.optBoolean("flipHorizontal", false),
        flipVertical = obj.optBoolean("flipVertical", false),
        straightenDegrees = obj.optDouble("straightenDegrees", 0.0).toFloat(),
        perspectiveVertical = obj.optDouble("perspectiveVertical", 0.0).toFloat(),
        perspectiveHorizontal = obj.optDouble("perspectiveHorizontal", 0.0).toFloat(),
      )
    }

    private fun serializeAdjustments(a: ColorAdjustments): JSONObject =
      JSONObject().apply {
        put("brightness", a.brightness.toDouble())
        put("contrast", a.contrast.toDouble())
        put("saturation", a.saturation.toDouble())
        put("exposure", a.exposure.toDouble())
        put("highlights", a.highlights.toDouble())
        put("shadows", a.shadows.toDouble())
        put("temperature", a.temperature.toDouble())
        put("tint", a.tint.toDouble())
        put("vibrance", a.vibrance.toDouble())
        put("hue", a.hue.toDouble())
        put("vignette", a.vignette.toDouble())
        put("grain", a.grain.toDouble())
      }

    private fun deserializeAdjustments(obj: JSONObject?): ColorAdjustments {
      if (obj == null) return ColorAdjustments()
      return ColorAdjustments(
        brightness = obj.optDouble("brightness", 0.0).toFloat(),
        contrast = obj.optDouble("contrast", 0.0).toFloat(),
        saturation = obj.optDouble("saturation", 0.0).toFloat(),
        exposure = obj.optDouble("exposure", 0.0).toFloat(),
        highlights = obj.optDouble("highlights", 0.0).toFloat(),
        shadows = obj.optDouble("shadows", 0.0).toFloat(),
        temperature = obj.optDouble("temperature", 0.0).toFloat(),
        tint = obj.optDouble("tint", 0.0).toFloat(),
        vibrance = obj.optDouble("vibrance", 0.0).toFloat(),
        hue = obj.optDouble("hue", 0.0).toFloat(),
        vignette = obj.optDouble("vignette", 0.0).toFloat(),
        grain = obj.optDouble("grain", 0.0).toFloat(),
      )
    }

    private fun serializeHsl(hsl: HslMixerParams): JSONObject =
      JSONObject().apply {
        hsl.ranges.forEach { (range, adj) ->
          put(
            range.name,
            JSONObject().apply {
              put("hue", adj.hue.toDouble())
              put("saturation", adj.saturation.toDouble())
              put("luminance", adj.luminance.toDouble())
            },
          )
        }
      }

    private fun deserializeHsl(obj: JSONObject?): HslMixerParams {
      if (obj == null) return HslMixerParams()
      var result = HslMixerParams()
      HslColorRange.entries.forEach { range ->
        val rangeObj = obj.optJSONObject(range.name)
        if (rangeObj != null) {
          result =
            result.withRange(
              range,
              HslAdjustment(
                hue = rangeObj.optDouble("hue", 0.0).toFloat(),
                saturation = rangeObj.optDouble("saturation", 0.0).toFloat(),
                luminance = rangeObj.optDouble("luminance", 0.0).toFloat(),
              ),
            )
        }
      }
      return result
    }

    private fun serializeToneCurve(tc: ToneCurveParams): JSONObject =
      JSONObject().apply {
        put("rgb", serializeCurvePoints(tc.rgbPoints))
        put("red", serializeCurvePoints(tc.redPoints))
        put("green", serializeCurvePoints(tc.greenPoints))
        put("blue", serializeCurvePoints(tc.bluePoints))
      }

    private fun serializeCurvePoints(points: List<CurvePoint>): JSONArray =
      JSONArray().apply {
        points.forEach { pt ->
          put(
            JSONObject().apply {
              put("x", pt.x.toDouble())
              put("y", pt.y.toDouble())
            },
          )
        }
      }

    private fun deserializeToneCurve(obj: JSONObject?): ToneCurveParams {
      if (obj == null) return ToneCurveParams()
      return ToneCurveParams(
        rgbPoints = deserializeCurvePoints(obj.optJSONArray("rgb")),
        redPoints = deserializeCurvePoints(obj.optJSONArray("red")),
        greenPoints = deserializeCurvePoints(obj.optJSONArray("green")),
        bluePoints = deserializeCurvePoints(obj.optJSONArray("blue")),
      )
    }

    private fun deserializeCurvePoints(arr: JSONArray?): List<CurvePoint> {
      if (arr == null || arr.length() < 2) return ToneCurveParams.DEFAULT_POINTS
      val list = ArrayList<CurvePoint>(arr.length())
      for (i in 0 until arr.length()) {
        val item = arr.optJSONObject(i) ?: continue
        list.add(
          CurvePoint(
            x = item.optDouble("x", 0.0).toFloat(),
            y = item.optDouble("y", 0.0).toFloat(),
          )
        )
      }
      return ToneCurveParams.sanitizePoints(list)
    }

    private fun serializeColorGrading(cg: ColorGradingParams): JSONObject =
      JSONObject().apply {
        put("shadows", serializeWheel(cg.shadows))
        put("midtones", serializeWheel(cg.midtones))
        put("highlights", serializeWheel(cg.highlights))
      }

    private fun serializeWheel(w: ColorGradeWheel): JSONObject =
      JSONObject().apply {
        put("hueDegrees", w.hueDegrees.toDouble())
        put("saturation", w.saturation.toDouble())
        put("luminance", w.luminance.toDouble())
      }

    private fun deserializeColorGrading(obj: JSONObject?): ColorGradingParams {
      if (obj == null) return ColorGradingParams()
      return ColorGradingParams(
        shadows = deserializeWheel(obj.optJSONObject("shadows")),
        midtones = deserializeWheel(obj.optJSONObject("midtones")),
        highlights = deserializeWheel(obj.optJSONObject("highlights")),
      )
    }

    private fun deserializeWheel(obj: JSONObject?): ColorGradeWheel {
      if (obj == null) return ColorGradeWheel()
      return ColorGradeWheel(
        hueDegrees = obj.optDouble("hueDegrees", 0.0).toFloat(),
        saturation = obj.optDouble("saturation", 0.0).toFloat(),
        luminance = obj.optDouble("luminance", 0.0).toFloat(),
      )
    }

    private fun serializeTextLayers(layers: List<TextLayer>): JSONArray =
      JSONArray().apply {
        layers.forEach { layer ->
          put(
            JSONObject().apply {
              put("id", layer.id)
              put("text", layer.text)
              put("xFraction", layer.xFraction.toDouble())
              put("yFraction", layer.yFraction.toDouble())
              put("fontSizeSp", layer.fontSizeSp.toDouble())
              put("rotationDegrees", layer.rotationDegrees.toDouble())
              put("colorArgb", layer.colorArgb)
              put("opacity", layer.opacity.toDouble())
              put("font", layer.font.name)
              put("isBold", layer.isBold)
              put("isItalic", layer.isItalic)
              put("isVisible", layer.isVisible)
              put("isLocked", layer.isLocked)
            },
          )
        }
      }

    private fun deserializeTextLayers(arr: JSONArray?): List<TextLayer> {
      if (arr == null) return emptyList()
      val list = ArrayList<TextLayer>(arr.length())
      for (i in 0 until arr.length()) {
        val obj = arr.optJSONObject(i) ?: continue
        val font =
          runCatching { EditorFont.valueOf(obj.optString("font", EditorFont.NOTO_SANS_MYANMAR.name)) }
            .getOrDefault(EditorFont.NOTO_SANS_MYANMAR)
        list.add(
          TextLayer(
            id = obj.getString("id"),
            text = obj.optString("text", ""),
            xFraction = obj.optDouble("xFraction", 0.5).toFloat(),
            yFraction = obj.optDouble("yFraction", 0.5).toFloat(),
            fontSizeSp = obj.optDouble("fontSizeSp", 28.0).toFloat(),
            rotationDegrees = obj.optDouble("rotationDegrees", 0.0).toFloat(),
            colorArgb = obj.optLong("colorArgb", 0xFFFFFFFF),
            opacity = obj.optDouble("opacity", 1.0).toFloat(),
            font = font,
            isBold = obj.optBoolean("isBold", false),
            isItalic = obj.optBoolean("isItalic", false),
            isVisible = obj.optBoolean("isVisible", true),
            isLocked = obj.optBoolean("isLocked", false),
          )
        )
      }
      return list
    }
  }
}
