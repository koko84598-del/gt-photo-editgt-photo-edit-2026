package com.example.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.res.ResourcesCompat
import com.example.model.ExportFormat
import com.example.model.ExportResult
import com.example.model.TextLayer
import kotlin.math.min
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface GalleryExporter {
  suspend fun exportToGallery(
    bitmap: Bitmap,
    sourceDisplayName: String,
    format: ExportFormat,
    jpegQuality: Int,
  ): Result<ExportResult>
}

class MediaStoreGalleryExporter(
  private val context: Context,
  private val ioDispatcher: kotlinx.coroutines.CoroutineDispatcher = Dispatchers.IO,
) : GalleryExporter {

  override suspend fun exportToGallery(
    bitmap: Bitmap,
    sourceDisplayName: String,
    format: ExportFormat,
    jpegQuality: Int,
  ): Result<ExportResult> =
    withContext(ioDispatcher) {
      runCatching {
        val cleanBaseName =
          sourceDisplayName
            .substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .ifBlank { "GTPhotoEdit" }
        val fileName = "${cleanBaseName}_${System.currentTimeMillis()}.${format.extension}"
        val resolver = context.contentResolver

        val values =
          ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, format.mimeType)
            put(MediaStore.Images.Media.WIDTH, bitmap.width)
            put(MediaStore.Images.Media.HEIGHT, bitmap.height)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
              put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/GT Photo Edit")
              put(MediaStore.Images.Media.IS_PENDING, 1)
            }
          }

        val collection =
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
          } else {
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI
          }

        val itemUri =
          resolver.insert(collection, values)
            ?: error("MediaStore rejected creating the exported image entry.")

        try {
          val bitmapToWrite = prepareBitmapForFormat(bitmap, format)
          resolver.openOutputStream(itemUri)?.use { outStream ->
            val compressFormat =
              when (format) {
                ExportFormat.JPEG -> Bitmap.CompressFormat.JPEG
                ExportFormat.PNG -> Bitmap.CompressFormat.PNG
              }
            val quality =
              when (format) {
                ExportFormat.JPEG -> jpegQuality.coerceIn(1, 100)
                ExportFormat.PNG -> 100
              }
            if (!bitmapToWrite.compress(compressFormat, quality, outStream)) {
              error("Failed to compress ${format.label} image data.")
            }
            outStream.flush()
          } ?: error("Unable to open MediaStore output stream.")

          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val readyValues =
              ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
            resolver.update(itemUri, readyValues, null, null)
          }

          ExportResult(
            outputUriString = itemUri.toString(),
            displayName = fileName,
            width = bitmap.width,
            height = bitmap.height,
            format = format,
          )
        } catch (t: Throwable) {
          runCatching { resolver.delete(itemUri, null, null) }
          throw t
        }
      }
    }

  private fun prepareBitmapForFormat(source: Bitmap, format: ExportFormat): Bitmap {
    if (format == ExportFormat.PNG || !source.hasAlpha()) {
      return source
    }
    val w = source.width
    val h = source.height
    val pixels = IntArray(w * h)
    source.getPixels(pixels, 0, w, 0, 0, w, h)
    for (i in pixels.indices) {
      val p = pixels[i]
      val a = (p ushr 24) and 0xFF
      if (a < 255) {
        val r = (((p ushr 16) and 0xFF) * a) / 255
        val g = (((p ushr 8) and 0xFF) * a) / 255
        val b = ((p and 0xFF) * a) / 255
        pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
      }
    }
    val flattened = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    flattened.setHasAlpha(false)
    flattened.setPixels(pixels, 0, w, 0, 0, w, h)
    return flattened
  }
}

object TextLayerCompositor {

  fun compositeVisibleTextLayers(
    baseBitmap: Bitmap,
    textLayers: List<TextLayer>,
    context: Context?,
    preserveAlpha: Boolean,
  ): Bitmap {
    val visibleLayers = textLayers.filter { it.isVisible && it.text.isNotEmpty() }
    val mutable =
      if (baseBitmap.isMutable && baseBitmap.config == Bitmap.Config.ARGB_8888) {
        baseBitmap
      } else {
        baseBitmap.copy(Bitmap.Config.ARGB_8888, true)
      }
    mutable.setHasAlpha(preserveAlpha && baseBitmap.hasAlpha())
    if (visibleLayers.isEmpty()) {
      return mutable
    }

    val canvas = Canvas(mutable)
    val outW = mutable.width.toFloat().coerceAtLeast(1f)
    val outH = mutable.height.toFloat().coerceAtLeast(1f)
    val scaleFactor = (min(outW, outH) / 360f).coerceAtLeast(0.5f)

    visibleLayers.forEach { layer ->
      val paint =
        TextPaint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG).apply {
          val baseColor = layer.colorArgb.toInt()
          val alphaInt = ((Color.alpha(baseColor) / 255f) * layer.opacity.coerceIn(0f, 1f) * 255f)
            .roundToInt()
            .coerceIn(0, 255)
          color = Color.argb(alphaInt, Color.red(baseColor), Color.green(baseColor), Color.blue(baseColor))
          textSize = layer.fontSizeSp * scaleFactor
          typeface = resolveTypeface(context, layer)
        }

      val centerX = layer.xFraction.coerceIn(0f, 1f) * outW
      val centerY = layer.yFraction.coerceIn(0f, 1f) * outH
      val maxLineWidth = (outW * 0.9f).roundToInt().coerceAtLeast(1)

      val layout =
        StaticLayout.Builder.obtain(layer.text, 0, layer.text.length, paint, maxLineWidth)
          .setAlignment(Layout.Alignment.ALIGN_CENTER)
          .setIncludePad(false)
          .build()

      canvas.save()
      canvas.translate(centerX, centerY)
      if (layer.rotationDegrees != 0f) {
        canvas.rotate(layer.rotationDegrees)
      }
      canvas.translate(-maxLineWidth / 2f, -layout.height / 2f)
      layout.draw(canvas)
      canvas.restore()
    }
    return mutable
  }

  private fun resolveTypeface(context: Context?, layer: TextLayer): Typeface {
    val base =
      if (context != null) {
        runCatching { ResourcesCompat.getFont(context, layer.font.fontResId) }.getOrNull()
          ?: Typeface.DEFAULT
      } else {
        Typeface.DEFAULT
      }
    val style =
      when {
        layer.isBold && layer.isItalic -> Typeface.BOLD_ITALIC
        layer.isBold -> Typeface.BOLD
        layer.isItalic -> Typeface.ITALIC
        else -> Typeface.NORMAL
      }
    return Typeface.create(base, style)
  }
}
