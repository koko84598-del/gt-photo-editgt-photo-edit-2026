package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.AutoAwesomeMosaic
import androidx.compose.material.icons.outlined.FileUpload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.model.AdjustmentType
import com.example.model.ColorGradeWheel
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.model.CurvePoint
import com.example.model.EditorCategory
import com.example.model.EditorFont
import com.example.model.EditorUiState
import com.example.model.ExportFormat
import com.example.model.GradingRange
import com.example.model.HslAdjustment
import com.example.model.HslColorRange
import com.example.model.ToneCurveChannel
import com.example.ui.components.CenterEditingWorkspace
import com.example.ui.components.EditorBottomNavigation
import com.example.ui.components.EditorSideRail
import com.example.ui.components.ExportGalleryDialog
import com.example.ui.components.OpenProjectDialog
import com.example.ui.components.PhotoPreviewStage
import com.example.ui.components.SaveProjectDialog
import com.example.ui.components.StudioUtilityBar
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.viewmodel.EditorViewModel

@Composable
fun EditorRoute(
  viewModel: EditorViewModel,
  onLaunchPhotoPicker: () -> Unit,
  onLaunchRelinkPicker: () -> Unit = onLaunchPhotoPicker,
  onRequestExport: (ExportFormat, Int) -> Unit = { format, quality ->
    viewModel.exportToGallery(format, quality)
  },
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Deselect active layer on system back press before exiting
  BackHandler(enabled = uiState.selectedLayerId != null) {
    viewModel.selectTextLayer(null)
  }

  EditorScreen(
    uiState = uiState,
    onLaunchPhotoPicker = onLaunchPhotoPicker,
    onLaunchRelinkPicker = onLaunchRelinkPicker,
    onClearPhoto = viewModel::clearPhoto,
    onDismissError = viewModel::dismissPhotoError,
    onDismissStatus = viewModel::dismissStatusMessage,
    onUndo = viewModel::undo,
    onRedo = viewModel::redo,
    onSaveProject = viewModel::saveProject,
    onOpenProject = viewModel::openProject,
    onDeleteProject = viewModel::deleteSavedProject,
    onExportImage = onRequestExport,
    onSelectCategory = viewModel::selectCategory,
    onTogglePanelExpanded = viewModel::togglePanelExpanded,
    onSelectAspectRatio = viewModel::setCropAspectRatio,
    onCropRectChange = viewModel::updateCropRect,
    onRotate90 = viewModel::rotateBy90,
    onSelectRotation90 = viewModel::setRotation90,
    onToggleFlipHorizontal = viewModel::toggleFlipHorizontal,
    onToggleFlipVertical = viewModel::toggleFlipVertical,
    onUpdateStraighten = viewModel::updateStraightenDegrees,
    onUpdatePerspectiveV = viewModel::updatePerspectiveVertical,
    onUpdatePerspectiveH = viewModel::updatePerspectiveHorizontal,
    onResetTransform = viewModel::resetCropTransform,
    onUpdateColorAdjustment = viewModel::updateColorAdjustment,
    onResetColorAdjustment = viewModel::resetColorAdjustment,
    onResetAllColorAdjustments = viewModel::resetAllColorAdjustments,
    onUpdateHslRange = viewModel::updateHslRange,
    onResetHslRange = viewModel::resetHslRange,
    onResetAllHsl = viewModel::resetAllHsl,
    onAddToneCurvePoint = viewModel::addToneCurvePoint,
    onUpdateToneCurvePoint = viewModel::updateToneCurvePoint,
    onRemoveToneCurvePoint = viewModel::removeToneCurvePoint,
    onResetToneCurveChannel = viewModel::resetToneCurveChannel,
    onResetAllToneCurves = viewModel::resetAllToneCurves,
    onUpdateColorGrading = viewModel::updateColorGrading,
    onResetColorGradingRange = viewModel::resetColorGradingRange,
    onResetAllColorGrading = viewModel::resetAllColorGrading,
    onAddTextLayer = viewModel::addTextLayer,
    onSelectLayer = viewModel::selectTextLayer,
    onUpdateSelectedText = viewModel::updateSelectedLayerText,
    onMoveLayer = viewModel::moveTextLayer,
    onSelectFont = viewModel::updateLayerFont,
    onUpdateFontSize = viewModel::updateLayerFontSize,
    onUpdateRotation = viewModel::updateLayerRotation,
    onUpdateOpacity = viewModel::updateLayerOpacity,
    onUpdateColor = viewModel::updateLayerColor,
    onToggleBold = viewModel::toggleLayerBold,
    onToggleItalic = viewModel::toggleLayerItalic,
    onDuplicateLayer = viewModel::duplicateLayer,
    onDeleteLayer = viewModel::deleteLayer,
    onToggleVisibility = viewModel::toggleLayerVisibility,
    onToggleLock = viewModel::toggleLayerLock,
    onMoveLayerOrder = viewModel::moveLayerOrder,
  )
}

@Composable
fun EditorScreen(
  uiState: EditorUiState,
  onLaunchPhotoPicker: () -> Unit,
  onLaunchRelinkPicker: () -> Unit = onLaunchPhotoPicker,
  onClearPhoto: () -> Unit,
  onDismissError: () -> Unit,
  onDismissStatus: () -> Unit = {},
  onUndo: () -> Unit = {},
  onRedo: () -> Unit = {},
  onSaveProject: (String?) -> Unit = {},
  onOpenProject: (String) -> Unit = {},
  onDeleteProject: (String) -> Unit = {},
  onExportImage: (ExportFormat, Int) -> Unit = { _, _ -> },
  onSelectCategory: (EditorCategory) -> Unit,
  onTogglePanelExpanded: () -> Unit,
  onSelectAspectRatio: (CropAspectRatio) -> Unit,
  onCropRectChange: (CropRect) -> Unit,
  onRotate90: () -> Unit,
  onSelectRotation90: (Int) -> Unit,
  onToggleFlipHorizontal: () -> Unit,
  onToggleFlipVertical: () -> Unit,
  onUpdateStraighten: (Float) -> Unit,
  onUpdatePerspectiveV: (Float) -> Unit,
  onUpdatePerspectiveH: (Float) -> Unit,
  onResetTransform: () -> Unit,
  onUpdateColorAdjustment: (AdjustmentType, Float) -> Unit,
  onResetColorAdjustment: (AdjustmentType) -> Unit,
  onResetAllColorAdjustments: () -> Unit,
  onUpdateHslRange: (HslColorRange, HslAdjustment) -> Unit,
  onResetHslRange: (HslColorRange) -> Unit,
  onResetAllHsl: () -> Unit,
  onAddToneCurvePoint: (ToneCurveChannel, CurvePoint) -> Unit,
  onUpdateToneCurvePoint: (ToneCurveChannel, Int, CurvePoint) -> Unit,
  onRemoveToneCurvePoint: (ToneCurveChannel, Int) -> Unit,
  onResetToneCurveChannel: (ToneCurveChannel) -> Unit,
  onResetAllToneCurves: () -> Unit,
  onUpdateColorGrading: (GradingRange, ColorGradeWheel) -> Unit,
  onResetColorGradingRange: (GradingRange) -> Unit,
  onResetAllColorGrading: () -> Unit,
  onAddTextLayer: (String, EditorFont) -> Unit,
  onSelectLayer: (String?) -> Unit,
  onUpdateSelectedText: (String) -> Unit,
  onMoveLayer: (String, Float, Float) -> Unit,
  onSelectFont: (String, EditorFont) -> Unit,
  onUpdateFontSize: (String, Float) -> Unit,
  onUpdateRotation: (String, Float) -> Unit,
  onUpdateOpacity: (String, Float) -> Unit,
  onUpdateColor: (String, Long) -> Unit,
  onToggleBold: (String) -> Unit,
  onToggleItalic: (String) -> Unit,
  onDuplicateLayer: (String) -> Unit,
  onDeleteLayer: (String) -> Unit,
  onToggleVisibility: (String) -> Unit,
  onToggleLock: (String) -> Unit,
  onMoveLayerOrder: (String, Boolean) -> Unit,
) {
  val snackbarHostState = remember { SnackbarHostState() }
  var showSaveDialog by remember { mutableStateOf(false) }
  var showOpenDialog by remember { mutableStateOf(false) }
  var showExportDialog by remember { mutableStateOf(false) }

  LaunchedEffect(uiState.photoError) {
    val err = uiState.photoError ?: return@LaunchedEffect
    snackbarHostState.showSnackbar(err)
    onDismissError()
  }

  LaunchedEffect(uiState.statusMessage) {
    val msg = uiState.statusMessage ?: return@LaunchedEffect
    snackbarHostState.showSnackbar(msg)
    onDismissStatus()
  }

  val isCropMode = uiState.activeCategory == EditorCategory.CROP && uiState.importedPhoto != null

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val isWideLayout = maxWidth >= 720.dp
    val widePanelMaxHeight = maxHeight
    val adaptivePanelMaxHeight = (maxHeight * 0.34f).coerceIn(130.dp, 280.dp)

    Scaffold(
      containerColor = ObsidianBg,
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      bottomBar = {
        if (!isWideLayout) {
          EditorBottomNavigation(
            activeCategory = uiState.activeCategory,
            onSelectCategory = onSelectCategory,
          )
        }
      },
    ) { innerPadding ->
      if (isWideLayout) {
        Row(modifier = Modifier.fillMaxSize().padding(innerPadding).statusBarsPadding()) {
          EditorSideRail(
            activeCategory = uiState.activeCategory,
            onSelectCategory = onSelectCategory,
          )
          Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
            StudioTopBar(
              uiState = uiState,
              onImportClick = onLaunchPhotoPicker,
              onExportClick = { showExportDialog = true },
            )
            StudioUtilityBar(
              canUndo = uiState.canUndo,
              canRedo = uiState.canRedo,
              currentProjectName = uiState.currentProjectName,
              savedProjectCount = uiState.savedProjects.size,
              onUndo = onUndo,
              onRedo = onRedo,
              onOpenSaveDialog = { showSaveDialog = true },
              onOpenProjectsDialog = { showOpenDialog = true },
            )
            PhotoPreviewStage(
              importedPhoto = uiState.importedPhoto,
              previewBitmap = uiState.previewBitmap,
              isLoadingPhoto = uiState.isLoadingPhoto,
              isCropMode = isCropMode,
              cropRect = uiState.cropTransform.cropRect,
              cropAspectRatio = uiState.cropTransform.aspectRatio,
              textLayers = uiState.textLayers,
              selectedLayerId = uiState.selectedLayerId,
              onImportClick = onLaunchPhotoPicker,
              onCropRectChange = onCropRectChange,
              onSelectLayer = onSelectLayer,
              onMoveLayer = onMoveLayer,
              onDuplicateSelected = onDuplicateLayer,
              onDeleteSelected = onDeleteLayer,
              missingSourceMessage = uiState.missingSourceMessage,
              onRelinkPhoto = onLaunchRelinkPicker,
              modifier = Modifier.weight(1f),
            )
          }
          CenterEditingWorkspace(
            uiState = uiState,
            onTogglePanelExpanded = onTogglePanelExpanded,
            onImportPhoto = onLaunchPhotoPicker,
            onClearPhoto = onClearPhoto,
            onSelectAspectRatio = onSelectAspectRatio,
            onRotate90 = onRotate90,
            onSelectRotation90 = onSelectRotation90,
            onToggleFlipHorizontal = onToggleFlipHorizontal,
            onToggleFlipVertical = onToggleFlipVertical,
            onUpdateStraighten = onUpdateStraighten,
            onUpdatePerspectiveV = onUpdatePerspectiveV,
            onUpdatePerspectiveH = onUpdatePerspectiveH,
            onResetTransform = onResetTransform,
            onUpdateColorAdjustment = onUpdateColorAdjustment,
            onResetColorAdjustment = onResetColorAdjustment,
            onResetAllColorAdjustments = onResetAllColorAdjustments,
            onUpdateHslRange = onUpdateHslRange,
            onResetHslRange = onResetHslRange,
            onResetAllHsl = onResetAllHsl,
            onAddToneCurvePoint = onAddToneCurvePoint,
            onUpdateToneCurvePoint = onUpdateToneCurvePoint,
            onRemoveToneCurvePoint = onRemoveToneCurvePoint,
            onResetToneCurveChannel = onResetToneCurveChannel,
            onResetAllToneCurves = onResetAllToneCurves,
            onUpdateColorGrading = onUpdateColorGrading,
            onResetColorGradingRange = onResetColorGradingRange,
            onResetAllColorGrading = onResetAllColorGrading,
            onAddTextLayer = onAddTextLayer,
            onUpdateSelectedText = onUpdateSelectedText,
            onSelectFont = onSelectFont,
            onUpdateFontSize = onUpdateFontSize,
            onUpdateRotation = onUpdateRotation,
            onUpdateOpacity = onUpdateOpacity,
            onUpdateColor = onUpdateColor,
            onToggleBold = onToggleBold,
            onToggleItalic = onToggleItalic,
            onSelectLayer = { onSelectLayer(it) },
            onDuplicateLayer = onDuplicateLayer,
            onDeleteLayer = onDeleteLayer,
            onToggleVisibility = onToggleVisibility,
            onToggleLock = onToggleLock,
            onMoveLayerOrder = onMoveLayerOrder,
            modifier = Modifier.width(340.dp).fillMaxHeight(),
            maxContentHeight = widePanelMaxHeight,
          )
        }
      } else {
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).statusBarsPadding().imePadding()) {
          StudioTopBar(
            uiState = uiState,
            onImportClick = onLaunchPhotoPicker,
            onExportClick = { showExportDialog = true },
          )
          StudioUtilityBar(
            canUndo = uiState.canUndo,
            canRedo = uiState.canRedo,
            currentProjectName = uiState.currentProjectName,
            savedProjectCount = uiState.savedProjects.size,
            onUndo = onUndo,
            onRedo = onRedo,
            onOpenSaveDialog = { showSaveDialog = true },
            onOpenProjectsDialog = { showOpenDialog = true },
          )

          // Fixed top photo preview: always visible even when switching tools/panels
          PhotoPreviewStage(
            importedPhoto = uiState.importedPhoto,
            previewBitmap = uiState.previewBitmap,
            isLoadingPhoto = uiState.isLoadingPhoto,
            isCropMode = isCropMode,
            cropRect = uiState.cropTransform.cropRect,
            cropAspectRatio = uiState.cropTransform.aspectRatio,
            textLayers = uiState.textLayers,
            selectedLayerId = uiState.selectedLayerId,
            onImportClick = onLaunchPhotoPicker,
            onCropRectChange = onCropRectChange,
            onSelectLayer = onSelectLayer,
            onMoveLayer = onMoveLayer,
            onDuplicateSelected = onDuplicateLayer,
            onDeleteSelected = onDeleteLayer,
            missingSourceMessage = uiState.missingSourceMessage,
            onRelinkPhoto = onLaunchRelinkPicker,
            modifier = Modifier.weight(1f).fillMaxWidth(),
          )

          // Separate center editing panel for active category
          CenterEditingWorkspace(
            uiState = uiState,
            onTogglePanelExpanded = onTogglePanelExpanded,
            onImportPhoto = onLaunchPhotoPicker,
            onClearPhoto = onClearPhoto,
            onSelectAspectRatio = onSelectAspectRatio,
            onRotate90 = onRotate90,
            onSelectRotation90 = onSelectRotation90,
            onToggleFlipHorizontal = onToggleFlipHorizontal,
            onToggleFlipVertical = onToggleFlipVertical,
            onUpdateStraighten = onUpdateStraighten,
            onUpdatePerspectiveV = onUpdatePerspectiveV,
            onUpdatePerspectiveH = onUpdatePerspectiveH,
            onResetTransform = onResetTransform,
            onUpdateColorAdjustment = onUpdateColorAdjustment,
            onResetColorAdjustment = onResetColorAdjustment,
            onResetAllColorAdjustments = onResetAllColorAdjustments,
            onUpdateHslRange = onUpdateHslRange,
            onResetHslRange = onResetHslRange,
            onResetAllHsl = onResetAllHsl,
            onAddToneCurvePoint = onAddToneCurvePoint,
            onUpdateToneCurvePoint = onUpdateToneCurvePoint,
            onRemoveToneCurvePoint = onRemoveToneCurvePoint,
            onResetToneCurveChannel = onResetToneCurveChannel,
            onResetAllToneCurves = onResetAllToneCurves,
            onUpdateColorGrading = onUpdateColorGrading,
            onResetColorGradingRange = onResetColorGradingRange,
            onResetAllColorGrading = onResetAllColorGrading,
            onAddTextLayer = onAddTextLayer,
            onUpdateSelectedText = onUpdateSelectedText,
            onSelectFont = onSelectFont,
            onUpdateFontSize = onUpdateFontSize,
            onUpdateRotation = onUpdateRotation,
            onUpdateOpacity = onUpdateOpacity,
            onUpdateColor = onUpdateColor,
            onToggleBold = onToggleBold,
            onToggleItalic = onToggleItalic,
            onSelectLayer = { onSelectLayer(it) },
            onDuplicateLayer = onDuplicateLayer,
            onDeleteLayer = onDeleteLayer,
            onToggleVisibility = onToggleVisibility,
            onToggleLock = onToggleLock,
            onMoveLayerOrder = onMoveLayerOrder,
            maxContentHeight = adaptivePanelMaxHeight,
          )
        }
      }
    }

    if (showSaveDialog) {
      val suggestedName =
        uiState.currentProjectName
          ?: uiState.importedPhoto?.displayName?.substringBeforeLast('.')
          ?: "GT Studio Project"
      SaveProjectDialog(
        initialName = suggestedName,
        onDismiss = { showSaveDialog = false },
        onConfirmSave = { name ->
          showSaveDialog = false
          onSaveProject(name)
        },
      )
    }

    if (showOpenDialog) {
      OpenProjectDialog(
        projects = uiState.savedProjects,
        onDismiss = { showOpenDialog = false },
        onOpenProject = { id ->
          showOpenDialog = false
          onOpenProject(id)
        },
        onDeleteProject = onDeleteProject,
      )
    }

    if (showExportDialog) {
      ExportGalleryDialog(
        importedPhoto = uiState.importedPhoto,
        cropTransform = uiState.cropTransform,
        visibleLayerCount = uiState.textLayers.count { it.isVisible && it.text.isNotEmpty() },
        isExporting = uiState.isExporting,
        onDismiss = { showExportDialog = false },
        onExport = { format, quality ->
          showExportDialog = false
          onExportImage(format, quality)
        },
      )
    }
  }
}

@Composable
private fun StudioTopBar(
  uiState: EditorUiState,
  onImportClick: () -> Unit,
  onExportClick: () -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.weight(1f),
    ) {
      Surface(
        color = StudioCyan.copy(alpha = 0.14f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.35f)),
        modifier = Modifier.size(34.dp),
      ) {
        Icon(
          imageVector = Icons.Outlined.AutoAwesomeMosaic,
          contentDescription = null,
          tint = StudioCyan,
          modifier = Modifier.padding(7.dp),
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.app_name),
          style = MaterialTheme.typography.titleMedium,
          color = StudioTextPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        val photo = uiState.importedPhoto
        if (photo != null) {
          Text(
            text = "${photo.originalWidth} × ${photo.originalHeight} px",
            style = MaterialTheme.typography.labelSmall,
            color = StudioCyan,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.testTag("top_bar_resolution"),
          )
        } else {
          Text(
            text = "Pro Darkroom Studio",
            style = MaterialTheme.typography.labelSmall,
            color = StudioTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      FilledTonalButton(
        onClick = onImportClick,
        shape = RoundedCornerShape(10.dp),
        colors =
          ButtonDefaults.filledTonalButtonColors(
            containerColor = StudioSurfaceElevated,
            contentColor = StudioTextPrimary,
          ),
        border = BorderStroke(1.dp, StudioOutline),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        modifier = Modifier.height(48.dp).testTag("top_import_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.AddPhotoAlternate,
          contentDescription = stringResource(R.string.cd_import_photo),
          tint = StudioCyan,
          modifier = Modifier.size(17.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = if (uiState.importedPhoto == null) "Import" else "Swap",
          style = MaterialTheme.typography.labelMedium,
        )
      }

      Button(
        onClick = onExportClick,
        enabled = uiState.importedPhoto != null && !uiState.isExporting,
        shape = RoundedCornerShape(10.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            disabledContainerColor = StudioSurfaceElevated,
            disabledContentColor = StudioTextSecondary.copy(alpha = 0.4f),
          ),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        modifier = Modifier.height(48.dp).testTag("export_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.FileUpload,
          contentDescription = stringResource(R.string.cd_export_image),
          modifier = Modifier.size(17.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("Export", style = MaterialTheme.typography.labelMedium)
      }
    }
  }
}
