package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Flip
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.RotateRight
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CropAspectRatio
import com.example.model.CropTransformParams
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlin.math.roundToInt

@Composable
fun CropTransformPanel(
  hasPhoto: Boolean,
  cropTransform: CropTransformParams,
  maxContentHeight: Dp,
  onSelectAspectRatio: (CropAspectRatio) -> Unit,
  onRotate90: () -> Unit,
  onSelectRotation90: (Int) -> Unit,
  onToggleFlipHorizontal: () -> Unit,
  onToggleFlipVertical: () -> Unit,
  onUpdateStraighten: (Float) -> Unit,
  onUpdatePerspectiveV: (Float) -> Unit,
  onUpdatePerspectiveH: (Float) -> Unit,
  onResetTransform: () -> Unit,
) {
  if (!hasPhoto) {
    Surface(
      color = StudioSurfaceElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, StudioOutline),
      modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("crop_no_photo_hint"),
    ) {
      Text(
        text = "Import a photo first to use Crop, Rotate, Flip, Straighten, and Perspective controls.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        modifier = Modifier.padding(14.dp),
      )
    }
    return
  }

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("crop_panel"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    // Aspect Ratio Presets
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "Aspect Ratio",
        style = MaterialTheme.typography.labelMedium,
        color = StudioTextSecondary,
      )
      OutlinedButton(
        onClick = onResetTransform,
        enabled = !cropTransform.isIdentity,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, StudioOutline),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
        modifier = Modifier.height(36.dp).testTag("reset_transform_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.RestartAlt,
          contentDescription = stringResource(R.string.cd_reset_transform),
          modifier = Modifier.size(16.dp),
          tint = if (cropTransform.isIdentity) StudioTextSecondary else StudioCyan,
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = "Reset",
          style = MaterialTheme.typography.labelMedium,
          color = if (cropTransform.isIdentity) StudioTextSecondary else StudioCyan,
        )
      }
    }

    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      contentPadding = PaddingValues(end = 8.dp),
    ) {
      items(CropAspectRatio.entries) { preset ->
        FilterChip(
          selected = cropTransform.aspectRatio == preset,
          onClick = { onSelectAspectRatio(preset) },
          label = { Text(preset.label) },
          colors = cropChipColors(),
          modifier = Modifier.testTag("aspect_ratio_${preset.name.lowercase()}"),
        )
      }
    }

    // Rotate 90 / 180 / 270 and Flip H / V
    @OptIn(ExperimentalLayoutApi::class)
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      OutlinedButton(
        onClick = onRotate90,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, StudioOutline),
        contentPadding = PaddingValues(horizontal = 10.dp),
        modifier = Modifier.height(48.dp).testTag("rotate_90_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.RotateRight,
          contentDescription = stringResource(R.string.cd_rotate_90),
          tint = StudioCyan,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text("+90°", color = StudioTextPrimary, style = MaterialTheme.typography.labelMedium)
      }

      FilterChip(
        selected = cropTransform.flipHorizontal,
        onClick = onToggleFlipHorizontal,
        label = { Text("Flip H") },
        leadingIcon = {
          Icon(
            imageVector = Icons.Outlined.Flip,
            contentDescription = stringResource(R.string.cd_flip_horizontal),
            modifier = Modifier.size(16.dp),
          )
        },
        colors = cropChipColors(),
        modifier = Modifier.height(48.dp).testTag("flip_horizontal_button"),
      )

      FilterChip(
        selected = cropTransform.flipVertical,
        onClick = onToggleFlipVertical,
        label = { Text("Flip V") },
        leadingIcon = {
          Icon(
            imageVector = Icons.Outlined.SwapVert,
            contentDescription = stringResource(R.string.cd_flip_vertical),
            modifier = Modifier.size(16.dp),
          )
        },
        colors = cropChipColors(),
        modifier = Modifier.height(48.dp).testTag("flip_vertical_button"),
      )
    }

    // Direct 0 / 90 / 180 / 270 degree rotation chips
    @OptIn(ExperimentalLayoutApi::class)
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      listOf(0, 90, 180, 270).forEach { deg ->
        FilterChip(
          selected = cropTransform.rotation90Degrees == deg,
          onClick = { onSelectRotation90(deg) },
          label = { Text("${deg}°") },
          colors = cropChipColors(),
          modifier = Modifier.testTag("rotate_preset_$deg"),
        )
      }
    }

    // Straighten Slider (-45..45 deg)
    TransformSliderRow(
      label = "Straighten",
      valueText = "${cropTransform.straightenDegrees.roundToInt()}°",
      value = cropTransform.straightenDegrees,
      valueRange = -45f..45f,
      canReset = cropTransform.straightenDegrees != 0f,
      onValueChange = onUpdateStraighten,
      onReset = { onUpdateStraighten(0f) },
      tag = "straighten_slider",
    )

    // Perspective Correction Sliders
    TransformSliderRow(
      label = "Tilt V",
      valueText = "${(cropTransform.perspectiveVertical * 100).roundToInt()}%",
      value = cropTransform.perspectiveVertical,
      valueRange = -1f..1f,
      canReset = cropTransform.perspectiveVertical != 0f,
      onValueChange = onUpdatePerspectiveV,
      onReset = { onUpdatePerspectiveV(0f) },
      tag = "perspective_v_slider",
    )

    TransformSliderRow(
      label = "Tilt H",
      valueText = "${(cropTransform.perspectiveHorizontal * 100).roundToInt()}%",
      value = cropTransform.perspectiveHorizontal,
      valueRange = -1f..1f,
      canReset = cropTransform.perspectiveHorizontal != 0f,
      onValueChange = onUpdatePerspectiveH,
      onReset = { onUpdatePerspectiveH(0f) },
      tag = "perspective_h_slider",
    )
  }
}

@Composable
private fun TransformSliderRow(
  label: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  canReset: Boolean,
  onValueChange: (Float) -> Unit,
  onReset: () -> Unit,
  tag: String,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = StudioTextSecondary,
      modifier = Modifier.width(68.dp),
    )
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      colors =
        SliderDefaults.colors(
          thumbColor = StudioCyan,
          activeTrackColor = StudioCyan,
          inactiveTrackColor = StudioOutline,
        ),
      modifier = Modifier.weight(1f).testTag(tag),
    )
    Text(
      text = valueText,
      style = MaterialTheme.typography.labelSmall,
      color = StudioTextPrimary,
      modifier = Modifier.width(44.dp),
    )
    IconButton(
      onClick = onReset,
      enabled = canReset,
      modifier = Modifier.size(48.dp).testTag("${tag}_reset"),
    ) {
      Icon(
        imageVector = Icons.Outlined.RestartAlt,
        contentDescription = stringResource(R.string.cd_reset_adjustment),
        tint = if (canReset) StudioCyan else StudioTextSecondary.copy(alpha = 0.3f),
        modifier = Modifier.size(18.dp),
      )
    }
  }
}

@Composable
private fun cropChipColors() =
  FilterChipDefaults.filterChipColors(
    containerColor = StudioSurfaceElevated,
    labelColor = StudioTextSecondary,
    iconColor = StudioTextSecondary,
    selectedContainerColor = StudioCyan.copy(alpha = 0.2f),
    selectedLabelColor = StudioCyan,
    selectedLeadingIconColor = StudioCyan,
  )
