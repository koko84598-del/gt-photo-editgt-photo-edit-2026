package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ColorEngine
import com.example.model.CurvePoint
import com.example.model.ToneCurveChannel
import com.example.model.ToneCurveParams
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlin.math.abs
import kotlin.math.hypot

@Composable
fun ToneCurvePanel(
  hasPhoto: Boolean,
  toneCurve: ToneCurveParams,
  maxContentHeight: Dp,
  onAddPoint: (ToneCurveChannel, CurvePoint) -> Unit,
  onUpdatePoint: (ToneCurveChannel, Int, CurvePoint) -> Unit,
  onRemovePoint: (ToneCurveChannel, Int) -> Unit,
  onResetChannel: (ToneCurveChannel) -> Unit,
  onResetAll: () -> Unit,
) {
  if (!hasPhoto) {
    Surface(
      color = StudioSurfaceElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, StudioOutline),
      modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("curve_no_photo_hint"),
    ) {
      Text(
        text = "Import a photo first to shape RGB, Red, Green, and Blue tone curves.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        modifier = Modifier.padding(14.dp),
      )
    }
    return
  }

  var activeChannel by remember { mutableStateOf(ToneCurveChannel.RGB) }
  var selectedPointIndex by remember(activeChannel) { mutableStateOf<Int?>(null) }

  val points = toneCurve.pointsFor(activeChannel)
  val isChannelIdentity = ToneCurveParams.isChannelIdentity(points)
  val canRemoveSelected =
    selectedPointIndex != null && selectedPointIndex!! > 0 && selectedPointIndex!! < points.lastIndex

  val currentPointsState by rememberUpdatedState(points)
  val currentChannelState by rememberUpdatedState(activeChannel)

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("tone_curve_panel"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // Action header row + full-width channel selector row so all 4 channels stay visible on mobile
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "Channel Curve",
        style = MaterialTheme.typography.labelMedium,
        color = StudioTextSecondary,
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        IconButton(
          onClick = {
            val idx = selectedPointIndex
            if (idx != null && idx > 0 && idx < points.lastIndex) {
              onRemovePoint(activeChannel, idx)
              selectedPointIndex = null
            }
          },
          enabled = canRemoveSelected,
          modifier = Modifier.size(48.dp).testTag("remove_curve_point_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.DeleteOutline,
            contentDescription = stringResource(R.string.cd_remove_curve_point),
            tint = if (canRemoveSelected) MaterialTheme.colorScheme.error else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp),
          )
        }

        IconButton(
          onClick = {
            onResetChannel(activeChannel)
            selectedPointIndex = null
          },
          enabled = !isChannelIdentity,
          modifier = Modifier.size(48.dp).testTag("reset_curve_channel_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.RestartAlt,
            contentDescription = stringResource(R.string.cd_reset_channel),
            tint = if (!isChannelIdentity) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp),
          )
        }

        OutlinedButton(
          onClick = {
            onResetAll()
            selectedPointIndex = null
          },
          enabled = !toneCurve.isIdentity,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(36.dp).testTag("reset_all_curves_button"),
        ) {
          Text(
            text = "Reset All",
            style = MaterialTheme.typography.labelMedium,
            color = if (toneCurve.isIdentity) StudioTextSecondary else StudioAmber,
          )
        }
      }
    }

    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth(),
    ) {
      items(ToneCurveChannel.entries) { channel ->
        val modified = !ToneCurveParams.isChannelIdentity(toneCurve.pointsFor(channel))
        val accent = Color(channel.accentArgb)
        FilterChip(
          selected = activeChannel == channel,
          onClick = { activeChannel = channel },
          label = {
            Text(
              text = if (modified) "${channel.label} •" else channel.label,
              style = MaterialTheme.typography.labelMedium,
            )
          },
          colors =
            FilterChipDefaults.filterChipColors(
              containerColor = StudioSurfaceElevated,
              labelColor = StudioTextSecondary,
              selectedContainerColor = accent.copy(alpha = 0.22f),
              selectedLabelColor = accent,
            ),
          modifier = Modifier.testTag("curve_channel_${channel.name.lowercase()}"),
        )
      }
    }

    // Interactive Curve Graph Canvas
    val curveColor = Color(activeChannel.accentArgb)
    Canvas(
      modifier =
        Modifier.fillMaxWidth()
          .height(168.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(ObsidianBg)
          .border(1.dp, StudioOutline, RoundedCornerShape(12.dp))
          .pointerInput(activeChannel) {
            val hitRadiusPx = 28.dp.toPx()
            awaitEachGesture {
              val down = awaitFirstDown(requireUnconsumed = false)
              val w = size.width.toFloat().coerceAtLeast(1f)
              val h = size.height.toFloat().coerceAtLeast(1f)

              fun toNormalized(pos: Offset): CurvePoint =
                CurvePoint(
                  x = (pos.x / w).coerceIn(0f, 1f),
                  y = (1f - pos.y / h).coerceIn(0f, 1f),
                )

              val pts = currentPointsState
              var bestIdx = -1
              var bestDist = Float.MAX_VALUE
              pts.forEachIndexed { i, pt ->
                val px = pt.x * w
                val py = (1f - pt.y) * h
                val d = hypot(down.position.x - px, down.position.y - py)
                if (d <= hitRadiusPx && d < bestDist) {
                  bestDist = d
                  bestIdx = i
                }
              }

              val dragIndex: Int
              if (bestIdx >= 0) {
                selectedPointIndex = bestIdx
                dragIndex = bestIdx
              } else {
                val tapped = toNormalized(down.position)
                val newPt = CurvePoint(tapped.x.coerceIn(0.03f, 0.97f), tapped.y)
                onAddPoint(currentChannelState, newPt)
                val simulated = ToneCurveParams.sanitizePoints(pts + newPt)
                val addedIdx =
                  simulated.indices.minByOrNull { abs(simulated[it].x - newPt.x) } ?: 1
                selectedPointIndex = addedIdx
                dragIndex = addedIdx
              }
              down.consume()

              drag(down.id) { change ->
                val updated = toNormalized(change.position)
                onUpdatePoint(currentChannelState, dragIndex, updated)
                change.consume()
              }
            }
          }
          .testTag("tone_curve_canvas")
    ) {
      val w = size.width
      val h = size.height

      // 4x4 darkroom grid
      val gridColor = StudioOutline.copy(alpha = 0.55f)
      for (step in 1..3) {
        val x = w * (step / 4f)
        val y = h * (step / 4f)
        drawLine(gridColor, Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
        drawLine(gridColor, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
      }

      // Diagonal identity reference line (0,0) -> (1,1)
      drawLine(
        color = StudioTextSecondary.copy(alpha = 0.45f),
        start = Offset(0f, h),
        end = Offset(w, 0f),
        strokeWidth = 1.5f,
      )

      // Smooth monotone spline curve
      val path = Path()
      val samples = 64
      for (i in 0..samples) {
        val xNorm = i / samples.toFloat()
        val yNorm = ColorEngine.evaluateMonotoneCurve(points, xNorm)
        val px = xNorm * w
        val py = (1f - yNorm) * h
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
      }
      drawPath(
        path = path,
        color = curveColor,
        style = Stroke(width = 3.5f, cap = StrokeCap.Round),
      )

      // Control point handles
      points.forEachIndexed { idx, pt ->
        val px = pt.x * w
        val py = (1f - pt.y) * h
        val isSelected = idx == selectedPointIndex
        if (isSelected) {
          drawCircle(
            color = StudioCyan.copy(alpha = 0.35f),
            radius = 16f,
            center = Offset(px, py),
          )
        }
        drawCircle(
          color = ObsidianBg,
          radius = 9f,
          center = Offset(px, py),
        )
        drawCircle(
          color = if (isSelected) StudioCyan else curveColor,
          radius = 9f,
          center = Offset(px, py),
          style = Stroke(width = if (isSelected) 3.5f else 2.5f),
        )
      }
    }

    Text(
      text = "Tap graph to add point • Drag points to shape • Select interior point & tap trash to remove (${points.size} pts)",
      style = MaterialTheme.typography.labelSmall,
      color = StudioTextSecondary,
      modifier = Modifier.testTag("tone_curve_hint"),
    )
  }
}
