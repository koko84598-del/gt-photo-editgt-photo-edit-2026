package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import android.graphics.Bitmap
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.model.ImportedPhoto
import com.example.model.TextLayer
import com.example.ui.theme.StageMatte
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlin.math.roundToInt

@Composable
fun PhotoPreviewStage(
  importedPhoto: ImportedPhoto?,
  previewBitmap: Bitmap?,
  isLoadingPhoto: Boolean,
  isCropMode: Boolean,
  cropRect: CropRect,
  cropAspectRatio: CropAspectRatio,
  textLayers: List<TextLayer>,
  selectedLayerId: String?,
  onImportClick: () -> Unit,
  onCropRectChange: (CropRect) -> Unit,
  onSelectLayer: (String?) -> Unit,
  onMoveLayer: (String, Float, Float) -> Unit,
  onDuplicateSelected: (String) -> Unit,
  onDeleteSelected: (String) -> Unit,
  modifier: Modifier = Modifier,
  missingSourceMessage: String? = null,
  onRelinkPhoto: () -> Unit = {},
) {
  val selectedLayer = textLayers.firstOrNull { it.id == selectedLayerId }

  BoxWithConstraints(
    modifier =
      modifier
        .fillMaxSize()
        .padding(horizontal = 12.dp, vertical = 8.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(StageMatte)
        .border(1.dp, StudioOutline, RoundedCornerShape(18.dp))
        .drawBehind {
          // Subtle darkroom crosshair & radial glow
          drawRect(
            brush =
              Brush.radialGradient(
                colors = listOf(Color(0xFF141B29), StageMatte),
                center = Offset(size.width * 0.5f, size.height * 0.45f),
                radius = size.maxDimension * 0.7f,
              )
          )
          val gridStep = 32.dp.toPx()
          val lineColor = Color.White.copy(alpha = 0.025f)
          var x = gridStep
          while (x < size.width) {
            drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1f)
            x += gridStep
          }
          var y = gridStep
          while (y < size.height) {
            drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1f)
            y += gridStep
          }
        }
        .pointerInput(Unit) {
          detectTapGestures { onSelectLayer(null) }
        }
        .testTag("photo_preview_stage"),
    contentAlignment = Alignment.Center,
  ) {
    val density = LocalDensity.current
    val stageWidthPx = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
    val stageHeightPx = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)

    if (importedPhoto != null) {
      val displayBitmap = previewBitmap ?: importedPhoto.bitmap
      val imageBitmap = remember(displayBitmap) { displayBitmap.asImageBitmap() }
      Box(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Image(
          bitmap = imageBitmap,
          contentDescription = importedPhoto.displayName,
          contentScale = ContentScale.Fit,
          modifier = Modifier.fillMaxSize().testTag("imported_photo_image"),
        )
        if (isCropMode) {
          InteractiveCropOverlay(
            imageWidth = displayBitmap.width,
            imageHeight = displayBitmap.height,
            cropRect = cropRect,
            aspectRatio = cropAspectRatio,
            onCropRectChange = onCropRectChange,
          )
        }
      }
    } else if (!isLoadingPhoto && missingSourceMessage != null) {
      MissingSourceStageBanner(
        message = missingSourceMessage,
        onRelinkPhoto = onRelinkPhoto,
      )
    } else if (!isLoadingPhoto && textLayers.isEmpty()) {
      EmptyPhotoStagePrompt(
        isCompactHeight = maxHeight < 210.dp,
        onImportClick = onImportClick,
      )
    }

    // Independent draggable text layers (Burmese & English) shown when not in active Crop frame mode
    if (!isCropMode) {
      val maxTextWidth = (maxWidth - 24.dp).coerceAtLeast(120.dp)
      textLayers
        .filter { it.isVisible }
        .forEach { layer ->
          DraggableTextLayerOverlay(
            layer = layer,
            isSelected = layer.id == selectedLayerId,
            stageWidthPx = stageWidthPx,
            stageHeightPx = stageHeightPx,
            maxTextWidth = maxTextWidth,
            onSelect = { onSelectLayer(layer.id) },
            onMove = { dxPx, dyPx ->
              onMoveLayer(layer.id, dxPx / stageWidthPx, dyPx / stageHeightPx)
            },
          )
        }
    }

    // Floating quick actions when a layer is selected
    AnimatedVisibility(
      visible = selectedLayer != null && !isCropMode,
      enter = fadeIn(),
      exit = fadeOut(),
      modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
    ) {
      selectedLayer?.let { active ->
        Surface(
          color = StudioSurface.copy(alpha = 0.92f),
          shape = RoundedCornerShape(14.dp),
          border = BorderStroke(1.dp, StudioOutline),
          tonalElevation = 6.dp,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
          ) {
            if (active.isLocked) {
              Icon(
                imageVector = Icons.Outlined.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(16.dp).padding(start = 4.dp),
              )
            }
            IconButton(
              onClick = { onDuplicateSelected(active.id) },
              modifier = Modifier.size(48.dp).testTag("canvas_duplicate_layer_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.ContentCopy,
                contentDescription = stringResource(R.string.cd_duplicate_layer),
                tint = StudioTextPrimary,
                modifier = Modifier.size(18.dp),
              )
            }
            IconButton(
              onClick = { onDeleteSelected(active.id) },
              modifier = Modifier.size(48.dp).testTag("canvas_delete_layer_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.DeleteOutline,
                contentDescription = stringResource(R.string.cd_delete_layer),
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }
      }
    }

    if (isLoadingPhoto) {
      Surface(
        color = StudioSurface.copy(alpha = 0.85f),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, StudioOutline),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.5.dp,
            color = StudioCyan,
          )
          Text(
            text = "Decoding full-resolution image…",
            style = MaterialTheme.typography.bodyMedium,
            color = StudioTextPrimary,
          )
        }
      }
    }
  }
}

@Composable
private fun EmptyPhotoStagePrompt(isCompactHeight: Boolean, onImportClick: () -> Unit) {
  Column(
    modifier =
      Modifier.widthIn(max = 320.dp)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    if (!isCompactHeight) {
      Surface(
        shape = CircleShape,
        color = StudioSurfaceElevated,
        border = BorderStroke(1.dp, StudioCyan.copy(alpha = 0.4f)),
        modifier = Modifier.size(48.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Outlined.AddPhotoAlternate,
            contentDescription = null,
            tint = StudioCyan,
            modifier = Modifier.size(24.dp),
          )
        }
      }
      Spacer(modifier = Modifier.height(10.dp))
    }
    Text(
      text = stringResource(R.string.empty_preview_title),
      style = MaterialTheme.typography.titleMedium,
      color = StudioTextPrimary,
      textAlign = TextAlign.Center,
    )
    if (!isCompactHeight) {
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = stringResource(R.string.empty_preview_subtitle),
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        textAlign = TextAlign.Center,
        maxLines = 2,
      )
    }
    Spacer(modifier = Modifier.height(10.dp))
    Button(
      onClick = onImportClick,
      shape = RoundedCornerShape(12.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = StudioCyan,
          contentColor = MaterialTheme.colorScheme.onPrimary,
        ),
      modifier = Modifier.height(48.dp).testTag("import_photo_button"),
    ) {
      Icon(
        imageVector = Icons.Outlined.AddPhotoAlternate,
        contentDescription = null,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.size(8.dp))
      Text(
        text = stringResource(R.string.action_import_photo),
        style = MaterialTheme.typography.titleSmall,
      )
    }
  }
}

@Composable
private fun MissingSourceStageBanner(
  message: String,
  onRelinkPhoto: () -> Unit,
) {
  Surface(
    color = StudioSurfaceElevated.copy(alpha = 0.94f),
    shape = RoundedCornerShape(16.dp),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
    modifier = Modifier.widthIn(max = 320.dp).padding(16.dp).testTag("missing_source_banner"),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Text(
        text = "Original Photo Unavailable",
        style = MaterialTheme.typography.titleSmall,
        color = StudioTextPrimary,
        textAlign = TextAlign.Center,
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        textAlign = TextAlign.Center,
      )
      Button(
        onClick = onRelinkPhoto,
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.height(48.dp).testTag("relink_photo_button"),
      ) {
        Text(text = stringResource(R.string.action_relink_photo))
      }
    }
  }
}

@Composable
private fun DraggableTextLayerOverlay(
  layer: TextLayer,
  isSelected: Boolean,
  stageWidthPx: Float,
  stageHeightPx: Float,
  maxTextWidth: androidx.compose.ui.unit.Dp,
  onSelect: () -> Unit,
  onMove: (Float, Float) -> Unit,
) {
  val currentOnSelect by rememberUpdatedState(onSelect)
  val currentOnMove by rememberUpdatedState(onMove)
  val offsetX = ((layer.xFraction - 0.5f) * stageWidthPx).roundToInt()
  val offsetY = ((layer.yFraction - 0.5f) * stageHeightPx).roundToInt()

  Box(
    modifier =
      Modifier.offset { IntOffset(offsetX, offsetY) }
        .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
        .pointerInput(layer.id, layer.isLocked) {
          detectTapGestures(onTap = { currentOnSelect() })
        }
        .pointerInput(layer.id, layer.isLocked) {
          detectDragGestures(
            onDragStart = { currentOnSelect() },
            onDrag = { change, dragAmount ->
              change.consume()
              if (!layer.isLocked) {
                currentOnMove(dragAmount.x, dragAmount.y)
              }
            },
          )
        }
        .testTag("text_layer_${layer.id}"),
    contentAlignment = Alignment.Center,
  ) {
    Box(
      modifier =
        Modifier.widthIn(max = maxTextWidth)
          .graphicsLayer {
            rotationZ = layer.rotationDegrees
            alpha = layer.opacity
          }
          .then(
            if (isSelected) {
              Modifier.border(
                  width = 1.5.dp,
                  color = if (layer.isLocked) MaterialTheme.colorScheme.secondary else StudioCyan,
                  shape = RoundedCornerShape(8.dp),
                )
                .background(
                  color = Color.Black.copy(alpha = 0.22f),
                  shape = RoundedCornerShape(8.dp),
                )
            } else {
              Modifier
            }
          )
          .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
      Text(
        text = layer.text.ifEmpty { "…" },
        style =
          TextStyle(
            fontFamily = layer.font.fontFamily,
            fontSize = layer.fontSizeSp.sp,
            fontWeight = if (layer.isBold) FontWeight.Bold else FontWeight.Normal,
            fontStyle = if (layer.isItalic) FontStyle.Italic else FontStyle.Normal,
            color = Color(layer.colorArgb),
            textAlign = TextAlign.Center,
          ),
      )
    }
  }
}
