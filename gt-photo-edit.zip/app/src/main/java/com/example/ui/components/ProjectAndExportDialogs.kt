package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Redo
import androidx.compose.material.icons.automirrored.outlined.Undo
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.ImageProcessor
import com.example.model.CropTransformParams
import com.example.model.ExportFormat
import com.example.model.ImportedPhoto
import com.example.model.SavedProjectSummary
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBright
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.text.DateFormat
import java.util.Date
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun StudioUtilityBar(
  canUndo: Boolean,
  canRedo: Boolean,
  currentProjectName: String?,
  savedProjectCount: Int,
  onUndo: () -> Unit,
  onRedo: () -> Unit,
  onOpenSaveDialog: () -> Unit,
  onOpenProjectsDialog: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = StudioSurface,
    border = BorderStroke(1.dp, StudioOutline.copy(alpha = 0.7f)),
    shape = RoundedCornerShape(12.dp),
    modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp).testTag("studio_utility_bar"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onUndo,
          enabled = canUndo,
          modifier = Modifier.size(48.dp).testTag("undo_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.Undo,
            contentDescription = stringResource(R.string.cd_undo),
            tint = if (canUndo) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(20.dp),
          )
        }
        IconButton(
          onClick = onRedo,
          enabled = canRedo,
          modifier = Modifier.size(48.dp).testTag("redo_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Outlined.Redo,
            contentDescription = stringResource(R.string.cd_redo),
            tint = if (canRedo) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(20.dp),
          )
        }
      }

      if (!currentProjectName.isNullOrBlank()) {
        Text(
          text = currentProjectName,
          style = MaterialTheme.typography.labelSmall,
          color = StudioAmber,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).padding(horizontal = 6.dp).testTag("active_project_name"),
        )
      } else {
        Spacer(modifier = Modifier.weight(1f))
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        OutlinedButton(
          onClick = onOpenSaveDialog,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(48.dp).padding(vertical = 5.dp).testTag("save_project_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.BookmarkAdd,
            contentDescription = stringResource(R.string.cd_save_project),
            tint = StudioCyan,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Save",
            style = MaterialTheme.typography.labelMedium,
            color = StudioTextPrimary,
            maxLines = 1,
            softWrap = false,
          )
        }

        OutlinedButton(
          onClick = onOpenProjectsDialog,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(48.dp).padding(vertical = 5.dp).testTag("open_project_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.FolderOpen,
            contentDescription = stringResource(R.string.cd_open_project),
            tint = StudioTextPrimary,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (savedProjectCount > 0) "Open ($savedProjectCount)" else "Open",
            style = MaterialTheme.typography.labelMedium,
            color = StudioTextPrimary,
            maxLines = 1,
            softWrap = false,
          )
        }
      }
    }
  }
}

@Composable
private fun StudioModalDialog(
  title: String,
  onDismissRequest: () -> Unit,
  actions: @Composable RowScope.() -> Unit,
  content: @Composable ColumnScope.() -> Unit,
) {
  BackHandler(onBack = onDismissRequest)
  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(Color.Black.copy(alpha = 0.65f))
        .clickable(
          interactionSource = remember { MutableInteractionSource() },
          indication = null,
          onClick = onDismissRequest,
        )
        .imePadding()
        .padding(20.dp),
    contentAlignment = Alignment.Center,
  ) {
    Surface(
      color = StudioSurface,
      shape = RoundedCornerShape(22.dp),
      border = BorderStroke(1.dp, StudioOutline),
      tonalElevation = 6.dp,
      shadowElevation = 16.dp,
      modifier =
        Modifier.fillMaxWidth()
          .widthIn(min = 280.dp, max = 440.dp)
          .clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null,
            onClick = {},
          ),
    ) {
      Column(
        modifier = Modifier.padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = StudioTextPrimary,
        )
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(8.dp),
          content = content,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
          verticalAlignment = Alignment.CenterVertically,
          content = actions,
        )
      }
    }
  }
}

@Composable
fun SaveProjectDialog(
  initialName: String,
  onDismiss: () -> Unit,
  onConfirmSave: (String) -> Unit,
) {
  var name by remember(initialName) { mutableStateOf(initialName) }

  StudioModalDialog(
    title = "Save Project",
    onDismissRequest = onDismiss,
    actions = {
      TextButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text("Cancel", color = StudioTextSecondary)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Button(
        onClick = { onConfirmSave(name) },
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.height(48.dp).testTag("confirm_save_project_button"),
      ) {
        Text("Save")
      }
    },
  ) {
    Text(
      text = "Saves crop, transforms, adjustments, HSL, tone curves, color grading, and all text layers locally.",
      style = MaterialTheme.typography.bodyMedium,
      color = StudioTextSecondary,
    )
    OutlinedTextField(
      value = name,
      onValueChange = { name = it },
      label = { Text("Project Name") },
      singleLine = true,
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = StudioCyan,
          unfocusedBorderColor = StudioOutline,
          focusedTextColor = StudioTextPrimary,
          unfocusedTextColor = StudioTextPrimary,
          focusedContainerColor = StudioSurfaceElevated,
          unfocusedContainerColor = StudioSurfaceElevated,
        ),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth().testTag("project_name_input"),
    )
  }
}

@Composable
fun OpenProjectDialog(
  projects: List<SavedProjectSummary>,
  onDismiss: () -> Unit,
  onOpenProject: (String) -> Unit,
  onDeleteProject: (String) -> Unit,
) {
  StudioModalDialog(
    title = "Saved Projects",
    onDismissRequest = onDismiss,
    actions = {
      TextButton(onClick = onDismiss, modifier = Modifier.height(48.dp)) {
        Text("Close", color = StudioCyan)
      }
    },
  ) {
    if (projects.isEmpty()) {
      Surface(
        color = StudioSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioOutline),
        modifier = Modifier.fillMaxWidth().testTag("empty_projects_notice"),
      ) {
        Text(
          text = "No saved projects yet. Tap Save to store your current edit locally.",
          style = MaterialTheme.typography.bodyMedium,
          color = StudioTextSecondary,
          modifier = Modifier.padding(14.dp),
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        items(projects, key = { it.id }) { project ->
          val dateText =
            remember(project.updatedAtMillis) {
              DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                .format(Date(project.updatedAtMillis))
            }
          Surface(
            color = StudioSurfaceElevated,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, StudioOutline),
            modifier =
              Modifier.fillMaxWidth()
                .clickable { onOpenProject(project.id) }
                .testTag("open_project_item_${project.id}"),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.PhotoLibrary,
                contentDescription = null,
                tint = StudioCyan,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = project.name,
                  style = MaterialTheme.typography.titleSmall,
                  color = StudioTextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = "${project.sourceDisplayName} • ${project.layerCount} layers",
                  style = MaterialTheme.typography.labelSmall,
                  color = StudioTextSecondary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = dateText,
                  style = MaterialTheme.typography.labelSmall,
                  color = StudioTextSecondary.copy(alpha = 0.75f),
                )
              }
              IconButton(
                onClick = { onDeleteProject(project.id) },
                modifier = Modifier.size(48.dp).testTag("delete_project_${project.id}"),
              ) {
                Icon(
                  imageVector = Icons.Outlined.DeleteOutline,
                  contentDescription = stringResource(R.string.cd_delete_project),
                  tint = MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(18.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ExportGalleryDialog(
  importedPhoto: ImportedPhoto?,
  cropTransform: CropTransformParams,
  visibleLayerCount: Int,
  isExporting: Boolean,
  onDismiss: () -> Unit,
  onExport: (ExportFormat, Int) -> Unit,
) {
  var selectedFormat by remember { mutableStateOf(ExportFormat.JPEG) }
  var jpegQuality by remember { mutableFloatStateOf(95f) }

  val targetDimensions =
    remember(importedPhoto, cropTransform) {
      if (importedPhoto == null) {
        0 to 0
      } else {
        val (ow, oh) =
          ImageProcessor.orientedDimensions(
            importedPhoto.originalWidth.coerceAtLeast(importedPhoto.bitmap.width),
            importedPhoto.originalHeight.coerceAtLeast(importedPhoto.bitmap.height),
            cropTransform.rotation90Degrees,
          )
        val outW = max(1, (ow * cropTransform.cropRect.width).roundToInt())
        val outH = max(1, (oh * cropTransform.cropRect.height).roundToInt())
        outW to outH
      }
    }

  StudioModalDialog(
    title = "Export to Gallery",
    onDismissRequest = { if (!isExporting) onDismiss() },
    actions = {
      TextButton(
        onClick = onDismiss,
        enabled = !isExporting,
        modifier = Modifier.height(48.dp),
      ) {
        Text("Cancel", color = StudioTextSecondary)
      }
      Spacer(modifier = Modifier.width(8.dp))
      Button(
        onClick = { onExport(selectedFormat, jpegQuality.roundToInt()) },
        enabled = importedPhoto != null && !isExporting,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.height(48.dp).testTag("confirm_export_button"),
      ) {
        if (isExporting) {
          CircularProgressIndicator(
            modifier = Modifier.size(16.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.onPrimary,
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("Exporting…")
        } else {
          Text("Export")
        }
      }
    },
  ) {
    Column(
      modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Surface(
        color = StudioSurfaceBright,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioOutline),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(12.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = "Full Resolution: ${targetDimensions.first} × ${targetDimensions.second} px",
            style = MaterialTheme.typography.titleSmall,
            color = StudioCyan,
            modifier = Modifier.testTag("export_resolution_label"),
          )
          Text(
            text = "Includes all color edits, transforms, and $visibleLayerCount visible text layer(s).",
            style = MaterialTheme.typography.labelSmall,
            color = StudioTextSecondary,
          )
        }
      }

      HorizontalDivider(color = StudioOutline.copy(alpha = 0.6f))

      Text("Format", style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ExportFormat.entries.forEach { format ->
          FilterChip(
            selected = selectedFormat == format,
            onClick = { selectedFormat = format },
            label = { Text(format.label) },
            colors =
              FilterChipDefaults.filterChipColors(
                containerColor = StudioSurfaceElevated,
                labelColor = StudioTextSecondary,
                selectedContainerColor = StudioCyan.copy(alpha = 0.2f),
                selectedLabelColor = StudioCyan,
              ),
            modifier = Modifier.testTag("export_format_${format.name.lowercase()}"),
          )
        }
      }

      if (selectedFormat == ExportFormat.JPEG) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text("JPEG Quality", style = MaterialTheme.typography.labelMedium, color = StudioTextPrimary)
          Text(
            text = "${jpegQuality.roundToInt()}%",
            style = MaterialTheme.typography.labelSmall,
            color = StudioCyan,
            modifier = Modifier.testTag("export_quality_value"),
          )
        }
        Slider(
          value = jpegQuality,
          onValueChange = { jpegQuality = it },
          valueRange = 60f..100f,
          colors =
            SliderDefaults.colors(
              thumbColor = StudioCyan,
              activeTrackColor = StudioCyan,
              inactiveTrackColor = StudioOutline,
            ),
          modifier = Modifier.fillMaxWidth().testTag("export_quality_slider"),
        )
      } else {
        Text(
          text = "PNG exports losslessly and preserves transparency.",
          style = MaterialTheme.typography.labelSmall,
          color = StudioTextSecondary,
        )
      }
    }
  }
}
