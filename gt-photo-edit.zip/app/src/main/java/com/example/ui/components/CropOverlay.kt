package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.ui.theme.StudioCyan
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private enum class CropCorner {
  TOP_LEFT,
  TOP_RIGHT,
  BOTTOM_LEFT,
  BOTTOM_RIGHT,
}

@Composable
fun InteractiveCropOverlay(
  imageWidth: Int,
  imageHeight: Int,
  cropRect: CropRect,
  aspectRatio: CropAspectRatio,
  onCropRectChange: (CropRect) -> Unit,
  modifier: Modifier = Modifier,
) {
  if (imageWidth <= 0 || imageHeight <= 0) return

  BoxWithConstraints(modifier = modifier.fillMaxSize().testTag("interactive_crop_overlay")) {
    val density = LocalDensity.current
    val stageW = with(density) { maxWidth.toPx() }.coerceAtLeast(1f)
    val stageH = with(density) { maxHeight.toPx() }.coerceAtLeast(1f)

    // Compute exact fitted image rectangle inside the stage (matching ContentScale.Fit)
    val imgRatio = imageWidth.toFloat() / imageHeight.toFloat()
    val stageRatio = stageW / stageH
    val fittedW: Float
    val fittedH: Float
    if (imgRatio > stageRatio) {
      fittedW = stageW
      fittedH = stageW / imgRatio
    } else {
      fittedH = stageH
      fittedW = stageH * imgRatio
    }
    val offsetX = (stageW - fittedW) / 2f
    val offsetY = (stageH - fittedH) / 2f

    val currentRect by rememberUpdatedState(cropRect)
    val currentRatio by rememberUpdatedState(aspectRatio)
    val currentCallback by rememberUpdatedState(onCropRectChange)

    val lockedRatioNorm: Float? =
      when (aspectRatio) {
        CropAspectRatio.FREE -> null
        CropAspectRatio.ORIGINAL -> 1f // Normalized square in original image ratio == image ratio
        else -> (aspectRatio.ratio ?: 1f) / imgRatio
      }
    val currentLockedRatioNorm by rememberUpdatedState(lockedRatioNorm)

    val cropLeftPx = offsetX + cropRect.left * fittedW
    val cropTopPx = offsetY + cropRect.top * fittedH
    val cropRightPx = offsetX + cropRect.right * fittedW
    val cropBottomPx = offsetY + cropRect.bottom * fittedH
    val cropWidthPx = (cropRightPx - cropLeftPx).coerceAtLeast(1f)
    val cropHeightPx = (cropBottomPx - cropTopPx).coerceAtLeast(1f)

    // Scrim + crop frame + rule-of-thirds grid
    Canvas(modifier = Modifier.fillMaxSize()) {
      val cropPath =
        Path().apply {
          addRect(
            Rect(
              offset = Offset(cropLeftPx, cropTopPx),
              size = Size(cropWidthPx, cropHeightPx),
            )
          )
        }
      clipPath(cropPath, clipOp = ClipOp.Difference) {
        drawRect(
          color = Color.Black.copy(alpha = 0.62f),
          topLeft = Offset(offsetX, offsetY),
          size = Size(fittedW, fittedH),
        )
      }

      // Outer border
      drawRect(
        color = StudioCyan,
        topLeft = Offset(cropLeftPx, cropTopPx),
        size = Size(cropWidthPx, cropHeightPx),
        style = Stroke(width = 2.dp.toPx()),
      )

      // Rule of thirds lines
      val gridColor = Color.White.copy(alpha = 0.35f)
      val stroke1 = 1.dp.toPx()
      for (i in 1..2) {
        val x = cropLeftPx + cropWidthPx * (i / 3f)
        val y = cropTopPx + cropHeightPx * (i / 3f)
        drawLine(gridColor, Offset(x, cropTopPx), Offset(x, cropBottomPx), strokeWidth = stroke1)
        drawLine(gridColor, Offset(cropLeftPx, y), Offset(cropRightPx, y), strokeWidth = stroke1)
      }

      // Corner L-brackets
      val bracketLen = 16.dp.toPx()
      val bracketStroke = 3.5.dp.toPx()
      // Top-left
      drawLine(StudioCyan, Offset(cropLeftPx, cropTopPx), Offset(cropLeftPx + bracketLen, cropTopPx), bracketStroke)
      drawLine(StudioCyan, Offset(cropLeftPx, cropTopPx), Offset(cropLeftPx, cropTopPx + bracketLen), bracketStroke)
      // Top-right
      drawLine(StudioCyan, Offset(cropRightPx - bracketLen, cropTopPx), Offset(cropRightPx, cropTopPx), bracketStroke)
      drawLine(StudioCyan, Offset(cropRightPx, cropTopPx), Offset(cropRightPx, cropTopPx + bracketLen), bracketStroke)
      // Bottom-left
      drawLine(StudioCyan, Offset(cropLeftPx, cropBottomPx), Offset(cropLeftPx + bracketLen, cropBottomPx), bracketStroke)
      drawLine(StudioCyan, Offset(cropLeftPx, cropBottomPx - bracketLen), Offset(cropLeftPx, cropBottomPx), bracketStroke)
      // Bottom-right
      drawLine(StudioCyan, Offset(cropRightPx - bracketLen, cropBottomPx), Offset(cropRightPx, cropBottomPx), bracketStroke)
      drawLine(StudioCyan, Offset(cropRightPx, cropBottomPx - bracketLen), Offset(cropRightPx, cropBottomPx), bracketStroke)
    }

    // Pan gesture inside the crop box
    Box(
      modifier =
        Modifier.offset { IntOffset(cropLeftPx.roundToInt(), cropTopPx.roundToInt()) }
          .size(
            width = with(density) { cropWidthPx.toDp() },
            height = with(density) { cropHeightPx.toDp() },
          )
          .pointerInput(fittedW, fittedH) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              val r = currentRect
              val w = r.width
              val h = r.height
              val dx = dragAmount.x / fittedW
              val dy = dragAmount.y / fittedH
              val newLeft = (r.left + dx).coerceIn(0f, 1f - w)
              val newTop = (r.top + dy).coerceIn(0f, 1f - h)
              currentCallback(CropRect(newLeft, newTop, newLeft + w, newTop + h))
            }
          }
    )

    // 48dp touch targets at the 4 corners
    val handleSizePx = with(density) { 48.dp.toPx() }
    val halfHandle = handleSizePx / 2f

    CropCorner.entries.forEach { corner ->
      val cx =
        when (corner) {
          CropCorner.TOP_LEFT, CropCorner.BOTTOM_LEFT -> cropLeftPx
          CropCorner.TOP_RIGHT, CropCorner.BOTTOM_RIGHT -> cropRightPx
        }
      val cy =
        when (corner) {
          CropCorner.TOP_LEFT, CropCorner.TOP_RIGHT -> cropTopPx
          CropCorner.BOTTOM_LEFT, CropCorner.BOTTOM_RIGHT -> cropBottomPx
        }

      Box(
        modifier =
          Modifier.offset {
              IntOffset((cx - halfHandle).roundToInt(), (cy - halfHandle).roundToInt())
            }
            .size(48.dp)
            .pointerInput(corner, fittedW, fittedH, currentRatio) {
              detectDragGestures { change, dragAmount ->
                change.consume()
                val dx = dragAmount.x / fittedW
                val dy = dragAmount.y / fittedH
                val updated =
                  resizeCropRect(
                    rect = currentRect,
                    corner = corner,
                    dx = dx,
                    dy = dy,
                    lockedRatioNorm = currentLockedRatioNorm,
                  )
                currentCallback(updated)
              }
            }
            .testTag("crop_handle_${corner.name.lowercase()}")
      )
    }
  }
}

private fun resizeCropRect(
  rect: CropRect,
  corner: CropCorner,
  dx: Float,
  dy: Float,
  lockedRatioNorm: Float?,
): CropRect {
  val minSize = CropRect.MIN_SIZE
  var left = rect.left
  var top = rect.top
  var right = rect.right
  var bottom = rect.bottom

  when (corner) {
    CropCorner.TOP_LEFT -> {
      left = (left + dx).coerceIn(0f, right - minSize)
      top = (top + dy).coerceIn(0f, bottom - minSize)
      if (lockedRatioNorm != null) {
        val maxW = right
        val maxH = bottom
        var newW = right - left
        var newH = newW / lockedRatioNorm
        if (newH > maxH) {
          newH = maxH
          newW = newH * lockedRatioNorm
        }
        if (newW < minSize) {
          newW = minSize
          newH = newW / lockedRatioNorm
        }
        if (newH < minSize) {
          newH = minSize
          newW = newH * lockedRatioNorm
        }
        left = (right - min(maxW, newW)).coerceAtLeast(0f)
        top = (bottom - min(maxH, newH)).coerceAtLeast(0f)
      }
    }
    CropCorner.TOP_RIGHT -> {
      right = (right + dx).coerceIn(left + minSize, 1f)
      top = (top + dy).coerceIn(0f, bottom - minSize)
      if (lockedRatioNorm != null) {
        val maxW = 1f - left
        val maxH = bottom
        var newW = right - left
        var newH = newW / lockedRatioNorm
        if (newH > maxH) {
          newH = maxH
          newW = newH * lockedRatioNorm
        }
        if (newW < minSize) {
          newW = minSize
          newH = newW / lockedRatioNorm
        }
        if (newH < minSize) {
          newH = minSize
          newW = newH * lockedRatioNorm
        }
        right = (left + min(maxW, newW)).coerceAtMost(1f)
        top = (bottom - min(maxH, newH)).coerceAtLeast(0f)
      }
    }
    CropCorner.BOTTOM_LEFT -> {
      left = (left + dx).coerceIn(0f, right - minSize)
      bottom = (bottom + dy).coerceIn(top + minSize, 1f)
      if (lockedRatioNorm != null) {
        val maxW = right
        val maxH = 1f - top
        var newW = right - left
        var newH = newW / lockedRatioNorm
        if (newH > maxH) {
          newH = maxH
          newW = newH * lockedRatioNorm
        }
        if (newW < minSize) {
          newW = minSize
          newH = newW / lockedRatioNorm
        }
        if (newH < minSize) {
          newH = minSize
          newW = newH * lockedRatioNorm
        }
        left = (right - min(maxW, newW)).coerceAtLeast(0f)
        bottom = (top + min(maxH, newH)).coerceAtMost(1f)
      }
    }
    CropCorner.BOTTOM_RIGHT -> {
      right = (right + dx).coerceIn(left + minSize, 1f)
      bottom = (bottom + dy).coerceIn(top + minSize, 1f)
      if (lockedRatioNorm != null) {
        val maxW = 1f - left
        val maxH = 1f - top
        var newW = right - left
        var newH = newW / lockedRatioNorm
        if (newH > maxH) {
          newH = maxH
          newW = newH * lockedRatioNorm
        }
        if (newW < minSize) {
          newW = minSize
          newH = newW / lockedRatioNorm
        }
        if (newH < minSize) {
          newH = minSize
          newW = newH * lockedRatioNorm
        }
        right = (left + min(maxW, newW)).coerceAtMost(1f)
        bottom = (top + min(maxH, newH)).coerceAtMost(1f)
      }
    }
  }

  return CropRect(
    left = max(0f, left),
    top = max(0f, top),
    right = min(1f, right),
    bottom = min(1f, bottom),
  )
}
