package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.automirrored.outlined.ShowChart
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Title
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.outlined.Crop
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Title
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EditorCategory
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioCyanContainer
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary

@Composable
fun EditorBottomNavigation(
  activeCategory: EditorCategory,
  onSelectCategory: (EditorCategory) -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    color = StudioSurface,
    tonalElevation = 0.dp,
    modifier = modifier.fillMaxWidth().testTag("editor_bottom_nav"),
  ) {
    Column(modifier = Modifier.fillMaxWidth().windowInsetsPadding(WindowInsets.navigationBars)) {
      HorizontalDivider(color = StudioOutline.copy(alpha = 0.7f))
      BoxWithConstraints(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        val fitAllInRow = maxWidth >= 420.dp
        val rowModifier =
          if (fitAllInRow) {
            Modifier.fillMaxWidth().padding(horizontal = 4.dp)
          } else {
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp)
          }
        Row(
          modifier = rowModifier,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          EditorCategory.entries.forEach { category ->
            val selected = category == activeCategory
            val itemModifier =
              if (fitAllInRow) {
                Modifier.weight(1f).height(56.dp)
              } else {
                Modifier.width(54.dp).height(56.dp)
              }
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.Center,
              modifier =
                itemModifier
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { onSelectCategory(category) }
                  .padding(horizontal = 2.dp, vertical = 4.dp)
                  .testTag("nav_${category.name.lowercase()}"),
            ) {
              Box(
                contentAlignment = Alignment.Center,
                modifier =
                  Modifier.clip(RoundedCornerShape(10.dp))
                    .background(if (selected) StudioCyanContainer.copy(alpha = 0.65f) else Color.Transparent)
                    .padding(horizontal = 10.dp, vertical = 3.dp),
              ) {
                Icon(
                  imageVector = categoryIcon(category, selected),
                  contentDescription = category.label,
                  tint = if (selected) StudioCyan else StudioTextSecondary,
                  modifier = Modifier.size(20.dp),
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = category.label,
                style =
                  MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                  ),
                color = if (selected) StudioCyan else StudioTextSecondary,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun EditorSideRail(
  activeCategory: EditorCategory,
  onSelectCategory: (EditorCategory) -> Unit,
  modifier: Modifier = Modifier,
) {
  NavigationRail(
    modifier = modifier.testTag("editor_nav_rail"),
    containerColor = StudioSurface,
  ) {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
      EditorCategory.entries.forEach { category ->
        val selected = category == activeCategory
        NavigationRailItem(
          selected = selected,
          onClick = { onSelectCategory(category) },
          icon = {
            Icon(
              imageVector = categoryIcon(category, selected),
              contentDescription = category.label,
            )
          },
          label = { Text(category.label) },
          colors =
            NavigationRailItemDefaults.colors(
              selectedIconColor = StudioCyan,
              selectedTextColor = StudioCyan,
              indicatorColor = StudioCyanContainer.copy(alpha = 0.6f),
              unselectedIconColor = StudioTextSecondary,
              unselectedTextColor = StudioTextPrimary,
            ),
          modifier = Modifier.testTag("nav_${category.name.lowercase()}"),
        )
      }
    }
  }
}

private fun categoryIcon(category: EditorCategory, selected: Boolean): ImageVector =
  when (category) {
    EditorCategory.PHOTO ->
      if (selected) Icons.Filled.PhotoLibrary else Icons.Outlined.PhotoLibrary
    EditorCategory.CROP -> if (selected) Icons.Filled.Crop else Icons.Outlined.Crop
    EditorCategory.ADJUST -> if (selected) Icons.Filled.Tune else Icons.Outlined.Tune
    EditorCategory.HSL -> if (selected) Icons.Filled.Palette else Icons.Outlined.Palette
    EditorCategory.CURVE ->
      if (selected) Icons.AutoMirrored.Filled.ShowChart else Icons.AutoMirrored.Outlined.ShowChart
    EditorCategory.GRADING -> if (selected) Icons.Filled.ColorLens else Icons.Outlined.ColorLens
    EditorCategory.TEXT -> if (selected) Icons.Filled.Title else Icons.Outlined.Title
    EditorCategory.LAYERS -> if (selected) Icons.Filled.Layers else Icons.Outlined.Layers
  }
