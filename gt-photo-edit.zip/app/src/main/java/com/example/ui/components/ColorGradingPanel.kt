package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ColorGradeWheel
import com.example.model.ColorGradingParams
import com.example.model.GradingRange
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun ColorGradingPanel(
  hasPhoto: Boolean,
  colorGrading: ColorGradingParams,
  maxContentHeight: Dp,
  onUpdateRange: (GradingRange, ColorGradeWheel) -> Unit,
  onResetRange: (GradingRange) -> Unit,
  onResetAll: () -> Unit,
) {
  if (!hasPhoto) {
    Surface(
      color = StudioSurfaceElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, StudioOutline),
      modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("grading_no_photo_hint"),
    ) {
      Text(
        text = "Import a photo first to color grade Shadows, Midtones, and Highlights.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        modifier = Modifier.padding(14.dp),
      )
    }
    return
  }

  var activeRange by remember { mutableStateOf(GradingRange.SHADOWS) }
  val activeWheel = colorGrading.forRange(activeRange)

  val currentRangeState by rememberUpdatedState(activeRange)
  val currentWheelState by rememberUpdatedState(activeWheel)

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("color_grading_panel"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // Tonal Range Selector + Reset Selected Range + Reset All
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        modifier = Modifier.weight(1f),
      ) {
        items(GradingRange.entries) { range ->
          val modified = !colorGrading.forRange(range).isIdentity
          FilterChip(
            selected = activeRange == range,
            onClick = { activeRange = range },
            label = {
              Text(
                text = if (modified) "${range.label} •" else range.label,
                style = MaterialTheme.typography.labelMedium,
              )
            },
            colors =
              FilterChipDefaults.filterChipColors(
                containerColor = StudioSurfaceElevated,
                labelColor = StudioTextSecondary,
                selectedContainerColor = StudioCyan.copy(alpha = 0.2f),
                selectedLabelColor = StudioCyan,
              ),
            modifier = Modifier.testTag("grading_range_${range.name.lowercase()}"),
          )
        }
      }

      Spacer(modifier = Modifier.width(4.dp))

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        IconButton(
          onClick = { onResetRange(activeRange) },
          enabled = !activeWheel.isIdentity,
          modifier = Modifier.size(48.dp).testTag("reset_grading_range_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.RestartAlt,
            contentDescription = stringResource(R.string.cd_reset_color_range),
            tint = if (!activeWheel.isIdentity) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp),
          )
        }

        OutlinedButton(
          onClick = onResetAll,
          enabled = !colorGrading.isIdentity,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(36.dp).testTag("reset_all_grading_button"),
        ) {
          Text(
            text = "Reset All",
            style = MaterialTheme.typography.labelMedium,
            color = if (colorGrading.isIdentity) StudioTextSecondary else StudioAmber,
          )
        }
      }
    }

    // Color Wheel + Hue / Saturation / Luminance controls side-by-side
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val wheelSize = if (maxWidth < 340.dp) 108.dp else 124.dp
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        // Interactive HSV Color Wheel
        Canvas(
          modifier =
            Modifier.size(wheelSize)
            .pointerInput(activeRange) {
              awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val cx = size.width * 0.5f
                val cy = size.height * 0.5f
                val maxR = min(cx, cy).coerceAtLeast(1f)

                fun updateFromOffset(pos: Offset) {
                  val dx = pos.x - cx
                  val dy = pos.y - cy
                  val deg = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
                  val sat = (hypot(dx, dy) / maxR).coerceIn(0f, 1f)
                  onUpdateRange(
                    currentRangeState,
                    currentWheelState.copy(hueDegrees = deg, saturation = sat),
                  )
                }

                updateFromOffset(down.position)
                down.consume()
                drag(down.id) { change ->
                  updateFromOffset(change.position)
                  change.consume()
                }
              }
            }
            .testTag("grading_color_wheel")
      ) {
        val radius = min(size.width, size.height) * 0.5f - 4f
        val centerOffset = Offset(size.width * 0.5f, size.height * 0.5f)

        val sweep =
          Brush.sweepGradient(
            colors =
              listOf(
                Color(0xFFFF0000),
                Color(0xFFFFFF00),
                Color(0xFF00FF00),
                Color(0xFF00FFFF),
                Color(0xFF0000FF),
                Color(0xFFFF00FF),
                Color(0xFFFF0000),
              ),
            center = centerOffset,
          )
        drawCircle(brush = sweep, radius = radius, center = centerOffset)

        val radialWhite =
          Brush.radialGradient(
            colors = listOf(Color.White, Color.White.copy(alpha = 0f)),
            center = centerOffset,
            radius = radius,
          )
        drawCircle(brush = radialWhite, radius = radius, center = centerOffset)

        drawCircle(
          color = StudioOutline,
          radius = radius,
          center = centerOffset,
          style = Stroke(width = 2.5f),
        )

        // Subtle crosshair
        drawLine(
          color = ObsidianBg.copy(alpha = 0.35f),
          start = Offset(centerOffset.x - 8f, centerOffset.y),
          end = Offset(centerOffset.x + 8f, centerOffset.y),
          strokeWidth = 1.5f,
        )
        drawLine(
          color = ObsidianBg.copy(alpha = 0.35f),
          start = Offset(centerOffset.x, centerOffset.y - 8f),
          end = Offset(centerOffset.x, centerOffset.y + 8f),
          strokeWidth = 1.5f,
        )

        // Puck position
        val rad = activeWheel.hueDegrees * PI.toFloat() / 180f
        val puckR = activeWheel.saturation.coerceIn(0f, 1f) * radius
        val puckCenter = Offset(centerOffset.x + cos(rad) * puckR, centerOffset.y + sin(rad) * puckR)
        drawCircle(color = ObsidianBg, radius = 9f, center = puckCenter)
        drawCircle(color = Color.White, radius = 6.5f, center = puckCenter)
      }

      // Precision Hue, Saturation, Luminance Sliders
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        GradingSliderRow(
          label = "Hue",
          valueText = "${activeWheel.hueDegrees.roundToInt()}°",
          value = activeWheel.hueDegrees,
          valueRange = 0f..360f,
          sliderTag = "grading_hue_slider",
          isActive = activeWheel.saturation > 0.01f,
          onValueChange = { onUpdateRange(activeRange, activeWheel.copy(hueDegrees = it)) },
        )
        GradingSliderRow(
          label = "Sat",
          valueText = "${(activeWheel.saturation * 100f).roundToInt()}%",
          value = activeWheel.saturation,
          valueRange = 0f..1f,
          sliderTag = "grading_saturation_slider",
          isActive = activeWheel.saturation > 0.01f,
          onValueChange = { onUpdateRange(activeRange, activeWheel.copy(saturation = it)) },
        )
        val lumPct = (activeWheel.luminance * 100f).roundToInt()
        GradingSliderRow(
          label = "Lum",
          valueText = if (lumPct > 0) "+$lumPct" else "$lumPct",
          value = activeWheel.luminance,
          valueRange = -1f..1f,
          sliderTag = "grading_luminance_slider",
          isActive = kotlin.math.abs(activeWheel.luminance) > 0.01f,
          onValueChange = { onUpdateRange(activeRange, activeWheel.copy(luminance = it)) },
        )
      }
      }
    }
  }
}

@Composable
private fun GradingSliderRow(
  label: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  sliderTag: String,
  isActive: Boolean,
  onValueChange: (Float) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = StudioTextSecondary,
      modifier = Modifier.width(30.dp),
    )
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      colors =
        SliderDefaults.colors(
          thumbColor = StudioCyan,
          activeTrackColor = StudioCyan,
          inactiveTrackColor = StudioOutline,
        ),
      modifier = Modifier.weight(1f).testTag(sliderTag),
    )
    Text(
      text = valueText,
      style = MaterialTheme.typography.labelSmall,
      color = if (isActive) StudioCyan else StudioTextPrimary,
      modifier = Modifier.width(38.dp),
    )
  }
}
