package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AdjustmentType
import com.example.model.ColorAdjustments
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun ColorAdjustmentsPanel(
  hasPhoto: Boolean,
  adjustments: ColorAdjustments,
  maxContentHeight: Dp,
  onUpdateAdjustment: (AdjustmentType, Float) -> Unit,
  onResetAdjustment: (AdjustmentType) -> Unit,
  onResetAll: () -> Unit,
) {
  if (!hasPhoto) {
    Surface(
      color = StudioSurfaceElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, StudioOutline),
      modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("adjust_no_photo_hint"),
    ) {
      Text(
        text = "Import a photo first to adjust Exposure, Brightness, Contrast, Highlights, Shadows, Temperature, and more.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        modifier = Modifier.padding(14.dp),
      )
    }
    return
  }

  var activeType by remember { mutableStateOf(AdjustmentType.BRIGHTNESS) }
  val activeValue = adjustments.valueFor(activeType)

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("adjust_panel"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // Active slider header + Reset individual + Reset All
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Text(
          text = activeType.label,
          style = MaterialTheme.typography.titleSmall,
          color = StudioTextPrimary,
        )
        Text(
          text = formatAdjustmentValue(activeType, activeValue),
          style = MaterialTheme.typography.labelSmall,
          color = if (abs(activeValue) > 0.001f) StudioCyan else StudioTextSecondary,
          modifier = Modifier.testTag("active_adjustment_value"),
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        IconButton(
          onClick = { onResetAdjustment(activeType) },
          enabled = abs(activeValue) > 0.001f,
          modifier = Modifier.size(48.dp).testTag("reset_single_adjustment_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.RestartAlt,
            contentDescription = stringResource(R.string.cd_reset_adjustment),
            tint = if (abs(activeValue) > 0.001f) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp),
          )
        }

        OutlinedButton(
          onClick = onResetAll,
          enabled = !adjustments.isIdentity,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(48.dp).padding(vertical = 6.dp).testTag("reset_all_adjustments_button"),
        ) {
          Text(
            text = "Reset All",
            style = MaterialTheme.typography.labelMedium,
            color = if (adjustments.isIdentity) StudioTextSecondary else StudioAmber,
            maxLines = 1,
            softWrap = false,
          )
        }
      }
    }

    // Active precision slider
    Slider(
      value = activeValue,
      onValueChange = { onUpdateAdjustment(activeType, it) },
      valueRange = activeType.min..activeType.max,
      colors =
        SliderDefaults.colors(
          thumbColor = StudioCyan,
          activeTrackColor = StudioCyan,
          inactiveTrackColor = StudioOutline,
        ),
      modifier = Modifier.fillMaxWidth().testTag("active_adjustment_slider"),
    )

    // Selector chips for all 12 adjustments
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      contentPadding = PaddingValues(end = 8.dp),
    ) {
      items(AdjustmentType.entries) { type ->
        val value = adjustments.valueFor(type)
        val isModified = abs(value) > 0.001f
        val isSelected = activeType == type
        FilterChip(
          selected = isSelected,
          onClick = { activeType = type },
          label = {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(type.label)
              if (isModified) {
                Text(
                  text = formatAdjustmentValue(type, value),
                  style = MaterialTheme.typography.labelSmall,
                  color = if (isSelected) StudioCyan else StudioAmber,
                )
              }
            }
          },
          colors =
            FilterChipDefaults.filterChipColors(
              containerColor = StudioSurfaceElevated,
              labelColor = StudioTextSecondary,
              selectedContainerColor = StudioCyan.copy(alpha = 0.2f),
              selectedLabelColor = StudioCyan,
            ),
          modifier = Modifier.testTag("adj_chip_${type.name.lowercase()}"),
        )
      }
    }

    // Full scrollable overview list of all 12 controls with individual reset buttons
    LazyColumn(
      modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      items(AdjustmentType.entries, key = { it.name }) { type ->
        val v = adjustments.valueFor(type)
        val modified = abs(v) > 0.001f
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = type.label,
            style = MaterialTheme.typography.labelMedium,
            color = if (modified) StudioCyan else StudioTextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.width(78.dp),
          )
          Slider(
            value = v,
            onValueChange = {
              activeType = type
              onUpdateAdjustment(type, it)
            },
            valueRange = type.min..type.max,
            colors =
              SliderDefaults.colors(
                thumbColor = StudioCyan,
                activeTrackColor = StudioCyan,
                inactiveTrackColor = StudioOutline,
              ),
            modifier = Modifier.weight(1f).testTag("adj_slider_${type.name.lowercase()}"),
          )
          Text(
            text = formatAdjustmentValue(type, v),
            style = MaterialTheme.typography.labelSmall,
            color = StudioTextPrimary,
            maxLines = 1,
            modifier = Modifier.width(44.dp),
          )
          IconButton(
            onClick = { onResetAdjustment(type) },
            enabled = modified,
            modifier = Modifier.size(48.dp).testTag("adj_reset_${type.name.lowercase()}"),
          ) {
            Icon(
              imageVector = Icons.Outlined.RestartAlt,
              contentDescription = stringResource(R.string.cd_reset_adjustment),
              tint = if (modified) StudioCyan else StudioTextSecondary.copy(alpha = 0.28f),
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
    }
  }
}

fun formatAdjustmentValue(type: AdjustmentType, value: Float): String {
  return when (type) {
    AdjustmentType.EXPOSURE -> {
      val sign = if (value > 0.005f) "+" else ""
      String.format(Locale.US, "%s%.2f%s", sign, value, type.suffix)
    }
    AdjustmentType.HUE -> {
      val rounded = value.roundToInt()
      val sign = if (rounded > 0) "+" else ""
      "$sign$rounded${type.suffix}"
    }
    AdjustmentType.VIGNETTE, AdjustmentType.GRAIN -> {
      "${(value * 100f).roundToInt()}%"
    }
    else -> {
      val pct = (value * 100f).roundToInt()
      val sign = if (pct > 0) "+" else ""
      "$sign$pct"
    }
  }
}
