package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.HslAdjustment
import com.example.model.HslColorRange
import com.example.model.HslMixerParams
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import kotlin.math.roundToInt

@Composable
fun HslMixerPanel(
  hasPhoto: Boolean,
  hslMixer: HslMixerParams,
  maxContentHeight: Dp,
  onUpdateRange: (HslColorRange, HslAdjustment) -> Unit,
  onResetRange: (HslColorRange) -> Unit,
  onResetAll: () -> Unit,
) {
  if (!hasPhoto) {
    Surface(
      color = StudioSurfaceElevated,
      shape = RoundedCornerShape(12.dp),
      border = BorderStroke(1.dp, StudioOutline),
      modifier = Modifier.fillMaxWidth().padding(16.dp).testTag("hsl_no_photo_hint"),
    ) {
      Text(
        text = "Import a photo first to adjust Red, Orange, Yellow, Green, Aqua, Blue, Purple, and Magenta HSL channels.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
        modifier = Modifier.padding(14.dp),
      )
    }
    return
  }

  var activeRange by remember { mutableStateOf(HslColorRange.RED) }
  val activeAdj = hslMixer.forRange(activeRange)

  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("hsl_panel"),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // Header: Selected color badge + Reset Selected + Reset All
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier =
            Modifier.size(14.dp)
              .clip(CircleShape)
              .background(Color(activeRange.swatchArgb))
              .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
        )
        Text(
          text = activeRange.label,
          style = MaterialTheme.typography.titleSmall,
          color = StudioTextPrimary,
          modifier = Modifier.testTag("hsl_active_range_label"),
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        IconButton(
          onClick = { onResetRange(activeRange) },
          enabled = !activeAdj.isIdentity,
          modifier = Modifier.size(48.dp).testTag("reset_hsl_range_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.RestartAlt,
            contentDescription = stringResource(R.string.cd_reset_color_range),
            tint = if (!activeAdj.isIdentity) StudioCyan else StudioTextSecondary.copy(alpha = 0.35f),
            modifier = Modifier.size(18.dp),
          )
        }

        OutlinedButton(
          onClick = onResetAll,
          enabled = !hslMixer.isIdentity,
          shape = RoundedCornerShape(10.dp),
          border = BorderStroke(1.dp, StudioOutline),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
          modifier = Modifier.height(36.dp).testTag("reset_all_hsl_button"),
        ) {
          Text(
            text = "Reset All",
            style = MaterialTheme.typography.labelMedium,
            color = if (hslMixer.isIdentity) StudioTextSecondary else StudioAmber,
          )
        }
      }
    }

    // 8 Selectable Color Swatches
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(4.dp),
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.fillMaxWidth(),
    ) {
      items(HslColorRange.entries) { range ->
        val isSelected = range == activeRange
        val isModified = !hslMixer.forRange(range).isIdentity
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier =
            Modifier.size(48.dp)
              .clip(RoundedCornerShape(12.dp))
              .clickable { activeRange = range }
              .background(if (isSelected) StudioSurfaceElevated else Color.Transparent)
              .border(
                width = if (isSelected) 1.5.dp else 0.dp,
                color = if (isSelected) StudioCyan else Color.Transparent,
                shape = RoundedCornerShape(12.dp),
              )
              .padding(top = 6.dp)
              .testTag("hsl_swatch_${range.name.lowercase()}"),
        ) {
          Box(
            modifier =
              Modifier.size(26.dp)
                .clip(CircleShape)
                .background(Color(range.swatchArgb))
                .border(
                  width = if (isSelected) 2.dp else 1.dp,
                  color = if (isSelected) Color.White else StudioOutline,
                  shape = CircleShape,
                )
          )
          Spacer(modifier = Modifier.height(3.dp))
          Box(
            modifier =
              Modifier.size(5.dp)
                .clip(CircleShape)
                .background(if (isModified) StudioAmber else Color.Transparent)
          )
        }
      }
    }

    // Independent Hue, Saturation, and Luminance Sliders (-100 to +100)
    HslValueSlider(
      label = "Hue",
      value = activeAdj.hue,
      sliderTag = "hsl_hue_slider",
      valueTag = "hsl_hue_value",
      accentColor = Color(activeRange.swatchArgb),
      onValueChange = { newHue ->
        onUpdateRange(activeRange, activeAdj.copy(hue = newHue))
      },
    )

    HslValueSlider(
      label = "Saturation",
      value = activeAdj.saturation,
      sliderTag = "hsl_saturation_slider",
      valueTag = "hsl_saturation_value",
      accentColor = Color(activeRange.swatchArgb),
      onValueChange = { newSat ->
        onUpdateRange(activeRange, activeAdj.copy(saturation = newSat))
      },
    )

    HslValueSlider(
      label = "Luminance",
      value = activeAdj.luminance,
      sliderTag = "hsl_luminance_slider",
      valueTag = "hsl_luminance_value",
      accentColor = Color(activeRange.swatchArgb),
      onValueChange = { newLum ->
        onUpdateRange(activeRange, activeAdj.copy(luminance = newLum))
      },
    )
  }
}

@Composable
private fun HslValueSlider(
  label: String,
  value: Float,
  sliderTag: String,
  valueTag: String,
  accentColor: Color,
  onValueChange: (Float) -> Unit,
) {
  val rounded = value.roundToInt()
  val formatted = if (rounded > 0) "+$rounded" else "$rounded"
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = StudioTextSecondary,
      modifier = Modifier.width(74.dp),
    )
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = -100f..100f,
      colors =
        SliderDefaults.colors(
          thumbColor = accentColor,
          activeTrackColor = accentColor,
          inactiveTrackColor = StudioOutline,
        ),
      modifier = Modifier.weight(1f).testTag(sliderTag),
    )
    Text(
      text = formatted,
      style = MaterialTheme.typography.labelSmall,
      color = if (rounded != 0) StudioCyan else StudioTextPrimary,
      modifier = Modifier.width(38.dp).testTag(valueTag),
    )
  }
}
