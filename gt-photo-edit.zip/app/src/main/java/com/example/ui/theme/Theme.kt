package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val DarkStudioColorScheme =
  darkColorScheme(
    primary = StudioCyan,
    onPrimary = StudioOnCyan,
    primaryContainer = StudioCyanContainer,
    onPrimaryContainer = StudioTextPrimary,
    secondary = StudioAmber,
    onSecondary = StudioOnAmber,
    secondaryContainer = StudioAmberContainer,
    onSecondaryContainer = StudioTextPrimary,
    background = ObsidianBg,
    onBackground = StudioTextPrimary,
    surface = StudioSurface,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = StudioTextSecondary,
    surfaceContainerLowest = StageMatte,
    surfaceContainerLow = StudioSurface,
    surfaceContainer = StudioSurfaceElevated,
    surfaceContainerHigh = StudioSurfaceBright,
    outline = StudioOutline,
    outlineVariant = StudioOutlineSubtle,
    error = StudioCoral,
    onError = StudioTextPrimary,
    errorContainer = StudioCoralContainer,
    onErrorContainer = StudioTextPrimary,
  )

private val StudioShapes =
  Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
  )

@Composable
fun GTPhotoEditTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = DarkStudioColorScheme,
    typography = GTPhotoTypography,
    shapes = StudioShapes,
    content = content,
  )
}
