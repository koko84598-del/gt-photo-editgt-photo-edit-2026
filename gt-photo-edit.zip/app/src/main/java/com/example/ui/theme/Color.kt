package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Darkroom Studio Palette
val ObsidianBg = Color(0xFF0B0D12)
val StageMatte = Color(0xFF07090D)
val StudioSurface = Color(0xFF13161F)
val StudioSurfaceElevated = Color(0xFF1B202C)
val StudioSurfaceBright = Color(0xFF252C3B)
val StudioOutline = Color(0xFF2D3548)
val StudioOutlineSubtle = Color(0xFF1E2433)

val StudioCyan = Color(0xFF38BDF8)
val StudioCyanDark = Color(0xFF0284C7)
val StudioCyanContainer = Color(0xFF0C4A6E)
val StudioOnCyan = Color(0xFF041E2B)

val StudioAmber = Color(0xFFF59E0B)
val StudioAmberContainer = Color(0xFF78350F)
val StudioOnAmber = Color(0xFF261200)

val StudioCoral = Color(0xFFFB7185)
val StudioCoralContainer = Color(0xFF4C0519)

val StudioTextPrimary = Color(0xFFF1F5F9)
val StudioTextSecondary = Color(0xFF94A3B8)
val StudioTextMuted = Color(0xFF64748B)

val TextLayerPalette =
  listOf(
    0xFFFFFFFF, // Pure White
    0xFF0F172A, // Deep Slate
    0xFF38BDF8, // Electric Cyan
    0xFFF59E0B, // Studio Amber
    0xFFFB7185, // Coral Rose
    0xFF34D399, // Emerald
    0xFFA78BFA, // Violet
    0xFFFDE047, // Warm Sun
    0xFFF97316, // Tangerine
    0xFFE2E8F0, // Silver Mist
  )
