package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AddPhotoAlternate
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.FormatBold
import androidx.compose.material.icons.outlined.FormatItalic
import androidx.compose.material.icons.outlined.HideImage
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AdjustmentType
import com.example.model.ColorGradeWheel
import com.example.model.CropAspectRatio
import com.example.model.CurvePoint
import com.example.model.EditorCategory
import com.example.model.EditorFont
import com.example.model.EditorUiState
import com.example.model.GradingRange
import com.example.model.HslAdjustment
import com.example.model.HslColorRange
import com.example.model.TextLayer
import com.example.model.ToneCurveChannel
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioOutline
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceBright
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.StudioTextMuted
import com.example.ui.theme.StudioTextPrimary
import com.example.ui.theme.StudioTextSecondary
import com.example.ui.theme.TextLayerPalette
import kotlin.math.roundToInt

@Composable
fun CenterEditingWorkspace(
  uiState: EditorUiState,
  onTogglePanelExpanded: () -> Unit,
  onImportPhoto: () -> Unit,
  onClearPhoto: () -> Unit,
  onSelectAspectRatio: (CropAspectRatio) -> Unit,
  onRotate90: () -> Unit,
  onSelectRotation90: (Int) -> Unit,
  onToggleFlipHorizontal: () -> Unit,
  onToggleFlipVertical: () -> Unit,
  onUpdateStraighten: (Float) -> Unit,
  onUpdatePerspectiveV: (Float) -> Unit,
  onUpdatePerspectiveH: (Float) -> Unit,
  onResetTransform: () -> Unit,
  onUpdateColorAdjustment: (AdjustmentType, Float) -> Unit,
  onResetColorAdjustment: (AdjustmentType) -> Unit,
  onResetAllColorAdjustments: () -> Unit,
  onUpdateHslRange: (HslColorRange, HslAdjustment) -> Unit,
  onResetHslRange: (HslColorRange) -> Unit,
  onResetAllHsl: () -> Unit,
  onAddToneCurvePoint: (ToneCurveChannel, CurvePoint) -> Unit,
  onUpdateToneCurvePoint: (ToneCurveChannel, Int, CurvePoint) -> Unit,
  onRemoveToneCurvePoint: (ToneCurveChannel, Int) -> Unit,
  onResetToneCurveChannel: (ToneCurveChannel) -> Unit,
  onResetAllToneCurves: () -> Unit,
  onUpdateColorGrading: (GradingRange, ColorGradeWheel) -> Unit,
  onResetColorGradingRange: (GradingRange) -> Unit,
  onResetAllColorGrading: () -> Unit,
  onAddTextLayer: (String, EditorFont) -> Unit,
  onUpdateSelectedText: (String) -> Unit,
  onSelectFont: (String, EditorFont) -> Unit,
  onUpdateFontSize: (String, Float) -> Unit,
  onUpdateRotation: (String, Float) -> Unit,
  onUpdateOpacity: (String, Float) -> Unit,
  onUpdateColor: (String, Long) -> Unit,
  onToggleBold: (String) -> Unit,
  onToggleItalic: (String) -> Unit,
  onSelectLayer: (String) -> Unit,
  onDuplicateLayer: (String) -> Unit,
  onDeleteLayer: (String) -> Unit,
  onToggleVisibility: (String) -> Unit,
  onToggleLock: (String) -> Unit,
  onMoveLayerOrder: (String, Boolean) -> Unit,
  modifier: Modifier = Modifier,
  maxContentHeight: androidx.compose.ui.unit.Dp = 240.dp,
) {
  Surface(
    modifier = modifier.fillMaxWidth().testTag("center_editing_workspace"),
    color = StudioSurface,
    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
    border = BorderStroke(1.dp, StudioOutline),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      // Panel header bar
      Row(
        modifier =
          Modifier.fillMaxWidth()
            .clickable(onClick = onTogglePanelExpanded)
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier.size(width = 6.dp, height = 16.dp)
                .clip(CircleShape)
                .background(StudioCyan)
          )
          Text(
            text =
              when (uiState.activeCategory) {
                EditorCategory.PHOTO -> "Photo Import & Canvas"
                EditorCategory.CROP -> "Crop & Transform"
                EditorCategory.ADJUST -> "Color Adjustments"
                EditorCategory.HSL -> "HSL Color Mixer"
                EditorCategory.CURVE -> "RGB Tone Curve"
                EditorCategory.GRADING -> "Color Grading"
                EditorCategory.TEXT -> "Text Studio (Burmese & English)"
                EditorCategory.LAYERS -> "Layers (${uiState.textLayers.size})"
              },
            style = MaterialTheme.typography.titleSmall,
            color = StudioTextPrimary,
          )
        }
        IconButton(
          onClick = onTogglePanelExpanded,
          modifier = Modifier.size(48.dp).testTag("toggle_panel_button"),
        ) {
          Icon(
            imageVector =
              if (uiState.isPanelExpanded) Icons.Outlined.ExpandMore else Icons.Outlined.ExpandLess,
            contentDescription = stringResource(R.string.cd_toggle_panel),
            tint = StudioTextSecondary,
          )
        }
      }

      if (uiState.isPanelExpanded) {
        HorizontalDivider(color = StudioOutline.copy(alpha = 0.7f))
        AnimatedContent(
          targetState = uiState.activeCategory,
          transitionSpec = { fadeIn() togetherWith fadeOut() },
          label = "editing_panel_switch",
        ) { category ->
          when (category) {
            EditorCategory.PHOTO ->
              PhotoToolPanel(
                uiState = uiState,
                maxContentHeight = maxContentHeight,
                onImportPhoto = onImportPhoto,
                onClearPhoto = onClearPhoto,
              )
            EditorCategory.CROP ->
              CropTransformPanel(
                hasPhoto = uiState.importedPhoto != null,
                cropTransform = uiState.cropTransform,
                maxContentHeight = maxContentHeight,
                onSelectAspectRatio = onSelectAspectRatio,
                onRotate90 = onRotate90,
                onSelectRotation90 = onSelectRotation90,
                onToggleFlipHorizontal = onToggleFlipHorizontal,
                onToggleFlipVertical = onToggleFlipVertical,
                onUpdateStraighten = onUpdateStraighten,
                onUpdatePerspectiveV = onUpdatePerspectiveV,
                onUpdatePerspectiveH = onUpdatePerspectiveH,
                onResetTransform = onResetTransform,
              )
            EditorCategory.ADJUST ->
              ColorAdjustmentsPanel(
                hasPhoto = uiState.importedPhoto != null,
                adjustments = uiState.colorAdjustments,
                maxContentHeight = maxContentHeight,
                onUpdateAdjustment = onUpdateColorAdjustment,
                onResetAdjustment = onResetColorAdjustment,
                onResetAll = onResetAllColorAdjustments,
              )
            EditorCategory.HSL ->
              HslMixerPanel(
                hasPhoto = uiState.importedPhoto != null,
                hslMixer = uiState.hslMixer,
                maxContentHeight = maxContentHeight,
                onUpdateRange = onUpdateHslRange,
                onResetRange = onResetHslRange,
                onResetAll = onResetAllHsl,
              )
            EditorCategory.CURVE ->
              ToneCurvePanel(
                hasPhoto = uiState.importedPhoto != null,
                toneCurve = uiState.toneCurve,
                maxContentHeight = maxContentHeight,
                onAddPoint = onAddToneCurvePoint,
                onUpdatePoint = onUpdateToneCurvePoint,
                onRemovePoint = onRemoveToneCurvePoint,
                onResetChannel = onResetToneCurveChannel,
                onResetAll = onResetAllToneCurves,
              )
            EditorCategory.GRADING ->
              ColorGradingPanel(
                hasPhoto = uiState.importedPhoto != null,
                colorGrading = uiState.colorGrading,
                maxContentHeight = maxContentHeight,
                onUpdateRange = onUpdateColorGrading,
                onResetRange = onResetColorGradingRange,
                onResetAll = onResetAllColorGrading,
              )
            EditorCategory.TEXT ->
              TextToolPanel(
                selectedLayer = uiState.selectedLayer,
                maxContentHeight = maxContentHeight,
                onAddTextLayer = onAddTextLayer,
                onUpdateSelectedText = onUpdateSelectedText,
                onSelectFont = onSelectFont,
                onUpdateFontSize = onUpdateFontSize,
                onUpdateRotation = onUpdateRotation,
                onUpdateOpacity = onUpdateOpacity,
                onUpdateColor = onUpdateColor,
                onToggleBold = onToggleBold,
                onToggleItalic = onToggleItalic,
                onDuplicateLayer = onDuplicateLayer,
                onToggleLock = onToggleLock,
                onDeleteLayer = onDeleteLayer,
              )
            EditorCategory.LAYERS ->
              LayersToolPanel(
                layers = uiState.textLayers,
                selectedLayerId = uiState.selectedLayerId,
                maxContentHeight = maxContentHeight,
                onSelectLayer = onSelectLayer,
                onToggleVisibility = onToggleVisibility,
                onToggleLock = onToggleLock,
                onMoveLayerOrder = onMoveLayerOrder,
                onDuplicateLayer = onDuplicateLayer,
                onDeleteLayer = onDeleteLayer,
              )
          }
        }
      }
    }
  }
}

@Composable
private fun PhotoToolPanel(
  uiState: EditorUiState,
  maxContentHeight: androidx.compose.ui.unit.Dp,
  onImportPhoto: () -> Unit,
  onClearPhoto: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(14.dp)
        .testTag("photo_panel"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Button(
        onClick = onImportPhoto,
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.weight(1f).height(48.dp).testTag("panel_import_photo_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.AddPhotoAlternate,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (uiState.importedPhoto == null) "Import from Gallery" else "Replace Photo",
          style = MaterialTheme.typography.titleSmall,
        )
      }

      if (uiState.importedPhoto != null) {
        OutlinedButton(
          onClick = onClearPhoto,
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, StudioOutline),
          modifier = Modifier.height(48.dp).testTag("clear_photo_button"),
        ) {
          Icon(
            imageVector = Icons.Outlined.HideImage,
            contentDescription = stringResource(R.string.cd_clear_photo),
            tint = StudioTextSecondary,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("Clear", color = StudioTextSecondary)
        }
      }
    }

    val photo = uiState.importedPhoto
    if (photo != null) {
      Surface(
        color = StudioSurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, StudioOutline),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f),
          ) {
            Icon(
              imageVector = Icons.Outlined.PhotoLibrary,
              contentDescription = null,
              tint = StudioCyan,
            )
            Column {
              Text(
                text = photo.displayName,
                style = MaterialTheme.typography.titleSmall,
                color = StudioTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${photo.originalWidth} × ${photo.originalHeight} px • Original Quality",
                style = MaterialTheme.typography.labelSmall,
                color = StudioTextSecondary,
              )
            }
          }
        }
      }
    } else {
      Text(
        text = "Supports high-resolution JPEG, PNG, and WebP photos via Android Photo Picker.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
      )
    }
  }
}

@Composable
private fun TextToolPanel(
  selectedLayer: TextLayer?,
  maxContentHeight: androidx.compose.ui.unit.Dp,
  onAddTextLayer: (String, EditorFont) -> Unit,
  onUpdateSelectedText: (String) -> Unit,
  onSelectFont: (String, EditorFont) -> Unit,
  onUpdateFontSize: (String, Float) -> Unit,
  onUpdateRotation: (String, Float) -> Unit,
  onUpdateOpacity: (String, Float) -> Unit,
  onUpdateColor: (String, Long) -> Unit,
  onToggleBold: (String) -> Unit,
  onToggleItalic: (String) -> Unit,
  onDuplicateLayer: (String) -> Unit,
  onToggleLock: (String) -> Unit,
  onDeleteLayer: (String) -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .heightIn(max = maxContentHeight)
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 10.dp)
        .testTag("text_panel"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    // Quick Add Burmese & English layers
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Button(
        onClick = { onAddTextLayer("GT Photo Edit", EditorFont.SPACE_GROTESK) },
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioSurfaceBright,
            contentColor = StudioTextPrimary,
          ),
        modifier = Modifier.weight(1f).height(48.dp).testTag("add_english_text_button"),
      ) {
        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("English Text", style = MaterialTheme.typography.labelMedium)
      }

      Button(
        onClick = { onAddTextLayer("မင်္ဂလာပါ", EditorFont.NOTO_SANS_MYANMAR) },
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = StudioCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
        modifier = Modifier.weight(1f).height(48.dp).testTag("add_burmese_text_button"),
      ) {
        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("မြန်မာစာ", style = MaterialTheme.typography.labelMedium)
      }
    }

    if (selectedLayer == null) {
      Surface(
        color = StudioSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, StudioOutline),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Text(
          text =
            "Tap a button above to add a Burmese or English text layer, or tap any layer on the photo preview to edit and drag it.",
          style = MaterialTheme.typography.bodyMedium,
          color = StudioTextSecondary,
          modifier = Modifier.padding(14.dp),
        )
      }
      return@Column
    }

    // Active layer text input (Burmese & English Unicode)
    OutlinedTextField(
      value = selectedLayer.text,
      onValueChange = onUpdateSelectedText,
      label = { Text("Layer Text (Burmese / English)") },
      textStyle =
        TextStyle(
          fontFamily = selectedLayer.font.fontFamily,
          fontSize = 16.sp,
          fontWeight = if (selectedLayer.isBold) FontWeight.Bold else FontWeight.Normal,
          fontStyle = if (selectedLayer.isItalic) FontStyle.Italic else FontStyle.Normal,
          color = StudioTextPrimary,
        ),
      maxLines = 3,
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = StudioCyan,
          unfocusedBorderColor = StudioOutline,
          focusedContainerColor = StudioSurfaceElevated,
          unfocusedContainerColor = StudioSurfaceElevated,
          focusedTextColor = StudioTextPrimary,
          unfocusedTextColor = StudioTextPrimary,
        ),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.fillMaxWidth().testTag("selected_text_input"),
    )

    // Layer Quick Controls: Bold, Italic, Duplicate, Lock, Delete (wraps cleanly on narrow phones)
    @OptIn(ExperimentalLayoutApi::class)
    FlowRow(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      FilterChip(
        selected = selectedLayer.isBold,
        onClick = { onToggleBold(selectedLayer.id) },
        label = { Text("Bold") },
        leadingIcon = {
          Icon(Icons.Outlined.FormatBold, contentDescription = null, modifier = Modifier.size(16.dp))
        },
        colors = studioChipColors(),
        modifier = Modifier.testTag("toggle_bold_button"),
      )
      FilterChip(
        selected = selectedLayer.isItalic,
        onClick = { onToggleItalic(selectedLayer.id) },
        label = { Text("Italic") },
        leadingIcon = {
          Icon(
            Icons.Outlined.FormatItalic,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
        },
        colors = studioChipColors(),
        modifier = Modifier.testTag("toggle_italic_button"),
      )
      IconButton(
        onClick = { onDuplicateLayer(selectedLayer.id) },
        modifier = Modifier.size(48.dp).testTag("duplicate_layer_button"),
      ) {
        Icon(
          Icons.Outlined.ContentCopy,
          contentDescription = stringResource(R.string.cd_duplicate_layer),
          tint = StudioTextPrimary,
          modifier = Modifier.size(19.dp),
        )
      }
      IconButton(
        onClick = { onToggleLock(selectedLayer.id) },
        modifier = Modifier.size(48.dp).testTag("lock_layer_button"),
      ) {
        Icon(
          imageVector = if (selectedLayer.isLocked) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
          contentDescription = stringResource(R.string.cd_toggle_lock),
          tint = if (selectedLayer.isLocked) StudioAmber else StudioTextSecondary,
          modifier = Modifier.size(19.dp),
        )
      }
      IconButton(
        onClick = { onDeleteLayer(selectedLayer.id) },
        modifier = Modifier.size(48.dp).testTag("panel_delete_layer_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.DeleteOutline,
          contentDescription = stringResource(R.string.cd_delete_layer),
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    // Font selector
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      contentPadding = PaddingValues(end = 8.dp),
    ) {
      items(EditorFont.entries) { font ->
        FilterChip(
          selected = selectedLayer.font == font,
          onClick = { onSelectFont(selectedLayer.id, font) },
          label = {
            Text(
              text = font.displayName,
              fontFamily = font.fontFamily,
              fontSize = 12.sp,
            )
          },
          colors = studioChipColors(),
          modifier = Modifier.testTag("font_chip_${font.name}"),
        )
      }
    }

    // Color swatches
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      items(TextLayerPalette) { argb ->
        val selected = selectedLayer.colorArgb == argb
        Box(
          modifier =
            Modifier.size(48.dp)
              .clip(CircleShape)
              .clickable { onUpdateColor(selectedLayer.id, argb) }
              .padding(7.dp)
              .clip(CircleShape)
              .background(Color(argb))
              .border(
                width = if (selected) 2.5.dp else 1.dp,
                color = if (selected) StudioCyan else StudioOutline,
                shape = CircleShape,
              )
        )
      }
    }

    // Size, Opacity, Rotation Sliders
    LabeledStudioSlider(
      label = "Size",
      valueText = "${selectedLayer.fontSizeSp.roundToInt()} sp",
      value = selectedLayer.fontSizeSp,
      valueRange = 14f..72f,
      onValueChange = { onUpdateFontSize(selectedLayer.id, it) },
    )
    LabeledStudioSlider(
      label = "Opacity",
      valueText = "${(selectedLayer.opacity * 100).roundToInt()}%",
      value = selectedLayer.opacity,
      valueRange = 0.1f..1f,
      onValueChange = { onUpdateOpacity(selectedLayer.id, it) },
    )
    LabeledStudioSlider(
      label = "Rotate",
      valueText = "${selectedLayer.rotationDegrees.roundToInt()}°",
      value = selectedLayer.rotationDegrees,
      valueRange = -180f..180f,
      onValueChange = { onUpdateRotation(selectedLayer.id, it) },
    )
  }
}

@Composable
private fun LayersToolPanel(
  layers: List<TextLayer>,
  selectedLayerId: String?,
  maxContentHeight: androidx.compose.ui.unit.Dp,
  onSelectLayer: (String) -> Unit,
  onToggleVisibility: (String) -> Unit,
  onToggleLock: (String) -> Unit,
  onMoveLayerOrder: (String, Boolean) -> Unit,
  onDuplicateLayer: (String) -> Unit,
  onDeleteLayer: (String) -> Unit,
) {
  if (layers.isEmpty()) {
    Box(
      modifier = Modifier.fillMaxWidth().padding(20.dp).testTag("layers_empty_state"),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = "No text layers yet. Switch to Text to add Burmese or English text.",
        style = MaterialTheme.typography.bodyMedium,
        color = StudioTextSecondary,
      )
    }
    return
  }

  val reversedLayers = layers.reversed()
  LazyColumn(
    modifier = Modifier.fillMaxWidth().heightIn(max = maxContentHeight).testTag("layers_panel"),
    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    itemsIndexed(reversedLayers, key = { _, item -> item.id }) { idx, layer ->
      val isSelected = layer.id == selectedLayerId
      Surface(
        color = if (isSelected) StudioSurfaceBright else StudioSurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, if (isSelected) StudioCyan else StudioOutline),
        modifier =
          Modifier.fillMaxWidth()
            .clickable { onSelectLayer(layer.id) }
            .testTag("layer_row_${layer.id}"),
      ) {
        Column(
          modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 4.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f).padding(end = 4.dp)) {
              Text(
                text = layer.text.ifBlank { "(Empty)" },
                style = MaterialTheme.typography.titleSmall.copy(fontFamily = layer.font.fontFamily),
                color = if (layer.isVisible) StudioTextPrimary else StudioTextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text = "${layer.font.displayName} • ${layer.fontSizeSp.roundToInt()}sp",
                style = MaterialTheme.typography.labelSmall,
                color = StudioTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }

            IconButton(
              onClick = { onToggleVisibility(layer.id) },
              modifier = Modifier.size(48.dp).testTag("layer_visibility_${layer.id}"),
            ) {
              Icon(
                imageVector =
                  if (layer.isVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                contentDescription = stringResource(R.string.cd_toggle_visibility),
                tint = if (layer.isVisible) StudioCyan else StudioTextMuted,
                modifier = Modifier.size(18.dp),
              )
            }
            IconButton(
              onClick = { onToggleLock(layer.id) },
              modifier = Modifier.size(48.dp).testTag("layer_lock_${layer.id}"),
            ) {
              Icon(
                imageVector = if (layer.isLocked) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
                contentDescription = stringResource(R.string.cd_toggle_lock),
                tint = if (layer.isLocked) StudioAmber else StudioTextSecondary,
                modifier = Modifier.size(18.dp),
              )
            }
            IconButton(
              onClick = { onDeleteLayer(layer.id) },
              modifier = Modifier.size(48.dp).testTag("layer_delete_${layer.id}"),
            ) {
              Icon(
                Icons.Outlined.DeleteOutline,
                contentDescription = stringResource(R.string.cd_delete_layer),
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(19.dp),
              )
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = "Order & Copy",
              style = MaterialTheme.typography.labelSmall,
              color = StudioTextMuted,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = { onMoveLayerOrder(layer.id, true) },
                enabled = idx > 0,
                modifier = Modifier.size(48.dp),
              ) {
                Icon(
                  Icons.Outlined.ArrowUpward,
                  contentDescription = stringResource(R.string.cd_move_layer_up),
                  tint = if (idx > 0) StudioTextSecondary else StudioTextMuted.copy(alpha = 0.35f),
                  modifier = Modifier.size(18.dp),
                )
              }
              IconButton(
                onClick = { onMoveLayerOrder(layer.id, false) },
                enabled = idx < reversedLayers.lastIndex,
                modifier = Modifier.size(48.dp),
              ) {
                Icon(
                  Icons.Outlined.ArrowDownward,
                  contentDescription = stringResource(R.string.cd_move_layer_down),
                  tint =
                    if (idx < reversedLayers.lastIndex) StudioTextSecondary
                    else StudioTextMuted.copy(alpha = 0.35f),
                  modifier = Modifier.size(18.dp),
                )
              }
              IconButton(
                onClick = { onDuplicateLayer(layer.id) },
                modifier = Modifier.size(48.dp),
              ) {
                Icon(
                  Icons.Outlined.ContentCopy,
                  contentDescription = stringResource(R.string.cd_duplicate_layer),
                  tint = StudioTextSecondary,
                  modifier = Modifier.size(17.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LabeledStudioSlider(
  label: String,
  valueText: String,
  value: Float,
  valueRange: ClosedFloatingPointRange<Float>,
  onValueChange: (Float) -> Unit,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = StudioTextSecondary,
      modifier = Modifier.width(56.dp),
    )
    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      colors =
        SliderDefaults.colors(
          thumbColor = StudioCyan,
          activeTrackColor = StudioCyan,
          inactiveTrackColor = StudioOutline,
        ),
      modifier = Modifier.weight(1f),
    )
    Text(
      text = valueText,
      style = MaterialTheme.typography.labelSmall,
      color = StudioTextPrimary,
      modifier = Modifier.width(52.dp),
    )
  }
}

@Composable
private fun studioChipColors() =
  FilterChipDefaults.filterChipColors(
    containerColor = StudioSurfaceElevated,
    labelColor = StudioTextSecondary,
    iconColor = StudioTextSecondary,
    selectedContainerColor = StudioCyan.copy(alpha = 0.2f),
    selectedLabelColor = StudioCyan,
    selectedLeadingIconColor = StudioCyan,
  )
