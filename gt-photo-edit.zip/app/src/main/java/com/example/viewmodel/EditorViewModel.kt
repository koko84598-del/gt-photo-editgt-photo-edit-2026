package com.example.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.GalleryExporter
import com.example.data.ImageProcessor
import com.example.data.PhotoDecoder
import com.example.data.ProjectRepository
import com.example.data.TextLayerCompositor
import com.example.model.AdjustmentType
import com.example.model.ColorAdjustments
import com.example.model.ColorGradeWheel
import com.example.model.ColorGradingParams
import com.example.model.CropAspectRatio
import com.example.model.CropRect
import com.example.model.CropTransformParams
import com.example.model.CurvePoint
import com.example.model.EditorCategory
import com.example.model.EditorFont
import com.example.model.EditorSnapshot
import com.example.model.EditorUiState
import com.example.model.ExportFormat
import com.example.model.GradingRange
import com.example.model.HslAdjustment
import com.example.model.HslColorRange
import com.example.model.HslMixerParams
import com.example.model.SavedProject
import com.example.model.TextLayer
import com.example.model.ToneCurveChannel
import com.example.model.ToneCurveParams
import java.util.UUID
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditorViewModel(
  private val photoDecoder: PhotoDecoder,
  private val processingDispatcher: CoroutineDispatcher = Dispatchers.Default,
  private val projectRepository: ProjectRepository? = null,
  private val galleryExporter: GalleryExporter? = null,
  private val appContext: Context? = null,
) : ViewModel() {

  private val _uiState = MutableStateFlow(EditorUiState())
  val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

  private val workingSourceBitmap = MutableStateFlow<Bitmap?>(null)
  private val history = EditorHistoryManager()

  init {
    refreshSavedProjects()
    viewModelScope.launch {
      combine(
          workingSourceBitmap,
          _uiState.map { it.cropTransform }.distinctUntilChanged(),
          _uiState
            .map {
              ColorPipelineParams(it.colorAdjustments, it.hslMixer, it.toneCurve, it.colorGrading)
            }
            .distinctUntilChanged(),
          _uiState.map { it.activeCategory == EditorCategory.CROP }.distinctUntilChanged(),
        ) { workingBmp, transform, colorParams, isCropping ->
          RenderRequest(
            source = workingBmp,
            transform = transform,
            adjustments = colorParams.adjustments,
            hslMixer = colorParams.hslMixer,
            toneCurve = colorParams.toneCurve,
            colorGrading = colorParams.colorGrading,
            applyCrop = !isCropping,
          )
        }
        .collectLatest { req ->
          val source = req.source
          if (source == null) {
            _uiState.update { it.copy(previewBitmap = null, isProcessingImage = false) }
            return@collectLatest
          }
          if (
            req.transform.isIdentity &&
              req.adjustments.isIdentity &&
              req.hslMixer.isIdentity &&
              req.toneCurve.isIdentity &&
              req.colorGrading.isIdentity
          ) {
            _uiState.update { it.copy(previewBitmap = source, isProcessingImage = false) }
            return@collectLatest
          }
          _uiState.update { it.copy(isProcessingImage = true) }
          val rendered =
            withContext(processingDispatcher) {
              ImageProcessor.processBitmap(
                source = source,
                transform = req.transform,
                adjustments = req.adjustments,
                applyCrop = req.applyCrop,
                hslMixer = req.hslMixer,
                toneCurve = req.toneCurve,
                colorGrading = req.colorGrading,
              )
            }
          _uiState.update { it.copy(previewBitmap = rendered, isProcessingImage = false) }
        }
    }
  }

  private data class ColorPipelineParams(
    val adjustments: ColorAdjustments,
    val hslMixer: HslMixerParams,
    val toneCurve: ToneCurveParams,
    val colorGrading: ColorGradingParams,
  )

  private data class RenderRequest(
    val source: Bitmap?,
    val transform: CropTransformParams,
    val adjustments: ColorAdjustments,
    val hslMixer: HslMixerParams,
    val toneCurve: ToneCurveParams,
    val colorGrading: ColorGradingParams,
    val applyCrop: Boolean,
  )

  // --- Photo Import & Relink ---

  fun importPhoto(uri: Uri) = decodeAndAttachPhoto(uri, preserveExistingEdits = false)

  fun relinkPhoto(uri: Uri) = decodeAndAttachPhoto(uri, preserveExistingEdits = true)

  private fun decodeAndAttachPhoto(uri: Uri, preserveExistingEdits: Boolean) {
    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingPhoto = true, photoError = null) }
      photoDecoder
        .decode(uri)
        .onSuccess { photo ->
          val working =
            withContext(processingDispatcher) {
              ImageProcessor.createWorkingPreview(photo.bitmap, maxEdge = 900)
            }
          workingSourceBitmap.value = working
          if (!preserveExistingEdits) {
            history.clear()
          }
          _uiState.update { state ->
            if (preserveExistingEdits) {
              state.copy(
                importedPhoto = photo,
                isLoadingPhoto = false,
                missingSourceMessage = null,
                photoError = null,
                statusMessage = "Photo relinked: ${photo.displayName}",
              )
            } else {
              state.copy(
                importedPhoto = photo,
                previewBitmap = working,
                cropTransform = CropTransformParams(),
                colorAdjustments = ColorAdjustments(),
                hslMixer = HslMixerParams(),
                toneCurve = ToneCurveParams(),
                colorGrading = ColorGradingParams(),
                currentProjectId = null,
                currentProjectName = null,
                missingSourceMessage = null,
                isLoadingPhoto = false,
                photoError = null,
                canUndo = false,
                canRedo = false,
              )
            }
          }
        }
        .onFailure { error ->
          _uiState.update {
            it.copy(
              isLoadingPhoto = false,
              photoError = error.localizedMessage ?: "Failed to load the selected photo.",
            )
          }
        }
    }
  }

  fun clearPhoto() {
    workingSourceBitmap.value = null
    history.clear()
    _uiState.update {
      it.copy(
        importedPhoto = null,
        previewBitmap = null,
        cropTransform = CropTransformParams(),
        colorAdjustments = ColorAdjustments(),
        hslMixer = HslMixerParams(),
        toneCurve = ToneCurveParams(),
        colorGrading = ColorGradingParams(),
        currentProjectId = null,
        currentProjectName = null,
        missingSourceMessage = null,
        photoError = null,
        canUndo = false,
        canRedo = false,
      )
    }
  }

  fun dismissPhotoError() {
    _uiState.update { it.copy(photoError = null) }
  }

  fun dismissStatusMessage() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  fun reportExportError(message: String) {
    _uiState.update { it.copy(isExporting = false, photoError = message) }
  }

  fun selectCategory(category: EditorCategory) {
    _uiState.update { state ->
      if (state.activeCategory == category && !state.isPanelExpanded) {
        state.copy(isPanelExpanded = true)
      } else {
        state.copy(activeCategory = category, isPanelExpanded = true)
      }
    }
  }

  fun togglePanelExpanded() {
    _uiState.update { it.copy(isPanelExpanded = !it.isPanelExpanded) }
  }

  // --- Milestone 4: Undo / Redo ---

  fun undo() {
    _uiState.update { state ->
      val previous = history.undo(state.toSnapshot()) ?: return@update state
      state.applyingSnapshot(previous, history.canUndo, history.canRedo)
    }
  }

  fun redo() {
    _uiState.update { state ->
      val next = history.redo(state.toSnapshot()) ?: return@update state
      state.applyingSnapshot(next, history.canUndo, history.canRedo)
    }
  }

  private fun mutateWithHistory(
    coalesceKey: String? = null,
    transform: (EditorUiState) -> EditorUiState,
  ) {
    _uiState.update { state ->
      val before = state.toSnapshot()
      val next = transform(state)
      val after = next.toSnapshot()
      if (before == after) return@update next
      history.recordTransition(before, after, coalesceKey)
      next.copy(canUndo = history.canUndo, canRedo = history.canRedo)
    }
  }

  private fun EditorUiState.applyingSnapshot(
    snapshot: EditorSnapshot,
    canUndo: Boolean,
    canRedo: Boolean,
  ): EditorUiState =
    copy(
      cropTransform = snapshot.cropTransform,
      colorAdjustments = snapshot.colorAdjustments,
      hslMixer = snapshot.hslMixer,
      toneCurve = snapshot.toneCurve,
      colorGrading = snapshot.colorGrading,
      textLayers = snapshot.textLayers,
      selectedLayerId = snapshot.selectedLayerId,
      canUndo = canUndo,
      canRedo = canRedo,
    )

  // --- Milestone 4: Project Save / Open / Delete ---

  fun refreshSavedProjects() {
    val repo = projectRepository ?: return
    viewModelScope.launch {
      repo.listProjects().onSuccess { list ->
        _uiState.update { it.copy(savedProjects = list) }
      }
    }
  }

  fun saveProject(customName: String? = null) {
    val repo = projectRepository ?: run {
      _uiState.update { it.copy(photoError = "Project storage is unavailable.") }
      return
    }
    val state = _uiState.value
    if (state.importedPhoto == null && state.textLayers.isEmpty() && state.currentProjectId == null) {
      _uiState.update { it.copy(photoError = "Import a photo or add a layer before saving.") }
      return
    }
    val projectId = state.currentProjectId ?: UUID.randomUUID().toString()
    val defaultName =
      state.currentProjectName
        ?: state.importedPhoto?.displayName?.substringBeforeLast('.')?.takeIf { it.isNotBlank() }
        ?: "GT Studio Project"
    val finalName = customName?.trim()?.takeIf { it.isNotBlank() } ?: defaultName

    val project =
      SavedProject(
        id = projectId,
        name = finalName,
        sourceUriString = state.importedPhoto?.uriString.orEmpty(),
        sourceDisplayName = state.importedPhoto?.displayName ?: "No Image",
        originalWidth = state.importedPhoto?.originalWidth ?: 0,
        originalHeight = state.importedPhoto?.originalHeight ?: 0,
        updatedAtMillis = System.currentTimeMillis(),
        activeCategory = state.activeCategory,
        snapshot = state.toSnapshot(),
      )

    viewModelScope.launch {
      repo.saveProject(project)
        .onSuccess {
          val updatedList = repo.listProjects().getOrDefault(_uiState.value.savedProjects)
          _uiState.update {
            it.copy(
              currentProjectId = project.id,
              currentProjectName = project.name,
              savedProjects = updatedList,
              statusMessage = "Project saved: ${project.name}",
            )
          }
        }
        .onFailure { err ->
          _uiState.update {
            it.copy(photoError = err.localizedMessage ?: "Failed to save project.")
          }
        }
    }
  }

  fun openProject(projectId: String) {
    val repo = projectRepository ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isLoadingPhoto = true, photoError = null) }
      val project =
        repo.loadProject(projectId).getOrElse { err ->
          _uiState.update {
            it.copy(
              isLoadingPhoto = false,
              photoError = err.localizedMessage ?: "Unable to open saved project.",
            )
          }
          return@launch
        }

      history.clear()

      val uriStr = project.sourceUriString
      val decodedPhoto =
        if (uriStr.isNotBlank()) photoDecoder.decode(Uri.parse(uriStr)).getOrNull()
        else null

      if (decodedPhoto != null) {
        val working =
          withContext(processingDispatcher) {
            ImageProcessor.createWorkingPreview(decodedPhoto.bitmap, maxEdge = 900)
          }
        workingSourceBitmap.value = working
        _uiState.update { state ->
          state
            .applyingSnapshot(project.snapshot, canUndo = false, canRedo = false)
            .copy(
              importedPhoto = decodedPhoto,
              previewBitmap = working,
              activeCategory = project.activeCategory,
              currentProjectId = project.id,
              currentProjectName = project.name,
              missingSourceMessage = null,
              isLoadingPhoto = false,
              statusMessage = "Opened project: ${project.name}",
            )
        }
      } else {
        workingSourceBitmap.value = null
        val missingNotice =
          if (project.sourceDisplayName.isNotBlank() && project.sourceDisplayName != "No Image") {
            "Original image \"${project.sourceDisplayName}\" is missing or inaccessible. Relink a photo to continue editing with your saved settings."
          } else {
            "Original image is missing or inaccessible. Relink a photo to continue editing."
          }
        _uiState.update { state ->
          state
            .applyingSnapshot(project.snapshot, canUndo = false, canRedo = false)
            .copy(
              importedPhoto = null,
              previewBitmap = null,
              activeCategory = project.activeCategory,
              currentProjectId = project.id,
              currentProjectName = project.name,
              missingSourceMessage = missingNotice,
              isLoadingPhoto = false,
              photoError = missingNotice,
            )
        }
      }
    }
  }

  fun deleteSavedProject(projectId: String) {
    val repo = projectRepository ?: return
    viewModelScope.launch {
      repo.deleteProject(projectId).onSuccess {
        val updatedList = repo.listProjects().getOrDefault(emptyList())
        _uiState.update { state ->
          val clearedCurrent = state.currentProjectId == projectId
          state.copy(
            savedProjects = updatedList,
            currentProjectId = if (clearedCurrent) null else state.currentProjectId,
            currentProjectName = if (clearedCurrent) null else state.currentProjectName,
          )
        }
      }
    }
  }

  // --- Milestone 4: Full-Resolution Gallery Export ---

  fun exportToGallery(format: ExportFormat, jpegQuality: Int = 95) {
    val exporter = galleryExporter ?: run {
      _uiState.update { it.copy(photoError = "Gallery exporter is unavailable.") }
      return
    }
    val state = _uiState.value
    val photo = state.importedPhoto ?: run {
      _uiState.update { it.copy(photoError = "Import a photo before exporting.") }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isExporting = true, photoError = null) }
      val renderedResult =
        withContext(processingDispatcher) {
          runCatching {
            val fullResSource = resolveFullResolutionSource(photo)
            val processed =
              ImageProcessor.processBitmap(
                source = fullResSource,
                transform = state.cropTransform,
                adjustments = state.colorAdjustments,
                applyCrop = true,
                hslMixer = state.hslMixer,
                toneCurve = state.toneCurve,
                colorGrading = state.colorGrading,
              )
            TextLayerCompositor.compositeVisibleTextLayers(
              baseBitmap = processed,
              textLayers = state.textLayers,
              context = appContext,
              preserveAlpha = format == ExportFormat.PNG,
            )
          }
        }

      val finalBitmap =
        renderedResult.getOrElse { err ->
          _uiState.update {
            it.copy(
              isExporting = false,
              photoError = err.localizedMessage ?: "Failed to render full-resolution export.",
            )
          }
          return@launch
        }

      exporter
        .exportToGallery(
          bitmap = finalBitmap,
          sourceDisplayName = photo.displayName,
          format = format,
          jpegQuality = jpegQuality,
        )
        .onSuccess { res ->
          _uiState.update {
            it.copy(
              isExporting = false,
              statusMessage =
                "Exported ${res.format.label} (${res.width} × ${res.height}) to Gallery",
            )
          }
        }
        .onFailure { err ->
          _uiState.update {
            it.copy(
              isExporting = false,
              photoError = err.localizedMessage ?: "Failed to save exported image to Gallery.",
            )
          }
        }
    }
  }

  private suspend fun resolveFullResolutionSource(photo: com.example.model.ImportedPhoto): Bitmap {
    if (
      photo.uriString.isNotBlank() &&
        (photo.bitmap.width < photo.originalWidth || photo.bitmap.height < photo.originalHeight)
    ) {
      val fullDecoded =
        try {
          photoDecoder.decodeFullResolution(Uri.parse(photo.uriString)).getOrNull()?.bitmap
        } catch (_: OutOfMemoryError) {
          null
        }
      if (fullDecoded != null) return fullDecoded
    }
    return photo.bitmap
  }

  fun renderFullResolutionEditedBitmap(): Bitmap? {
    val state = _uiState.value
    val source = state.importedPhoto?.bitmap ?: return null
    val processed =
      ImageProcessor.processBitmap(
        source = source,
        transform = state.cropTransform,
        adjustments = state.colorAdjustments,
        applyCrop = true,
        hslMixer = state.hslMixer,
        toneCurve = state.toneCurve,
        colorGrading = state.colorGrading,
      )
    return TextLayerCompositor.compositeVisibleTextLayers(
      baseBitmap = processed,
      textLayers = state.textLayers,
      context = appContext,
      preserveAlpha = true,
    )
  }

  // --- Crop & Transform (Milestone 2) ---

  fun setCropAspectRatio(aspectRatio: CropAspectRatio) {
    mutateWithHistory { state ->
      val photo = state.importedPhoto
      val (ow, oh) =
        if (photo != null) {
          ImageProcessor.orientedDimensions(
            photo.bitmap.width,
            photo.bitmap.height,
            state.cropTransform.rotation90Degrees,
          )
        } else {
          1000 to 1000
        }
      val newRect =
        ImageProcessor.computeCropRectForAspectRatio(
          orientedWidth = ow,
          orientedHeight = oh,
          aspectRatio = aspectRatio,
          currentRect = state.cropTransform.cropRect,
        )
      state.copy(
        cropTransform = state.cropTransform.copy(aspectRatio = aspectRatio, cropRect = newRect)
      )
    }
  }

  fun updateCropRect(cropRect: CropRect) {
    val clampedLeft = cropRect.left.coerceIn(0f, 1f - CropRect.MIN_SIZE)
    val clampedTop = cropRect.top.coerceIn(0f, 1f - CropRect.MIN_SIZE)
    val clampedRight = cropRect.right.coerceIn(clampedLeft + CropRect.MIN_SIZE, 1f)
    val clampedBottom = cropRect.bottom.coerceIn(clampedTop + CropRect.MIN_SIZE, 1f)
    mutateWithHistory(coalesceKey = "crop_rect") { state ->
      state.copy(
        cropTransform =
          state.cropTransform.copy(
            cropRect = CropRect(clampedLeft, clampedTop, clampedRight, clampedBottom)
          )
      )
    }
  }

  fun rotateBy90() {
    val nextRot = (_uiState.value.cropTransform.rotation90Degrees + 90) % 360
    setRotation90(nextRot)
  }

  fun setRotation90(degrees: Int) {
    val normalized = ((degrees % 360) + 360) % 360
    val discrete =
      when {
        normalized < 45 -> 0
        normalized < 135 -> 90
        normalized < 225 -> 180
        normalized < 315 -> 270
        else -> 0
      }
    mutateWithHistory { state ->
      val photo = state.importedPhoto
      val updatedRect =
        if (photo != null && state.cropTransform.aspectRatio != CropAspectRatio.FREE) {
          val (ow, oh) =
            ImageProcessor.orientedDimensions(photo.bitmap.width, photo.bitmap.height, discrete)
          ImageProcessor.computeCropRectForAspectRatio(
            ow,
            oh,
            state.cropTransform.aspectRatio,
            state.cropTransform.cropRect,
          )
        } else {
          state.cropTransform.cropRect
        }
      state.copy(
        cropTransform =
          state.cropTransform.copy(rotation90Degrees = discrete, cropRect = updatedRect)
      )
    }
  }

  fun toggleFlipHorizontal() {
    mutateWithHistory { state ->
      state.copy(
        cropTransform =
          state.cropTransform.copy(flipHorizontal = !state.cropTransform.flipHorizontal)
      )
    }
  }

  fun toggleFlipVertical() {
    mutateWithHistory { state ->
      state.copy(
        cropTransform =
          state.cropTransform.copy(flipVertical = !state.cropTransform.flipVertical)
      )
    }
  }

  fun updateStraightenDegrees(degrees: Float) {
    mutateWithHistory(coalesceKey = "straighten") { state ->
      state.copy(
        cropTransform = state.cropTransform.copy(straightenDegrees = degrees.coerceIn(-45f, 45f))
      )
    }
  }

  fun updatePerspectiveVertical(value: Float) {
    mutateWithHistory(coalesceKey = "perspective_v") { state ->
      state.copy(
        cropTransform = state.cropTransform.copy(perspectiveVertical = value.coerceIn(-1f, 1f))
      )
    }
  }

  fun updatePerspectiveHorizontal(value: Float) {
    mutateWithHistory(coalesceKey = "perspective_h") { state ->
      state.copy(
        cropTransform = state.cropTransform.copy(perspectiveHorizontal = value.coerceIn(-1f, 1f))
      )
    }
  }

  fun resetCropTransform() {
    mutateWithHistory { it.copy(cropTransform = CropTransformParams()) }
  }

  // --- Color Adjustments (Milestone 2) ---

  fun updateColorAdjustment(type: AdjustmentType, value: Float) {
    mutateWithHistory(coalesceKey = "adj:${type.name}") { state ->
      state.copy(colorAdjustments = state.colorAdjustments.withValue(type, value))
    }
  }

  fun resetColorAdjustment(type: AdjustmentType) {
    mutateWithHistory { state ->
      state.copy(colorAdjustments = state.colorAdjustments.withValue(type, type.defaultValue))
    }
  }

  fun resetAllColorAdjustments() {
    mutateWithHistory { it.copy(colorAdjustments = ColorAdjustments()) }
  }

  // --- Milestone 3: HSL Color Mixer ---

  fun updateHslRange(range: HslColorRange, adjustment: HslAdjustment) {
    mutateWithHistory(coalesceKey = "hsl:${range.name}") { state ->
      state.copy(hslMixer = state.hslMixer.withRange(range, adjustment))
    }
  }

  fun resetHslRange(range: HslColorRange) {
    mutateWithHistory { state -> state.copy(hslMixer = state.hslMixer.resetRange(range)) }
  }

  fun resetAllHsl() {
    mutateWithHistory { it.copy(hslMixer = HslMixerParams()) }
  }

  // --- Milestone 3: RGB Tone Curve ---

  fun addToneCurvePoint(channel: ToneCurveChannel, point: CurvePoint) {
    mutateWithHistory { state ->
      val current = state.toneCurve.pointsFor(channel)
      val clamped = CurvePoint(point.x.coerceIn(0.03f, 0.97f), point.y.coerceIn(0f, 1f))
      state.copy(toneCurve = state.toneCurve.withPoints(channel, current + clamped))
    }
  }

  fun updateToneCurvePoint(channel: ToneCurveChannel, index: Int, point: CurvePoint) {
    mutateWithHistory(coalesceKey = "curve:${channel.name}:$index") { state ->
      val current = state.toneCurve.pointsFor(channel)
      if (index !in current.indices) return@mutateWithHistory state
      val mutable = current.toMutableList()
      val yClamped = point.y.coerceIn(0f, 1f)
      val updatedPoint =
        when (index) {
          0 -> CurvePoint(0f, yClamped)
          current.lastIndex -> CurvePoint(1f, yClamped)
          else -> {
            val minX = current[index - 1].x + 0.03f
            val maxX = current[index + 1].x - 0.03f
            val xClamped =
              if (minX <= maxX) point.x.coerceIn(minX, maxX)
              else (current[index - 1].x + current[index + 1].x) * 0.5f
            CurvePoint(xClamped, yClamped)
          }
        }
      mutable[index] = updatedPoint
      state.copy(toneCurve = state.toneCurve.withPoints(channel, mutable))
    }
  }

  fun removeToneCurvePoint(channel: ToneCurveChannel, index: Int) {
    mutateWithHistory { state ->
      val current = state.toneCurve.pointsFor(channel)
      if (index <= 0 || index >= current.lastIndex) return@mutateWithHistory state
      val mutable = current.toMutableList()
      mutable.removeAt(index)
      state.copy(toneCurve = state.toneCurve.withPoints(channel, mutable))
    }
  }

  fun resetToneCurveChannel(channel: ToneCurveChannel) {
    mutateWithHistory { state -> state.copy(toneCurve = state.toneCurve.resetChannel(channel)) }
  }

  fun resetAllToneCurves() {
    mutateWithHistory { it.copy(toneCurve = ToneCurveParams()) }
  }

  // --- Milestone 3: Color Grading ---

  fun updateColorGrading(range: GradingRange, wheel: ColorGradeWheel) {
    mutateWithHistory(coalesceKey = "grading:${range.name}") { state ->
      state.copy(colorGrading = state.colorGrading.withRange(range, wheel))
    }
  }

  fun resetColorGradingRange(range: GradingRange) {
    mutateWithHistory { state ->
      state.copy(colorGrading = state.colorGrading.resetRange(range))
    }
  }

  fun resetAllColorGrading() {
    mutateWithHistory { it.copy(colorGrading = ColorGradingParams()) }
  }

  // --- Text Layers (Milestone 1) ---

  fun addTextLayer(
    initialText: String = "GT Studio",
    font: EditorFont = EditorFont.NOTO_SANS_MYANMAR,
  ) {
    mutateWithHistory { state ->
      val staggerIndex = state.textLayers.size % 5
      val offsetY = (0.38f + staggerIndex * 0.06f).coerceIn(0.15f, 0.85f)
      val newLayer =
        TextLayer(
          id = UUID.randomUUID().toString(),
          text = initialText,
          xFraction = 0.5f,
          yFraction = offsetY,
          font = font,
        )
      state.copy(
        textLayers = state.textLayers + newLayer,
        selectedLayerId = newLayer.id,
        activeCategory = EditorCategory.TEXT,
        isPanelExpanded = true,
      )
    }
  }

  fun selectTextLayer(id: String?) {
    _uiState.update { it.copy(selectedLayerId = id) }
  }

  fun updateSelectedLayerText(text: String) {
    val selectedId = _uiState.value.selectedLayerId ?: return
    updateLayer(selectedId, coalesceKey = "layer_text:$selectedId") { it.copy(text = text) }
  }

  fun moveTextLayer(id: String, deltaXFraction: Float, deltaYFraction: Float) {
    updateLayer(id, coalesceKey = "layer_move:$id") { layer ->
      if (layer.isLocked) {
        layer
      } else {
        layer.copy(
          xFraction = (layer.xFraction + deltaXFraction).coerceIn(0.05f, 0.95f),
          yFraction = (layer.yFraction + deltaYFraction).coerceIn(0.05f, 0.95f),
        )
      }
    }
  }

  fun updateLayerFontSize(id: String, sizeSp: Float) {
    updateLayer(id, coalesceKey = "layer_size:$id") {
      it.copy(fontSizeSp = sizeSp.coerceIn(12f, 84f))
    }
  }

  fun updateLayerRotation(id: String, degrees: Float) {
    updateLayer(id, coalesceKey = "layer_rot:$id") {
      it.copy(rotationDegrees = degrees.coerceIn(-180f, 180f))
    }
  }

  fun updateLayerColor(id: String, colorArgb: Long) {
    updateLayer(id, coalesceKey = null) { it.copy(colorArgb = colorArgb) }
  }

  fun updateLayerOpacity(id: String, opacity: Float) {
    updateLayer(id, coalesceKey = "layer_opacity:$id") {
      it.copy(opacity = opacity.coerceIn(0.1f, 1f))
    }
  }

  fun updateLayerFont(id: String, font: EditorFont) {
    updateLayer(id, coalesceKey = null) { it.copy(font = font) }
  }

  fun toggleLayerBold(id: String) {
    updateLayer(id, coalesceKey = null) { it.copy(isBold = !it.isBold) }
  }

  fun toggleLayerItalic(id: String) {
    updateLayer(id, coalesceKey = null) { it.copy(isItalic = !it.isItalic) }
  }

  fun toggleLayerVisibility(id: String) {
    updateLayer(id, coalesceKey = null) { it.copy(isVisible = !it.isVisible) }
  }

  fun toggleLayerLock(id: String) {
    updateLayer(id, coalesceKey = null) { it.copy(isLocked = !it.isLocked) }
  }

  fun duplicateLayer(id: String) {
    mutateWithHistory { state ->
      val source = state.textLayers.firstOrNull { it.id == id } ?: return@mutateWithHistory state
      val copy =
        source.copy(
          id = UUID.randomUUID().toString(),
          xFraction = (source.xFraction + 0.05f).coerceAtMost(0.92f),
          yFraction = (source.yFraction + 0.05f).coerceAtMost(0.92f),
          isLocked = false,
        )
      state.copy(
        textLayers = state.textLayers + copy,
        selectedLayerId = copy.id,
      )
    }
  }

  fun deleteLayer(id: String) {
    mutateWithHistory { state ->
      val remaining = state.textLayers.filterNot { it.id == id }
      val nextSelected = if (state.selectedLayerId == id) null else state.selectedLayerId
      state.copy(textLayers = remaining, selectedLayerId = nextSelected)
    }
  }

  fun moveLayerOrder(id: String, bringForward: Boolean) {
    mutateWithHistory { state ->
      val list = state.textLayers.toMutableList()
      val index = list.indexOfFirst { it.id == id }
      if (index == -1) return@mutateWithHistory state
      val targetIndex = if (bringForward) index + 1 else index - 1
      if (targetIndex !in list.indices) return@mutateWithHistory state
      val item = list.removeAt(index)
      list.add(targetIndex, item)
      state.copy(textLayers = list)
    }
  }

  private fun updateLayer(
    id: String,
    coalesceKey: String?,
    transform: (TextLayer) -> TextLayer,
  ) {
    mutateWithHistory(coalesceKey = coalesceKey) { state ->
      state.copy(
        textLayers = state.textLayers.map { layer -> if (layer.id == id) transform(layer) else layer }
      )
    }
  }

  companion object {
    fun factory(
      photoDecoder: PhotoDecoder,
      projectRepository: ProjectRepository? = null,
      galleryExporter: GalleryExporter? = null,
      appContext: Context? = null,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return EditorViewModel(
            photoDecoder = photoDecoder,
            projectRepository = projectRepository,
            galleryExporter = galleryExporter,
            appContext = appContext,
          ) as T
        }
      }
  }
}
