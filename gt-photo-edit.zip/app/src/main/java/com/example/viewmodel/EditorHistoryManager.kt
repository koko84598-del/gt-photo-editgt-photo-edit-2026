package com.example.viewmodel

import com.example.model.EditorSnapshot

class EditorHistoryManager(
  private val maxEntries: Int = DEFAULT_MAX_ENTRIES,
  private val coalesceWindowMs: Long = DEFAULT_COALESCE_WINDOW_MS,
) {

  private val undoStack = ArrayDeque<EditorSnapshot>()
  private val redoStack = ArrayDeque<EditorSnapshot>()
  private var activeCoalesceKey: String? = null
  private var lastMutationMs: Long = 0L

  val canUndo: Boolean
    get() = undoStack.isNotEmpty()

  val canRedo: Boolean
    get() = redoStack.isNotEmpty()

  val undoSize: Int
    get() = undoStack.size

  val redoSize: Int
    get() = redoStack.size

  fun recordTransition(
    before: EditorSnapshot,
    after: EditorSnapshot,
    coalesceKey: String?,
    nowMs: Long = System.currentTimeMillis(),
  ) {
    if (before == after) return

    val shouldPush =
      coalesceKey == null ||
        coalesceKey != activeCoalesceKey ||
        (nowMs - lastMutationMs) > coalesceWindowMs

    if (shouldPush) {
      if (undoStack.size >= maxEntries) {
        undoStack.removeFirst()
      }
      undoStack.addLast(before)
    }

    activeCoalesceKey = coalesceKey
    lastMutationMs = nowMs
    redoStack.clear()
  }

  fun undo(current: EditorSnapshot): EditorSnapshot? {
    if (undoStack.isEmpty()) return null
    val previous = undoStack.removeLast()
    if (redoStack.size >= maxEntries) {
      redoStack.removeFirst()
    }
    redoStack.addLast(current)
    activeCoalesceKey = null
    return previous
  }

  fun redo(current: EditorSnapshot): EditorSnapshot? {
    if (redoStack.isEmpty()) return null
    val next = redoStack.removeLast()
    if (undoStack.size >= maxEntries) {
      undoStack.removeFirst()
    }
    undoStack.addLast(current)
    activeCoalesceKey = null
    return next
  }

  fun clear() {
    undoStack.clear()
    redoStack.clear()
    activeCoalesceKey = null
    lastMutationMs = 0L
  }

  companion object {
    const val DEFAULT_MAX_ENTRIES = 50
    const val DEFAULT_COALESCE_WINDOW_MS = 500L
  }
}
