package com.example.model

import android.graphics.Bitmap
import androidx.annotation.FontRes
import androidx.compose.ui.text.font.FontFamily
import com.example.R
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.NotoSansMyanmarFontFamily
import com.example.ui.theme.PadaukFontFamily
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.theme.RobotoMonoFontFamily
import com.example.ui.theme.SpaceGroteskFontFamily

enum class EditorCategory(val label: String) {
  PHOTO("Photo"),
  CROP("Crop"),
  ADJUST("Adjust"),
  HSL("HSL"),
  CURVE("Curve"),
  GRADING("Grading"),
  TEXT("Text"),
  LAYERS("Layers"),
}

enum class EditorFont(
  val displayName: String,
  val fontFamily: FontFamily,
  @FontRes val fontResId: Int,
) {
  NOTO_SANS_MYANMAR("Noto Myanmar", NotoSansMyanmarFontFamily, R.font.noto_sans_myanmar),
  PADAUK("Padauk", PadaukFontFamily, R.font.padauk),
  INTER("Inter", InterFontFamily, R.font.inter),
  SPACE_GROTESK("Space Grotesk", SpaceGroteskFontFamily, R.font.space_grotesk),
  PLAYFAIR_DISPLAY("Playfair", PlayfairDisplayFontFamily, R.font.playfair_display),
  ROBOTO_MONO("Roboto Mono", RobotoMonoFontFamily, R.font.roboto_mono),
}

enum class CropAspectRatio(val label: String, val ratio: Float?) {
  FREE("Free", null),
  ORIGINAL("Original", -1f),
  RATIO_1_1("1:1", 1f),
  RATIO_4_5("4:5", 4f / 5f),
  RATIO_3_4("3:4", 3f / 4f),
  RATIO_9_16("9:16", 9f / 16f),
  RATIO_16_9("16:9", 16f / 9f),
}

data class CropRect(
  val left: Float = 0f,
  val top: Float = 0f,
  val right: Float = 1f,
  val bottom: Float = 1f,
) {
  val width: Float
    get() = (right - left).coerceAtLeast(MIN_SIZE)

  val height: Float
    get() = (bottom - top).coerceAtLeast(MIN_SIZE)

  val isFullFrame: Boolean
    get() = left <= 0.001f && top <= 0.001f && right >= 0.999f && bottom >= 0.999f

  companion object {
    const val MIN_SIZE = 0.1f
  }
}

data class CropTransformParams(
  val cropRect: CropRect = CropRect(),
  val aspectRatio: CropAspectRatio = CropAspectRatio.FREE,
  val rotation90Degrees: Int = 0,
  val flipHorizontal: Boolean = false,
  val flipVertical: Boolean = false,
  val straightenDegrees: Float = 0f,
  val perspectiveVertical: Float = 0f,
  val perspectiveHorizontal: Float = 0f,
) {
  val isIdentity: Boolean
    get() =
      cropRect.isFullFrame &&
        rotation90Degrees % 360 == 0 &&
        !flipHorizontal &&
        !flipVertical &&
        straightenDegrees == 0f &&
        perspectiveVertical == 0f &&
        perspectiveHorizontal == 0f
}

enum class AdjustmentType(
  val label: String,
  val min: Float,
  val max: Float,
  val defaultValue: Float = 0f,
  val suffix: String = "",
) {
  BRIGHTNESS("Brightness", -1f, 1f),
  CONTRAST("Contrast", -1f, 1f),
  SATURATION("Saturation", -1f, 1f),
  EXPOSURE("Exposure", -2f, 2f, suffix = " EV"),
  HIGHLIGHTS("Highlights", -1f, 1f),
  SHADOWS("Shadows", -1f, 1f),
  TEMPERATURE("Temperature", -1f, 1f),
  TINT("Tint", -1f, 1f),
  VIBRANCE("Vibrance", -1f, 1f),
  HUE("Hue", -180f, 180f, suffix = "°"),
  VIGNETTE("Vignette", 0f, 1f),
  GRAIN("Grain", 0f, 1f),
}

data class ColorAdjustments(
  val brightness: Float = 0f,
  val contrast: Float = 0f,
  val saturation: Float = 0f,
  val exposure: Float = 0f,
  val highlights: Float = 0f,
  val shadows: Float = 0f,
  val temperature: Float = 0f,
  val tint: Float = 0f,
  val vibrance: Float = 0f,
  val hue: Float = 0f,
  val vignette: Float = 0f,
  val grain: Float = 0f,
) {
  val isIdentity: Boolean
    get() =
      brightness == 0f &&
        contrast == 0f &&
        saturation == 0f &&
        exposure == 0f &&
        highlights == 0f &&
        shadows == 0f &&
        temperature == 0f &&
        tint == 0f &&
        vibrance == 0f &&
        hue == 0f &&
        vignette == 0f &&
        grain == 0f

  fun valueFor(type: AdjustmentType): Float =
    when (type) {
      AdjustmentType.BRIGHTNESS -> brightness
      AdjustmentType.CONTRAST -> contrast
      AdjustmentType.SATURATION -> saturation
      AdjustmentType.EXPOSURE -> exposure
      AdjustmentType.HIGHLIGHTS -> highlights
      AdjustmentType.SHADOWS -> shadows
      AdjustmentType.TEMPERATURE -> temperature
      AdjustmentType.TINT -> tint
      AdjustmentType.VIBRANCE -> vibrance
      AdjustmentType.HUE -> hue
      AdjustmentType.VIGNETTE -> vignette
      AdjustmentType.GRAIN -> grain
    }

  fun withValue(type: AdjustmentType, value: Float): ColorAdjustments {
    val clamped = value.coerceIn(type.min, type.max)
    return when (type) {
      AdjustmentType.BRIGHTNESS -> copy(brightness = clamped)
      AdjustmentType.CONTRAST -> copy(contrast = clamped)
      AdjustmentType.SATURATION -> copy(saturation = clamped)
      AdjustmentType.EXPOSURE -> copy(exposure = clamped)
      AdjustmentType.HIGHLIGHTS -> copy(highlights = clamped)
      AdjustmentType.SHADOWS -> copy(shadows = clamped)
      AdjustmentType.TEMPERATURE -> copy(temperature = clamped)
      AdjustmentType.TINT -> copy(tint = clamped)
      AdjustmentType.VIBRANCE -> copy(vibrance = clamped)
      AdjustmentType.HUE -> copy(hue = clamped)
      AdjustmentType.VIGNETTE -> copy(vignette = clamped)
      AdjustmentType.GRAIN -> copy(grain = clamped)
    }
  }
}

// --- Milestone 3: HSL Color Mixer ---

enum class HslColorRange(
  val label: String,
  val centerHueDegrees: Float,
  val swatchArgb: Long,
) {
  RED("Red", 0f, 0xFFEF4444),
  ORANGE("Orange", 30f, 0xFFF97316),
  YELLOW("Yellow", 60f, 0xFFEAB308),
  GREEN("Green", 120f, 0xFF22C55E),
  AQUA("Aqua", 180f, 0xFF06B6D4),
  BLUE("Blue", 240f, 0xFF3B82F6),
  PURPLE("Purple", 275f, 0xFF8B5CF6),
  MAGENTA("Magenta", 315f, 0xFFEC4899),
}

data class HslAdjustment(
  val hue: Float = 0f, // -100..100
  val saturation: Float = 0f, // -100..100
  val luminance: Float = 0f, // -100..100
) {
  val isIdentity: Boolean
    get() = hue == 0f && saturation == 0f && luminance == 0f
}

data class HslMixerParams(
  val ranges: Map<HslColorRange, HslAdjustment> = emptyMap(),
) {
  val isIdentity: Boolean
    get() = ranges.values.all { it.isIdentity }

  fun forRange(range: HslColorRange): HslAdjustment = ranges[range] ?: HslAdjustment()

  fun withRange(range: HslColorRange, adjustment: HslAdjustment): HslMixerParams {
    val sanitized =
      HslAdjustment(
        hue = adjustment.hue.coerceIn(-100f, 100f),
        saturation = adjustment.saturation.coerceIn(-100f, 100f),
        luminance = adjustment.luminance.coerceIn(-100f, 100f),
      )
    val nextMap = ranges.toMutableMap()
    if (sanitized.isIdentity) {
      nextMap.remove(range)
    } else {
      nextMap[range] = sanitized
    }
    return copy(ranges = nextMap)
  }

  fun resetRange(range: HslColorRange): HslMixerParams = copy(ranges = ranges - range)
}

// --- Milestone 3: RGB Tone Curve ---

enum class ToneCurveChannel(val label: String, val accentArgb: Long) {
  RGB("RGB", 0xFFF1F5F9),
  RED("Red", 0xFFFB7185),
  GREEN("Green", 0xFF34D399),
  BLUE("Blue", 0xFF38BDF8),
}

data class CurvePoint(val x: Float, val y: Float)

data class ToneCurveParams(
  val rgbPoints: List<CurvePoint> = DEFAULT_POINTS,
  val redPoints: List<CurvePoint> = DEFAULT_POINTS,
  val greenPoints: List<CurvePoint> = DEFAULT_POINTS,
  val bluePoints: List<CurvePoint> = DEFAULT_POINTS,
) {
  val isIdentity: Boolean
    get() =
      isChannelIdentity(rgbPoints) &&
        isChannelIdentity(redPoints) &&
        isChannelIdentity(greenPoints) &&
        isChannelIdentity(bluePoints)

  fun pointsFor(channel: ToneCurveChannel): List<CurvePoint> =
    when (channel) {
      ToneCurveChannel.RGB -> rgbPoints
      ToneCurveChannel.RED -> redPoints
      ToneCurveChannel.GREEN -> greenPoints
      ToneCurveChannel.BLUE -> bluePoints
    }

  fun withPoints(channel: ToneCurveChannel, points: List<CurvePoint>): ToneCurveParams {
    val sanitized = sanitizePoints(points)
    return when (channel) {
      ToneCurveChannel.RGB -> copy(rgbPoints = sanitized)
      ToneCurveChannel.RED -> copy(redPoints = sanitized)
      ToneCurveChannel.GREEN -> copy(greenPoints = sanitized)
      ToneCurveChannel.BLUE -> copy(bluePoints = sanitized)
    }
  }

  fun resetChannel(channel: ToneCurveChannel): ToneCurveParams =
    withPoints(channel, DEFAULT_POINTS)

  companion object {
    val DEFAULT_POINTS = listOf(CurvePoint(0f, 0f), CurvePoint(1f, 1f))

    fun isChannelIdentity(points: List<CurvePoint>): Boolean =
      points.size == 2 &&
        points[0].x <= 0.001f &&
        points[0].y <= 0.001f &&
        points[1].x >= 0.999f &&
        points[1].y >= 0.999f

    fun sanitizePoints(raw: List<CurvePoint>): List<CurvePoint> {
      if (raw.size < 2) return DEFAULT_POINTS
      val sorted =
        raw.map { CurvePoint(it.x.coerceIn(0f, 1f), it.y.coerceIn(0f, 1f)) }.sortedBy { it.x }
      val result = mutableListOf<CurvePoint>()
      result.add(CurvePoint(0f, sorted.first().y))
      for (i in 1 until sorted.lastIndex) {
        val prevX = result.last().x
        val clampedX = sorted[i].x.coerceIn(prevX + 0.03f, 0.97f)
        if (clampedX < 0.97f || sorted[i].x <= 0.97f) {
          result.add(CurvePoint(clampedX, sorted[i].y))
        }
      }
      result.add(CurvePoint(1f, sorted.last().y))
      return result
    }
  }
}

// --- Milestone 3: Color Grading ---

enum class GradingRange(val label: String) {
  SHADOWS("Shadows"),
  MIDTONES("Midtones"),
  HIGHLIGHTS("Highlights"),
}

data class ColorGradeWheel(
  val hueDegrees: Float = 0f, // 0..360
  val saturation: Float = 0f, // 0..1
  val luminance: Float = 0f, // -1..1
) {
  val isIdentity: Boolean
    get() = saturation == 0f && luminance == 0f
}

data class ColorGradingParams(
  val shadows: ColorGradeWheel = ColorGradeWheel(),
  val midtones: ColorGradeWheel = ColorGradeWheel(),
  val highlights: ColorGradeWheel = ColorGradeWheel(),
) {
  val isIdentity: Boolean
    get() = shadows.isIdentity && midtones.isIdentity && highlights.isIdentity

  fun forRange(range: GradingRange): ColorGradeWheel =
    when (range) {
      GradingRange.SHADOWS -> shadows
      GradingRange.MIDTONES -> midtones
      GradingRange.HIGHLIGHTS -> highlights
    }

  fun withRange(range: GradingRange, wheel: ColorGradeWheel): ColorGradingParams {
    val sanitized =
      ColorGradeWheel(
        hueDegrees = ((wheel.hueDegrees % 360f) + 360f) % 360f,
        saturation = wheel.saturation.coerceIn(0f, 1f),
        luminance = wheel.luminance.coerceIn(-1f, 1f),
      )
    return when (range) {
      GradingRange.SHADOWS -> copy(shadows = sanitized)
      GradingRange.MIDTONES -> copy(midtones = sanitized)
      GradingRange.HIGHLIGHTS -> copy(highlights = sanitized)
    }
  }

  fun resetRange(range: GradingRange): ColorGradingParams =
    withRange(range, ColorGradeWheel())
}

// --- Core Photo & Text Layer Models ---

data class ImportedPhoto(
  val uriString: String,
  val displayName: String,
  val originalWidth: Int,
  val originalHeight: Int,
  val bitmap: Bitmap,
)

data class TextLayer(
  val id: String,
  val text: String,
  val xFraction: Float = 0.5f,
  val yFraction: Float = 0.5f,
  val fontSizeSp: Float = 28f,
  val rotationDegrees: Float = 0f,
  val colorArgb: Long = 0xFFFFFFFF,
  val opacity: Float = 1f,
  val font: EditorFont = EditorFont.NOTO_SANS_MYANMAR,
  val isBold: Boolean = false,
  val isItalic: Boolean = false,
  val isVisible: Boolean = true,
  val isLocked: Boolean = false,
)

// --- Milestone 4: Undo/Redo Snapshot, Project Persistence, and Gallery Export ---

data class EditorSnapshot(
  val cropTransform: CropTransformParams = CropTransformParams(),
  val colorAdjustments: ColorAdjustments = ColorAdjustments(),
  val hslMixer: HslMixerParams = HslMixerParams(),
  val toneCurve: ToneCurveParams = ToneCurveParams(),
  val colorGrading: ColorGradingParams = ColorGradingParams(),
  val textLayers: List<TextLayer> = emptyList(),
  val selectedLayerId: String? = null,
)

data class SavedProject(
  val id: String,
  val name: String,
  val sourceUriString: String,
  val sourceDisplayName: String,
  val originalWidth: Int,
  val originalHeight: Int,
  val updatedAtMillis: Long,
  val activeCategory: EditorCategory = EditorCategory.PHOTO,
  val snapshot: EditorSnapshot = EditorSnapshot(),
)

data class SavedProjectSummary(
  val id: String,
  val name: String,
  val sourceDisplayName: String,
  val originalWidth: Int,
  val originalHeight: Int,
  val updatedAtMillis: Long,
  val layerCount: Int,
)

enum class ExportFormat(
  val label: String,
  val mimeType: String,
  val extension: String,
) {
  JPEG("JPEG", "image/jpeg", "jpg"),
  PNG("PNG", "image/png", "png"),
}

data class ExportResult(
  val outputUriString: String,
  val displayName: String,
  val width: Int,
  val height: Int,
  val format: ExportFormat,
)

data class EditorUiState(
  val importedPhoto: ImportedPhoto? = null,
  val previewBitmap: Bitmap? = null,
  val isLoadingPhoto: Boolean = false,
  val isProcessingImage: Boolean = false,
  val isExporting: Boolean = false,
  val photoError: String? = null,
  val statusMessage: String? = null,
  val missingSourceMessage: String? = null,
  val cropTransform: CropTransformParams = CropTransformParams(),
  val colorAdjustments: ColorAdjustments = ColorAdjustments(),
  val hslMixer: HslMixerParams = HslMixerParams(),
  val toneCurve: ToneCurveParams = ToneCurveParams(),
  val colorGrading: ColorGradingParams = ColorGradingParams(),
  val textLayers: List<TextLayer> = emptyList(),
  val selectedLayerId: String? = null,
  val activeCategory: EditorCategory = EditorCategory.PHOTO,
  val isPanelExpanded: Boolean = true,
  val canUndo: Boolean = false,
  val canRedo: Boolean = false,
  val currentProjectId: String? = null,
  val currentProjectName: String? = null,
  val savedProjects: List<SavedProjectSummary> = emptyList(),
) {
  val selectedLayer: TextLayer?
    get() = textLayers.firstOrNull { it.id == selectedLayerId }

  fun toSnapshot(): EditorSnapshot =
    EditorSnapshot(
      cropTransform = cropTransform,
      colorAdjustments = colorAdjustments,
      hslMixer = hslMixer,
      toneCurve = toneCurve,
      colorGrading = colorGrading,
      textLayers = textLayers,
      selectedLayerId = selectedLayerId,
    )
}
