package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AndroidPhotoDecoder
import com.example.data.LocalProjectRepository
import com.example.data.MediaStoreGalleryExporter
import com.example.model.ExportFormat
import com.example.ui.EditorRoute
import com.example.ui.theme.GTPhotoEditTheme
import com.example.viewmodel.EditorViewModel

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
    )
    val decoder = AndroidPhotoDecoder(applicationContext)
    val projectRepository = LocalProjectRepository(applicationContext)
    val galleryExporter = MediaStoreGalleryExporter(applicationContext)

    setContent {
      GTPhotoEditTheme {
        val editorViewModel: EditorViewModel =
          viewModel(
            factory =
              EditorViewModel.factory(
                photoDecoder = decoder,
                projectRepository = projectRepository,
                galleryExporter = galleryExporter,
                appContext = applicationContext,
              )
          )

        val photoPickerLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri ->
              if (uri != null) {
                runCatching {
                  contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                  )
                }
                editorViewModel.importPhoto(uri)
              }
            },
          )

        val relinkPhotoLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.PickVisualMedia(),
            onResult = { uri ->
              if (uri != null) {
                runCatching {
                  contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION,
                  )
                }
                editorViewModel.relinkPhoto(uri)
              }
            },
          )

        var pendingExport by remember { mutableStateOf<Pair<ExportFormat, Int>?>(null) }

        val storagePermissionLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission(),
            onResult = { granted ->
              val req = pendingExport
              pendingExport = null
              if (req != null) {
                if (granted) {
                  editorViewModel.exportToGallery(req.first, req.second)
                } else {
                  editorViewModel.reportExportError(
                    "Storage permission is required to save exported images to Gallery."
                  )
                }
              }
            },
          )

        EditorRoute(
          viewModel = editorViewModel,
          onLaunchPhotoPicker = {
            photoPickerLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          onLaunchRelinkPicker = {
            relinkPhotoLauncher.launch(
              PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
          },
          onRequestExport = { format, quality ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
              editorViewModel.exportToGallery(format, quality)
            } else {
              val hasLegacyWrite =
                ContextCompat.checkSelfPermission(
                  this@MainActivity,
                  Manifest.permission.WRITE_EXTERNAL_STORAGE,
                ) == PackageManager.PERMISSION_GRANTED
              if (hasLegacyWrite) {
                editorViewModel.exportToGallery(format, quality)
              } else {
                pendingExport = format to quality
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
              }
            }
          },
        )
      }
    }
  }
}
